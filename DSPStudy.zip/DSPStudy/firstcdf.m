function [sum1]=firstcdf(rms2delay,binnum,dif,difdB);

		%Calculate CDF
      [bins,z]=hist(rms2delay,binnum);
      
      sum1=0;
		for s=1:length(bins)
    		sum1=sum1+bins(s);
    		cd(s)=sum1;
    		cdf(s)=cd(s)/length(rms2delay);	
		end;
		figure(gcf+1)
		plot(z,cdf)
      axis([0 50 0 1])
      grid on;
		xlabel('rms delay spread (ns)');
		ylabel('CDF');
      title('Cumulative Distribution Function');
      
      %Calculate CDF
      [bins,z]=hist(dif,binnum);
      clear sum1 cdf cd
      sum1=0;
		for s=1:length(bins)
    		sum1=sum1+bins(s);
    		cd(s)=sum1;
    		cdf(s)=cd(s)/length(rms2delay);	
		end;
		figure(gcf+1)
		plot(z,cdf)
      %axis([0 50 0 1])
      grid on;
		xlabel('yhattilde - rms delay (ns)');
		ylabel('CDF');
      title('Cumulative Distribution Function');
      
      
      %Calculate CDF
      [bins,z]=hist(10*log(rms2delay+1),binnum);
      clear sum1 cdf cd
      sum1=0;
		for s=1:length(bins)
    		sum1=sum1+bins(s);
    		cd(s)=sum1;
    		cdf(s)=cd(s)/length(rms2delay);	
		end;
		figure(gcf+1)
      plot(z,cdf)
      grid on;
		%axis([-20 10 10e-1 100])
		xlabel('10log_1_0(rms delay) (dB)');
		ylabel('CDF');
      title('Cumulative Distribution Function');
      
      %Calculate CDF
      [bins,z]=hist(difdB,binnum);
      clear sum1 cdf cd
      sum1=0;
		for s=1:length(bins)
    		sum1=sum1+bins(s);
    		cd(s)=sum1;
    		cdf(s)=cd(s)/length(rms2delay);	
		end;
		figure(gcf+1)
		plot(z,cdf)
      %axis([0 50 0 1])
      grid on;
		xlabel('10log_1_0(yhattilde) - 10log_1_0(rms delay) (dB)');
		ylabel('CDF');
      title('Cumulative Distribution Function');
      
      
      