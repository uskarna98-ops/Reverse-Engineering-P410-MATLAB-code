
function [nrdatafiles,nrdatapts,nrdatasp,scanmatrix,lockmatrix,distancedata,xtag,ytag,RXcoord,BERmatrix,...
        SNRmatrix,VGA,txatt,rxatt,deltat,timebaseoff,filenum,tstop,disttype]=size_inputs(distinmeters,disttype,...
        distancedata,tstop,nrdatapts,timeperpt,scanmatrix,lockmatrix,setrange,nrdatast,nrdatasp,...
        nrdatafiles,AoAon,xtag,ytag,RXcoord,BERmatrix,SNRmatrix,VGA,txatt,rxatt,deltat,timebaseoff)


 %Force to meters
   if distinmeters==1
      if disttype==1
   		distancedata=distancedata/3.28;
        xtag=xtag/3.28;
        ytag=ytag/3.28;
        RXcoord=RXcoord/3.28;
   		disttype=2;
      end
   end   
 %Shorten Matrices based upon chosen time-window      
   if tstop==1
      tstop=nrdatapts*timeperpt;
   end
   looklength=round(tstop/timeperpt);
   if looklength > nrdatapts
      looklength=nrdatapts;
      tstop=nrdatapts*timeperpt;
   end   	      
   nrdatapts=looklength;
   scanmatrix=scanmatrix(1:looklength,:);
   lockmatrix=lockmatrix(1:looklength,:);
 
 %Shorten Matrices based on data file numbers  
   if setrange==1
   	%Always read in 1st two scans
 		if nrdatast<=2
    		nrdatast=3;
 		end   
   	nrdatafiles=nrdatasp-nrdatast+1+2;
   	scanmatrix=[scanmatrix(:,1:2) scanmatrix(:,nrdatast:nrdatasp)];
 		lockmatrix=[lockmatrix(:,1:2) lockmatrix(:,nrdatast:nrdatasp)];
 		distancedata=[distancedata(1:2) distancedata(nrdatast:nrdatasp)];
       if AoAon==1
        xtag=[xtag(1:2);xtag(nrdatast:nrdatasp)];
        ytag=[ytag(1:2);ytag(nrdatast:nrdatasp)];
       end 
   	BERmatrix=[BERmatrix(1:2);BERmatrix(nrdatast:nrdatasp)];
    
 		SNRmatrix=[SNRmatrix(1:2,:);SNRmatrix(nrdatast:nrdatasp,:)];
    
   	VGA=[VGA(1:2) VGA(nrdatast:nrdatasp)];
 		txatt=[txatt(1:2) txatt(nrdatast:nrdatasp)];
 		rxatt=[rxatt(1:2) rxatt(nrdatast:nrdatasp)];
      deltat=[deltat(1:2) deltat(nrdatast:nrdatasp)];
      timebaseoff=[timebaseoff(1:2) timebaseoff(nrdatast:nrdatasp)];
      
      filenum=[1 2 nrdatast:nrdatasp];
   else
      filenum=[1:nrdatafiles];
      nrdatasp=nrdatafiles;
   end  