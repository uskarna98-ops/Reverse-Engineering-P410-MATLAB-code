function [peakVV,rmsVV]=calcrmsV(AA);

%Calculate the Peak and RMS voltage of a voltage vector AA
ak2=AA.^2;
peakVV = sqrt(max(ak2));
rmsVV = sqrt( sum(ak2)./length(AA) );