% by David J. Hall
% Time Domain Corporation
% 17 Dec 1999
% 16:00

M=zeros(240,240);  % row gives ratio of energy relative to biggest pulse in increments of 0.25
% column gives time of arrival in increments of 2 nS
PeakData=zeros(40,1000);  	% Each row contains energy in hightest peak, 2nd highest, etc., relative
									%		to main lobe.
                           % Each column contains data from each consecutive input file.
                           % NOTE: limit of 1000 input files.
FID2=fopen('filelist.txt','r');   % read list of files to process
numfiles=fscanf(FID2,'%g',1)
S=fscanf(FID2,'%s');
v=findstr(S,'out')+2;   % find all occurrances of 'out' in the input file names

masterMpdf=zeros(240,240);
masterMenergy=zeros(240,240);
count=1;
threshholdpointer=1

valuefirstpulse=zeros(1,1000);   % where to put the value of the first pulse
threshholds=zeros(2,1000);       % where to put the value of the standard deviation of the first 2 nS, and
                                 %    standard deviation of the entire run.
columnpointer=0;
for bigloop=1:numfiles  
   M=zeros(240,240);   
   FID=fopen(S(count:v(bigloop)),'r');
   numreadings=fscanf(FID,'%g',1)
   for k=1:numreadings
      columnpointer=columnpointer+1
      temp2=zeros(1000,2);  % NOTE: at most can have 1000 peaks unless you change this - djh
      numpoints=fscanf(FID,'%g',1)
      % read in tpeakval
      for l=1:numpoints
         n=fscanf(FID,'%g',1);
         temp2(l,1)=n;
			PeakData(l,columnpointer)=n;         % read in value of numpoints hightest lobes
      end %l   
      
      % read in tpeakpts
      for l=1:numpoints
         n=fscanf(FID,'%g',1);
         temp2(l,2)=n;
      end %l 
      
      % place temp() into M[][] to create 2-D pdf
      for l=1:numpoints
         m=1+round(199.1667*temp2(l,1)/temp2(1,1));
         if m<1
            m=1;
         end;
         if m>240
            m=240;
         end;
         n=round( 2.39*(temp2(l,2)+30)  )+1;
         if n<1
            n=1;
         end;
         if n>240
            n=240;
         end;
         M(m,n)=M(m,n)+1;
         masterMpdf(m,n)=masterMpdf(m,n)+1;
      end         
   end %k  
   
   t=fscanf(FID, '%g %g %g', [3,inf]);
   [m n]=size(t);
   for k=threshholdpointer: (threshholdpointer+n-1)
      valuefirstpulse(1,k)=t(1,k+1-threshholdpointer);
      threshholds(1:2, k)=t(2:3, k+1-threshholdpointer);
   end; %k      
   threshholdpointer=threshholdpointer+n;
   figure(1);
   fclose(FID);
  
  
   % plot matrix M - meshgrid plot
   figure(1);
   xx= -30 : 100/240 : (70-(100/240));
   yy= 0: 1.2/240  : 1.2-(1.2/240);

   mesh(xx,yy,M);
   title('distribution of pulses');
   xlabel('time(nS)');
   ylabel('relative energy ratio');
   text(40,.5,10,S(count:v(bigloop)));
   
   %plot matrix M - contour plot
   figure(2);
   contour(xx,yy,M,15);
   title('distribution of pulses');
   xlabel('time(nS)')
   ylabel('relative energy ratio');
   grid on;
   text(40,.2,S(count:v(bigloop)));
         
   % plot 1-D distribution of pulse count vs. time 
   figure(3);
   Msum=sum(M);
   plot(xx,Msum);
   title('distribution of pulses vs. time');
   xlabel('time(nS)');
   ylabel('pdf');
   text(40,10,S(count:v(bigloop)));
   grid on;
   
      
   
   
   
   
   
   
   M=zeros(240,240); 
   FID=fopen(S(count:v(bigloop)),'r');
   numreadings=fscanf(FID,'%g',1)
   for k=1:numreadings
      temp2=zeros(1000,2);  % NOTE: at most can have 1000 peaks unless you change this - djh
      numpoints=fscanf(FID,'%g',1)
      % read in tpeakval
      for l=1:numpoints
         n=fscanf(FID,'%g',1);
         temp2(l,1)=n;
      end %l   
      % read in tpeakpts
      for l=1:numpoints
         n=fscanf(FID,'%g',1);
         temp2(l,2)=n;
      end %l 
      
      % place temp() into M[][] to create 2-D pdf
      for l=1:numpoints
         
         m=1+round(199.1667*temp2(l,1)/temp2(1,1));
         if m<1
            m=1;
         end;
         if m>240
            m=240;
         end;
         n=round( 2.39*(temp2(l,2)+30)  )+1;
         if n<1
            n=1;
         end;
         if n>240
            n=240;
         end;
         M(m,n)=M(m,n)+temp2(1,1)^2;  % add ENERGY to bin, instead of just incrementing it
         masterMenergy(m,n)=masterMenergy(m,n)+temp2(1,1)^2;
      end         
   end %k   
   fclose(FID);
  
   figure(4);
   xx= -30 : 100/240 : (70-(100/240));
   yy= 0: 1.2/240  : 1.2-(1.2/240);
   mesh(xx,yy,M);
   title('ENERGY distribution of pulses');
   xlabel('time(nS)');
   ylabel('relative energy ratio');
   text(40,.5,8e12,S(count:v(bigloop)));

   
   %plot matrix M - contour plot
   figure(5);
   contour(xx,yy,M,15);
   title('ENERGY distribution of pulses');
   xlabel('time(nS)')
   ylabel('relative energy ratio');
   grid on;
   text(40,.2,S(count:v(bigloop)));
        
   % plot 1-D distribution of pulse count vs. time 
   figure(6);
   Msum=sum(M);
   plot(xx,Msum);
   title('distribution of pulses vs. time');
   xlabel('time(nS)');
   ylabel('pdf');
   text(40,8e12,S(count:v(bigloop)));
   grid on;
         
   pause;
   
   count=v(bigloop)+1;     % increment pointer to next filename
end; % bigloop


% Normalize pulse data so that it is power relative to main pulse
for nextbigloop=1:columnpointer
   PeakData(2:40, nextbigloop)= (PeakData(2:40, nextbigloop)/PeakData(1, nextbigloop) ).^2;
end % nextbigloop   
fclose(FID2);




%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% plot matrix M - meshgrid plot
pause;


figure(1);
xx= -30 : 100/240 : (70-(100/240));
yy= 0: 1.2/240  : 1.2-(1.2/240);
mesh(xx,yy,masterMpdf)
title('total distribution of pulses')
xlabel('time(nS)');
ylabel('relative energy ratio');
   
%plot matrix M - contour plot
figure(2);
contour(xx,yy,masterMpdf,15);
title('total distribution of pulses')
xlabel('time(nS)');
ylabel('relative energy ratio');
grid on;
      
% plot 1-D distribution of pulse count vs. time 
figure(3);
Msum=sum(masterMpdf);
plot(xx,Msum);
title('total distribution of pulses vs. time');
xlabel('time(nS)');
ylabel('pdf');
grid on;
      
figure(4);
xx= -30 : 100/240 : (70-(100/240));
yy= 0: 1.2/240  : 1.2-(1.2/240);
mesh(xx,yy,masterMenergy)
title('total ENERGY distribution of pulses');
xlabel('time(nS)');
ylabel('relative energy ratio');
   
%plot matrix M - contour plot
figure(5);
contour(xx,yy,masterMenergy,15);
title('total ENERGY distribution of pulses');
xlabel('time(nS)');
ylabel('relative energy ratio');
grid on;
      
% plot 1-D distribution of pulse count vs. time 
figure(6);
Msum=sum(masterMenergy);
plot(xx,Msum);
title('total ENERGY distribution of pulses vs. time');
xlabel('time(nS)');
ylabel('pdf');
grid on;
   
x1=0: .10e6 : 10e6;
x2=0: .10e6 : 10e6;
x3=0: .10e6: 10e6
h1=hist(valuefirstpulse(1:threshholdpointer-1),x1);
h2=hist(threshholds(1, 1:threshholdpointer-1),x2);
h3=hist(threshholds(2, 1:threshholdpointer-1),x2);
pause;
figure(7);
plot(x1,h1,x2,h2,x3,h3);
title('Histogram of scan channel data');
axis([0 10e6 0 140]);
legend('first pulse','s.d. of first 2 nS','s.d. of entire channel');
hold on;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
   
% Plot Histogram of Percentage of Energy Relative to Main Lobe
figure(8)
for k=1:4
   mu=mean(PeakData(k,1:columnpointer));
   sd=std(PeakData(k,1:columnpointer));
     
   x=-0.1:.02:1.1;
   y=zeros(length(x),1);
   for l=1:length(x)
      y(l)=exp(-(x(l)-mu)^2/(2*sd^2))/(sqrt(2*pi*sd));
   end  %k      
   subplot(4,1,k);
   plot(x,y,'b-');
   axis([-0.1 1.1 0 1.5]);
   title('Histogram of Energy Relative to Main Lobe');
   xlabel('Percent of Energy Relative to Main Lobe');
   ylabel('distribution');
   grid on;
end %k
figure(9)
for k=5:8
   mu=mean(PeakData(k,1:columnpointer));
   sd=std(PeakData(k,1:columnpointer));     
   x=-0.1:.02:1.1;
   y=zeros(length(x),1);
   for l=1:length(x)
      y(l)=exp(-(x(l)-mu)^2/(2*sd^2))/(sqrt(2*pi*sd));
   end  %k      
   subplot(4,1,k-4);
   plot(x,y,'b-');
   axis([-0.1 1.1 0 1.5]);
   title('Histogram of Energy Relative to Main Lobe');
   xlabel('Percent of Energy Relative to Main Lobe');
   ylabel('distribution');
   grid on;
end %k   
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%