
function [startLE,stopLE,DoAfig,LE,LE2,LE3,LEAoA,LE_2,LE_2truth,DoA,DoAtruth,PEAK1,PEAK2,thetaAoA,...
            thetaREAL,NLOS,LEDon,templatestart]=...
            calc_LED(AoAon,LEDon,tempwidth,RXcoord,xtag,ytag,cable_delayns,...
            filenum,nrdatafiles,nrdatapts,filteredscanmatrix,timeperpt,chooseLED,Ts,firsttemp,...
            tstart,tstop,distfile,disttype,Naoa,EbNeff_scan,firstpeak4,distancedata)

  c=3e8; %meters per second
  feet_per_meter=100/2.54/12;
  cftps=feet_per_meter*c/1e12; %feet per picosecond
  nsperft = 1/cftps/1000;%1.0167;
  nsperm  = nsperft*3.28;
  if disttype==1
      nsperd=nsperft;
  elseif disttype==2
      nsperd=nsperm;
  end    
  
  if AoAon==1
      LEDon=1;
  	  A=sqrt( ( RXcoord(2,1)-RXcoord(1,1) )^2 + ( RXcoord(2,2)-RXcoord(1,2) )^2 + ( RXcoord(2,3)-RXcoord(1,3) )^2); %antenna separation in feet
  end   
  if LEDon==1
    disp(' ');
	disp(' ');
	disp('Calculating leading edge. . .');
    LE_2=0;
    LE_2truth=0;
    for k=1:nrdatafiles
      LEDcount=filenum(k);
      AoAcount=filenum(k);
      if AoAon==1
         AoAcount
      else   
         LEDcount
      end   
      %LED Variable Inputs (Correlate,Envelope,Difference,Peak) **********
      step=round(.6/(Ts/1e-9));%step=20;  		%step in ~.768 ns; was 16 for Ts=48 ps
      cumsamps=round(.6/(Ts/1e-9));cumsamps=20;  %cumulate over 1 ns; was 21 for Ts=48 ps
      peakdiv=5;				  			%peak=peak/peakdiv;
      addtoLE=round(.384/(Ts/1e-9));					%add ~.38 ns; was 8 for Ts=48 ps
      
      %LED2 Variable Inputs (Correlate,Envelope,Mean Threshold) **********
      step2=step;
      meantimes2=1.5;	%envelopeMEAN=envelopeMEAN*meantimes;
      
      %LED3 Variable Inputs (Time-reverse Correlate,Peak/Mean Threshold) ***********
      threshdiv3=40;   %threshold=(peakvalue-meanvalue)/threshdiv + meanvalue;
      
      if k==1
         Template=0;
      end
      [leadingedge]=LED(nrdatapts,filteredscanmatrix(:,k),step,Ts,cumsamps,peakdiv,addtoLE,k,tstart,tstop);
      [leadingedge2]=LED2(nrdatapts,filteredscanmatrix(:,k),step2,Ts,meantimes2,k,tstart,tstop);
      [leadingedge3,gamma]=LED3(nrdatapts,filteredscanmatrix(:,k),Ts,threshdiv3,k,tstart,tstop);
      [leadingedge4,Template]=LED4(nrdatapts,filteredscanmatrix(:,k),step2,Ts,meantimes2...
         ,k,firsttemp,tempwidth,Template,firstpeak4,tstart,tstop);
      	PAR(k)=gamma; %Peak to mean ratio
      %if AoAon==1
      %   LEstop=cable_delayns
      %   LEDscanmatrix(:,k)=[filteredscanmatrix(1:LEstop,k) zeros(1,length(filteredscanmatrix(:,k)-AoAstop))];
      %end       
      LE(k)=leadingedge*timeperpt;
      LE2(k)=leadingedge2*timeperpt;
      LE3(k)=leadingedge3*timeperpt;
      LE4(k)=leadingedge4*timeperpt;
      
      if chooseLED==0
         leadingedgeAoA=leadingedge;
      elseif chooseLED==2
         leadingedgeAoA=leadingedge2;
      elseif chooseLED==3
         leadingedgeAoA=leadingedge3; 
      elseif chooseLED==4
         leadingedgeAoA=leadingedge4;
      end 
      LEAoA(k)=leadingedgeAoA*timeperpt;
      
      %Use LED to set starting point of CLEAN template
      if k==1
         templatestart=leadingedgeAoA;
      end
      
      if AoAon==1
         %Assumes first measurement is 1 meter boresight (AoA=0 degrees)
         [aoa,correlation,Start,End,Template,cable_delayns,firstpeak,firstpeakmax,secondpeak,...
               secondpeakmax] = AOA(nrdatapts,filteredscanmatrix(:,k),leadingedgeAoA,...
            	tempwidth, cable_delayns, A,k,nsperd,Ts,firsttemp,Template,tstart,tstop);
         PEAK1(k)=20*log10(firstpeakmax);
         PEAK2(k)=20*log10(secondpeakmax);   
         PEAK1time(k)=firstpeak*timeperpt;
         PEAK2time(k)=secondpeak*timeperpt;
         LE_2(k)=aoa*timeperpt;
         DIF1(k)=PEAK1time(k)-LEAoA(k);
         DIF2(k)=PEAK2time(k)-LE_2(k);
         %Try to predict NLOS
         	DIF1low=DIF1(1)-2*Ts/1e-9; DIF1hi =DIF1(1)+2*Ts/1e-9;       
            DIF2low=DIF2(1)-2*Ts/1e-9; DIF2hi =DIF2(1)+2*Ts/1e-9;
         	if DIF1(k)<DIF1low | DIF1(k)>DIF1hi
         		NLOS(k)=1;   
         	elseif DIF2(k)<DIF2low | DIF2(k)>DIF2hi 
            	NLOS(k)=1;
         	else
            	NLOS(k)=0;
         	end   
         if distfile==1
            DoA(k)=abs(LEAoA(k)-LE_2(k))-cable_delayns;
         	Ans = A * nsperd;
        	%Plane Wave Assumption
           		thetaAoA(k)=asin(DoA(k)/Ans).*180/pi; %degrees
           		thetaREAL(k)=atan( ytag(k)/(xtag(k)+1e-12) ).*180/pi;
         	   if xtag(k)<0 & ytag(k)>0
                  thetaREAL(k)=180 + atan( ytag(k)/(xtag(k)+1e-12) ).*180/pi;
                  thetaAoA(k) =180 - asin(DoA(k)/Ans).*180/pi; %degrees
               elseif xtag(k)<0 & ytag(k)<0
                  thetaREAL(k)=-180 + atan( ytag(k)/(xtag(k)+1e-12) ).*180/pi;
                  thetaAoA(k) =-180 - asin(DoA(k)/Ans).*180/pi; %degrees
               end
          %Truth Data
            	 DoAtruth(k)=Ans*sin(thetaREAL(k)*pi/180);
                LE_2truth(k)=LEAoA(k)+DoAtruth(k)+cable_delayns;
          %Try to calculate Range of Tag
          	PEAK1norm(k)=PEAK1(k)-PEAK1(1);
          	PEAK2norm(k)=PEAK2(k)-PEAK2(1);
            %Adjust for DoA assuming free space
            d1=distancedata(1)*1./10.^(PEAK1norm(k)./(Naoa*10));
            d2=distancedata(1)*1./10.^(PEAK2norm(k)./(Naoa*10));
            d1a=distancedata(1)*1./10.^(PEAK1norm(k)./(Naoa*10)) + (DoA(k)/nsperd)/2;
		    d2a=distancedata(1)*1./10.^(PEAK2norm(k)./(Naoa*10)) + (DoA(k)/nsperd)/2;
            %if Doa(k)<=0
            %   PEAK1norm(k)=PEAK1norm(k) + Naoa*10*log10(abs(DoA(k)/nsperd)/2/distancedata(1) );
            % 	PEAK2norm(k)=PEAK2norm(k) + Naoa*10*log10(abs(DoA(k)/nsperd)/2/distancedata(1) );
            %elseif Doa(k)>0
            %   PEAK1norm(k)=PEAK1norm(k) - Naoa*10*log10(abs(DoA(k)/nsperd)/2/distancedata(1) );
            % 	PEAK2norm(k)=PEAK2norm(k) - Naoa*10*log10(abs(DoA(k)/nsperd)/2/distancedata(1) );
            %end
            %PEAK1norm(k)=Naoa*10*log10( 10^(PEAK1norm(k)/(Naoa*10)) - (DoA(k)/nsperd)/2/distancedata(1) );
            %PEAK2norm(k)=Naoa*10*log10( 10^(PEAK2norm(k)/(Naoa*10)) - (DoA(k)/nsperd)/2/distancedata(1) );
            %Condition for LOS
            if NLOS(k)==0 & abs(PEAK1norm(k)-PEAK2norm(k))<=1
               choice(k)=1;
               daoa(k)=mean([d1 d2]);
               daoa2(k)=mean([d1a d2a]);
            elseif DIF1(k)>DIF1low | DIF1(k)<DIF1hi
               choice(k)=2;
               daoa(k)=d1;
               daoa2(k)=d1a;%
            elseif DIF2(k)>DIF2low | DIF2(k)<DIF2hi   
               choice(k)=3;
               daoa(k)=d2;
               daoa2(k)=d2a;
            else
               choice(k)=4;
               Naoa=2.8;
               d1=distancedata(1)*1./10.^(PEAK1norm(k)./(Naoa*10));
               d2=distancedata(1)*1./10.^(PEAK2norm(k)./(Naoa*10));
               d1a=distancedata(1)*1./10.^(PEAK1norm(k)./(Naoa*10)) + (DoA(k)/nsperd)/2;
		    		d2a=distancedata(1)*1./10.^(PEAK2norm(k)./(Naoa*10)) + (DoA(k)/nsperd)/2;
               daoa(k)=mean([d1 d2]);
               daoa2(k)=mean([d1a d2a]);
            end
           
               
          end%if distfile      
       D1(k)=d1;
       D2(k)=d2;
       D12(k)=d1a;
       D22(k)=d2a;   
       end%if AoAon
   end%for k
    
    %[round(filenum') distancedata' daoa' daoa2' D1' D2' (PEAK1norm-PEAK2norm)' round(choice') ]
    %[round(filenum') abs(distancedata-daoa)' abs(distancedata-daoa2)' ];
    if AoAon==1
        startLE=round((cable_delayns-Ans)/(Ts*1e9));
        stopLE= round((cable_delayns+Ans)/(Ts*1e9));   
        count=0;count2=0;
        for h=1:length(daoa)
        if abs(distancedata(h)-daoa(h)) < abs(distancedata(h)-daoa2(h))
            count=count+1;
        elseif abs(distancedata(h)-daoa(h)) > abs(distancedata(h)-daoa2(h))
          count2=count2+1;
        end   
        end
        DaoaPER=count/length(daoa);
        Daoa2PER=(count2)/length(daoa);
        %Calculate TAG position with AoA angle and calculated distance
        %xtagAoA(k)=cos(thetaAoA(k)*pi/180)*distancedata(k);
        %ytagAoA(k)=sin(thetaAoA(k)*pi/180)*distancedata(k);
        if Daoa2PER>DaoaPER
           DAOA=real(daoa2);
        else
           DAOA=real(daoa);
        end   
        xtagAoA=cos(thetaAoA*pi/180).*DAOA;
        ytagAoA=sin(thetaAoA*pi/180).*DAOA;
   end %if AoAon 
    
   figure(gcf+1)
   subplot(311), plot(filenum,LE,'k*');hold on;plot(filenum,LE2,'rd');plot(filenum,LE3,'s','color',[.5 .5 .5]);hold off;
   title('Leading Edge Matrix')
   xlabel('Scan #')
   grid on;
   subplot(312), plot(distancedata,LE,'k*');hold on;plot(distancedata,LE2,'rd');plot(distancedata,LE3,'s','color',[.5 .5 .5]);hold off;
   if disttype==1
      xlabel('Distance (feet)');
   elseif disttype==2
      xlabel('Distance (meters)');
   end 
   grid on;
   subplot(313), plot(EbNeff_scan',LE,'k*');hold on;plot(EbNeff_scan',LE2,'rd');plot(EbNeff_scan',LE3,'s','color',[.5 .5 .5]);hold off;
   xlabel('Scan SNR (Vpeak^2/sigma^2)')
   grid on;
   
   if AoAon==1 & distfile==1
   	
      figure(gcf+1)
      plot(filenum,DoAtruth*1000,'k*');hold on;plot(filenum,DoA*1000,'ro');plot(filenum,(DoA*1000)-(DoAtruth*1000),'bd');hold off;
      %axis([1 nrdatafiles 0 30])
   	  DoAfig=gcf;
      title('DoA Calculation versus Truth')
   	  xlabel('Scan #')
      ylabel('DoA (ps)') 
      legend('DoA Truth','DoA Calculated','Error')
      grid
       
      figure(gcf+1)
      plot(filenum,thetaREAL,'k*');hold on;plot(filenum,thetaAoA,'ro');plot(filenum,thetaAoA-thetaREAL,'bd');
      for bb=1:length(thetaREAL)
         if NLOS(bb)==1
            plot(filenum(bb),thetaAoA(bb)-thetaREAL(bb),'mx','linewidth',2)
         end
      end   
      hold off;
      axis([1 max(filenum) -90 90])
      if min(xtag)<0
         axis([1 max(filenum) -180 180])
      end   
   	title('AoA Calculation')
      xlabel('Scan #')
      ylabel('AoA (degrees)') 
      legend('Truth','AoA Calculated','Error')
      grid
      
      figure(gcf+1)
      plot(filenum,distancedata,'k*');hold on;plot(filenum,DAOA,'ro');plot(filenum,(distancedata)-(DAOA),'bd');hold off;
      %axis([1 nrdatafiles 0 30])
   	  title('DoA Calculated Distance versus Truth')
        xlabel('Scan #')
        if disttype==1
           ylabel('Distance to Tag (ft)') 
        elseif disttype==2
           ylabel('Distance to Tag (m)')
        end   
        legend('Truth','Calculated','Error')
      	grid
      
      
      figure(gcf+1)
      plot(RXcoord(1,1),RXcoord(1,2),'kd',RXcoord(2,1),RXcoord(2,2),'kd',RXcoord(3,1),RXcoord(3,2),'r.')
      hold on;
      colorstring=['b','r','g','m','k'];
      bb=0;
      for kk=1:nrdatafiles
         bb=bb+1;
         plot([RXcoord(3,1) xtag(kk)],[RXcoord(3,2) ytag(kk)],'*:','color',colorstring(bb)) %truth data
        	plot([RXcoord(3,1) xtagAoA(kk)],[RXcoord(3,2) ytagAoA(kk)],'o-','color',colorstring(bb)) %AoA calculated
         if bb==5
            bb=0;
         end   
      end   
      hold off
      grid on;
      if disttype==1
        	xlabel('Distance (feet)');
        	ylabel('Distance (feet)');
   	elseif disttype==2
        	xlabel('Distance (meters)');
        	ylabel('Distance (meters)');
      end 
      title('Position Error Based on Single AoA Reader')  
      %coordlimit=ceil(max(distancedata))+5;
      %axis([-5 coordlimit -coordlimit coordlimit])
      %axis([-2 12 -6 6])
      
      figure(gcf+1)
      plot(RXcoord(1,1),RXcoord(1,2),'rd','linewidth',3)
      hold on;
      plot(RXcoord(2,1),RXcoord(2,2),'rd','linewidth',3)
      plot(RXcoord(3,1),RXcoord(3,2),'r.')
      thetaDIF=abs(thetaAoA-thetaREAL);
      %xtagp=[xtag-.5 xtag-.5 xtag+.5 xtag+.5];%xtagp=[xtagp;xtagp(length(xtag),:)];
      %ytagp=[ytag-.5 ytag+.5 ytag+.5 ytag-.5];%ytagp=[ytagp;ytagp(length(ytag),:)];
      %thetaDIFp=[thetaDIF' thetaDIF' thetaDIF' thetaDIF'];%thetaDIFp=[thetaDIFp;thetaDIFp(length(thetaDIF),:)];
      if disttype==1
          spacer=.5;
      elseif disttype==2
          spacer=.5/3.28;
      end
      for ww=1:length(xtag)
         xtagp=[xtag(ww)-spacer xtag(ww)+spacer;xtag(ww)-spacer xtag(ww)+spacer];
         ytagp=[ytag(ww)-spacer ytag(ww)-spacer;ytag(ww)+spacer ytag(ww)+spacer];
         thetaDIFp=[thetaDIF(ww) thetaDIF(ww);thetaDIF(ww) thetaDIF(ww)];
         pcolor(xtagp,ytagp,thetaDIFp)
         if NLOS(ww)==1
            plot(xtag(ww),ytag(ww),'g*','linewidth',1.5)
         end   
      end   
      hold off
      grid on;
      cmin=0;  %*minimum* error in feet (dark blue)
      cmax=5;%max(max(angleDIFF));
      caxis([cmin cmax]) %sets the max and min shading colors pcolor
      %colormap(jet(512))
      colorbar
      if disttype==1
        	xlabel('Distance (feet)');
        	ylabel('Distance (feet)');
   	elseif disttype==2
        	xlabel('Distance (meters)');
        	ylabel('Distance (meters)');
      end 
      title('Angular Error Based on Single AoA Reader')  
      %coordlimit=ceil(max(distancedata))+5;
      %axis([-5 coordlimit -coordlimit coordlimit])
      %axis([-2 12 -7 7])
      axis equal
      
      figure(gcf+1)
      plot(filenum,LEAoA,'r*',filenum,PEAK1time,'rd',filenum,DIF1,'ro');
      %plot(filenum,DIF1*1000,'ro');
      hold on;
      plot(filenum,LE_2,'b*',filenum,PEAK2time,'bd',filenum,DIF2,'bo');
      %plot(filenum,DIF2*1000,'bd');
      hold off;
      %axis([1 max(filenum) -90 90])
   	title('LE to Peak')
      xlabel('Scan #')
      ylabel('Time (ns)') 
      legend('LEAoA','PEAK1time','DIF1','LE_2','PEAK2time','DIF2')
      %legend('DIF1','DIF2')
      grid
      
      figure(gcf+1)
      %plot(filenum,LEAoA,'r*',filenum,PEAK1time,'rd',filenum,DIF1,'ro');
      plot(filenum,DIF1*1000,'ro');
      hold on;
      %plot(filenum,LE_2,'b*',filenum,PEAK2time,'bd',filenum,DIF2,'bo');
      plot(filenum,DIF2*1000,'bd');
      hold off;
      %axis([1 max(filenum) -90 90])
   	title('LE to Peak')
      xlabel('Scan #')
      ylabel('Time (ps)') 
      %legend('LEAoA','PEAK1time','DIF1','LE_2','PEAK2time','DIF2')
      legend('DIF1','DIF2')
      grid
      
        
  	end %if AoAon==1 & distfile==1
else
   startLE=0;
   stopLE =0;
   LE=0;
   LE2=0;
   LE3=0;
   LEAoA=0;
   LE_2=0;
   LE_2truth=0;
   DoAfig=gcf;
   DoA=ones(nrdatafiles,1);
   DoAtruth=ones(nrdatafiles,1);
   PEAK1=0;
   PEAK2=0;
   thetaAOA=0;
   thetaREAL=0;
   NLOS=0;
   thetaAoA=0;
   templatestart=0;
   
end   %if LEDon==1


