function [starttime, endtime, envelope, noiselvl,choice,glitchflag,noisestart,stepup]= ...
   calc_times(scanfile,scanwave,t, startthreshhold, timeperpt, endthreshhold,step,windowlength)

% startend.m
%
% operation:
%   finds the beginning wavefront and ending wavefront

%Check to see if noise preceeding lock point is corrupted by a multipath, 
%if so, use end of scan to get calculation of noise
noiselim=5;
glitchflag=0;
scanfile; %what is the point of this variable 
numlook=round(3/timeperpt); %look at first 3 ns
noiselvla=std(scanwave(1:numlook));
noiselvlb=std(scanwave(length(scanwave)-numlook*2:length(scanwave)-numlook));
if noiselvla < 2*(noiselvlb)
   noiselvl=noiselvla;
   choice=1;
else  
   noiselvl=noiselvlb;
   choice=2;
end   


% artificially set values of starttime and endtime
starttime=timeperpt;
endtime=length(scanwave)*timeperpt;

% find when ambient noise level is surpassed by threshhold of standard deviation - this is starttime
for k=1:length(scanwave)
   if abs(scanwave(k))>startthreshhold*noiselvl
      starttime=k*timeperpt;
      break;
   end %if
end %k 
	if k==length(scanwave)
   	%message=['Warning: startthreshhold set too high for scan #',num2str(scanfile), '. Will be reduced by 1/2']
   	%pause;
   	startthreshhold=startthreshhold/2;
   	for k=1:length(scanwave)
   		if abs(scanwave(k))>startthreshhold*noiselvl
      		starttime=k*timeperpt;
      		break;
   		end %if
		end %k 
   end %if
   if k==length(scanwave)
   	%message=['Warning: startthreshhold still set too high for scan #',num2str(scanfile), '. Will be set to level of noise']
   	%pause;
   	startthreshhold=1;
      starttime=10;
   end   
      


% now update noise level
	if choice==1
      choice;
      
      % now update noise level but only if starttime is more than 5 ns into scan
      
    if starttime>=8
         shift=round(6/timeperpt);
         noiselvl=std(scanwave(1:round(starttime/timeperpt)-shift));
         noisestart=starttime-timeperpt*shift;
         %Limit noise calculation to first 10 ns
    else noisestart>=noiselim
            noisestart=noiselim;
            noiselvl=std(scanwave(1:round(noisestart/timeperpt)));
         end   
      elseif starttime>=2 
         shift=round(1/timeperpt);
         noiselvl=std(scanwave(1:round(starttime/timeperpt)-shift));
         noisestart=starttime-timeperpt*shift;
      end 
  	if choice==2
      choice;  
      noiselvl=std(scanwave(length(scanwave)-400:length(scanwave)));
      noisestart=(length(scanwave)-400)*timeperpt;
	end   

   

% create envelope, which plots standard deviation of approximately 1 nS windows
envelope=zeros(1,length(scanwave));
interval=round(windowlength/timeperpt);
for k=1:interval:length(scanwave)-interval
   envelope( k:k+interval-1)=ones(1,interval)*std(scanwave(k:k+interval-1));
end %k   

% find when ambient noise level is reached again after main pulse - this is TENTATIVE endtime

%Find point ~185 ns behind lock point to step up endthreshold due to correlation sidelobes
breaktime=185;
if breaktime>=max(t)
   breaktime=max(t)-(starttime+1);
end   

for bb=1:1:length(t)
   if t(bb)>=starttime+breaktime
      stepup=bb;
      break
   else
      stepup=0;
   end   
end

for k=length(envelope):-1:round(starttime/timeperpt)+10
   if k>=stepup
   	if envelope(k)>step*endthreshhold*noiselvl
      	endtime=k*timeperpt;
      	break;
      end 
   elseif k<stepup
      if envelope(k)>endthreshhold*noiselvl
      	endtime=k*timeperpt;
      	break;
      end 
   end %if k   
end %for k   

% now create TENTATIVE delay profile to check that at least 5% of the cumulative energy has appeared
%   within 10 nS of the initial pulse.
sw=scanwave.^2;
y=cumsum( sw( round(starttime/timeperpt) : round(endtime/timeperpt) ));
y=y/sum( sw( round(starttime/timeperpt) : round(endtime/timeperpt ) ));
y=[ y ; ones(length(scanwave)-length(y), 1) ];

if y(round(10/timeperpt))<0.05
   scanfile;
   glitchflag=1;
   oldstarttime=starttime;
   
   % This means that initial point was wrong.  
   % find new ambient noise level - look at noise 3 to 6 nS after starttime
   noiselvl=std(scanwave(   round(starttime/timeperpt+3/timeperpt) : ...
      round(starttime/timeperpt+6/timeperpt)   ));

   % find when ambient noise level is surpassed by threshhold of standard deviation - this is starttime
   for k= round((starttime+5)/timeperpt) :length(scanwave)
      if scanwave(k)>startthreshhold*noiselvl*1.5
         newstarttime=k*timeperpt;
         break;
      else   
         newstarttime=oldstarttime;
      end %if
   end %k   
   
   % now update noise level
   starttime=newstarttime;
   if starttime>=8
         shift=round(6/timeperpt);
         noiselvl=std(scanwave(1:round(starttime/timeperpt)-shift));
         noisestart=starttime-timeperpt*shift;
         %Limit noise calculation to first 10 ns
         if noisestart>=noiselim
            noisestart=noiselim;
            noiselvl=std(scanwave(1:round(noisestart/timeperpt)));
         end   
   else 
         shift=round(1/timeperpt);
         noiselvl=std(scanwave(1:round(starttime/timeperpt)-shift));
         noisestart=starttime-timeperpt*shift;
   end   
   newstarttime;
end %if   

starttime;  % delete these - djh
endtime;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% find at 100 nS intervals after first arriving pulse, zero values from 15 ns before to 25 nS after
numintervals=floor((length(scanwave)*timeperpt - starttime)/100);
if(numintervals>0)
   for k=1:numintervals
      startpoint=round(starttime/timeperpt + k*100/timeperpt - 15/timeperpt);
      if (startpoint<1)
         startpoint=1;
      end; %if
      endpoint=round(starttime/timeperpt + k*100/timeperpt + 25/timeperpt);
      if (endpoint > length(envelope))
         endpoint=length(envelope);
      end; %if
      %whos envelope;
      startenvelope=startpoint-40;
      endenvelope=startpoint-5;
      m=mean(envelope(startenvelope:endenvelope));
      envelope(startpoint-1:endpoint)=ones(1,2+endpoint-startpoint)*m;     
   end %k
end % if 

% find when ambient noise level is reached again after main pulse
for k=length(envelope):-1:round(starttime/timeperpt)+10
   if k>=stepup
   	if envelope(k)>step*endthreshhold*noiselvl
      	endtime=k*timeperpt;
      	break;
      end 
   elseif k<stepup
      if envelope(k)>endthreshhold*noiselvl
      	endtime=k*timeperpt;
      	break;
      end 
   end %if k     
end %k   
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%