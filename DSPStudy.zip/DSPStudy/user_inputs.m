
function [meas_sys,datadirectory,direct,datafilename,nrdatast,nrdatasp,maxnumberoffiles]=...
    user_inputs(setrange,chanimpulse,maindirectory,maxnumberoffiles);

if setrange==1
   disp(' ')
   disp('setrange=1, output file will not be written. . .')
   disp(' ')
elseif chanimpulse==0
   disp(' ')
   disp('chanimpulse=0, output file will not be written. . .')
   disp(' ') 
end   

set(0,'DefaultTextInterpreter','none');  % turn TeX interpreter off




disp('>> Enter the Measurement System Used');
meas_sys=input('    (choices are PAD, DSO, or EVK) \n','s');

disp('>> Enter the name of the folder where the data is stored,');
disp(['     (the program is currently set to look in ' maindirectory, ' )'])
datadirectory=input(' ','s');
datadirectory=[maindirectory datadirectory];
if datadirectory(length(datadirectory))~='\'
    datadirectory=[datadirectory '\'];
end    
direct=pwd;

%  Enter the base name of the data files.  E.g.  if files are file1.dat - file20.dat,
%     entry would be 'file'
disp('>> Enter the base name of the data files.');
datafilename=input('    (for example, files scan1.dat thru scan8.dat, entry is "scan" ).\n','s');

%disp('>> Enter the number of peaks considered for path loss calculations');
%correlators=input('(1-20)  ');
     

if setrange==1
	disp('>> Enter the datafile number to begin reading in.');
	nrdatast=input('(Note: 1st two scans are always read-in) \n');

	disp('>> Enter the datafile number to stop reading in.');
   nrdatasp=input('\n');
   maxnumberoffiles=nrdatasp;
else
   nrdatast=0;
   nrdatasp=100;
   maxnumberoffiles=maxnumberoffiles;
end