% stdan.m
close all
clear


%********************************************************************************
%User Defined Parameters
%offdB=0;
ver='Rel_11'; %Matlab Version
chan_threshdB=20; %CHAN rms threshold
threshdBpre=15;%chan_threshdB;
step=3;			%SCAN rms step-up factor
CLEANNit=200;
rakes=4;
tempwidth=1.7;%Width of CLEAN template in ns


hRX=5;
hTX=5;
maindirectory=['c:\analysis\'];
%maindirectory=['q:\propagation\data\'];

scandisp		    =  1;% 0=three per figure, 1=Compared with Channel Impulse, 2=off
   tstart       =  0;
   tstop        =100;%1=maximum window of scan file (ns)
   zoomon		 =  0;
  
setrange        =  1
chooseLED		 =	 2;
P300stuffon     =  1;
antheightadj    =  0;
normscans		 =  1;
attenoff		    =  0; %Controls accounting for attenuation recorded in scan files
filterscans		 =  0; %Controls filtering 0=Remove DC Offset, 1=FIR filter
showunfiltered  =  0;
showenvelope	 =  0; %Shows envelope superimposed on scan  
pauseon			 =  0;
lockon			 =  0;
lockinterp		 =  0;  %1=on,0=off NOT USED CURRENTLY (this provides some filtering on lock data)
LEDon			    =  0;
chanimpulse		 =  1;
chandisp		    =  1;
if scandisp==2
   chandisp=0;
end   
RAKEplot			 =  0;
scatdisplay		 =  0;
ratiodisplay    =  0;
calcspec        =  0;
distinmeters	 =  0;
narrowcompare   =  0;%do comparison to 2.4 GHz 
spectrumdisp	 =  0;
if spectrumdisp==1
   calcspec=1;
end   
powcap			=	0;%shows how much energy of the total waveform is captured per correlator
writeoutput		=	1;
writeCIR 		=  1;
writeWAVE		=	1;    % whether or not waveform scan data is output in output file
   if setrange==1
      writeoutput=1
   end   

showtimes		=	0;

corr1=1;
corr2=2;
corr3=4;
correlators=corr1;
maxnumberoffiles=550;



%********************************************************************************
timestatplot   =  0;
SNRon				=	0;
oldstuffon		=	0;
stuffon			=	0;
envelopeshow	=	0;	if envelopeshow==1
   							scandisp=1;
							end   
wave_envelope	=	0;%Old Figure 1 of Wave and Envelope                     
BERshow			=	0;
if scandisp==1 & chandisp==0 & envelopeshow==0
   scandisp=0;
end   
printallfigure	=	0;
%pause

if setrange==1
   disp(' ')
   disp('setrange=1, output file will not be written. . .')
   disp(' ')
elseif chanimpulse==0
   disp(' ')
   disp('chanimpulse=0, output file will not be written. . .')
   disp(' ') 
end   

set(0,'DefaultTextInterpreter','none');  % turn TeX interpreter off
% 
% operation:
%     Analyzes propagation data collected
%     with the Time Domain propagation instrumentation system.
%
% usage: (from MATLAB command line)   stdan
%
% dependencies:   file  masterlist.txt    contains various parameters.  stored in same directory as stdan.m
%                          distance.txt      contains distances between transmitter and receiver
%                                                   of run of interest.
%                                            should be stored in same directory as input data files
%
% inputs:(from command line)
%            data directory      (string)             directory input data files are in
%            data file name      (string)             non-repeating portion of file name.
%            number of files     (integer)            number of data files in run
%
% outputs:(to command line)
%
%   

% based on: 
%   Rachel Reinhardt, Paul Withington, David J. Hall
%   Time Domain
%   October 1999


% The purpose of this set of files is to 
%  Read the data into the computer.
%
%		The data will be in two matrices:
%			lockmatrix:	the results from the lock (data) channel.
%			scanmatrix: the results from the scan channel.
%
%	A later program will need to know the duration of the transmitted Gaussian
%		monocycle, in nanoseconds:
%
%	Window the data to smooth out transitions at the ends of
%		the data file to minimize artificial spectral features.
%
%		Parameters:
%			windowsize = the number of points at the beginning
%				and end to smooth.
%			smoothingfactors = value of parameter to use for
%				exponential smoothing.

%Constants from Legacy Software
pulseduration=0.5;
windowsize=100;
smoothingfactor=0.95;
maxfreqdisplay=6;
maxpeaks=5;
startthreshhold=10;
endthreshhold=1.7;


%maxpeaks=corr3;

%	Provide names of directories containing m-files and data; plus the name of
%		the data file. NB: Assumes that there is a ".dat" suffix on the filename.
%
disp('>> Enter the Measurement System Used');
meas_sys=input('    (choices are PAD or DSO) \n','s');
disp('>> Enter the name of the folder where the data is stored.');
datadirectory=input('    (if the data is in "c:\\analysis\\data\\", type "data\\" ) \n','s');
datadirectory=[maindirectory datadirectory];
direct=pwd;

%  Enter the base name of the data files.  E.g.  if files are file1.dat - file20.dat,
%     entry would be 'file'
disp('>> Enter the base name of the data files.');
datafilename=input('    (for example, files scan1.dat thru scan8.dat, entry is "scan" ).\n','s');

%disp('>> Enter an offset for offdB');
%offdB=input('(Note: default is 0) \n');
%if isempty(offdB)==1
   offdB=0;
%end   

%disp('>> Enter the number of peaks considered for path loss calculations');
%correlators=input('(1-20)  ');
timenow=cputime;      


%	Now tell the program how many files to read into the computer. 
%		NB This assumes that the first file suffix is '1' and it steps in increments of
%		1, e.g., scan1.dat, scan2.dat, scan3.dat, etc.
%
if setrange==1
	disp('>> Enter the datafile number to begin reading in.');
	nrdatast=input('(Note: 1st two scans are always read-in) \n');

	disp('>> Enter the datafile number to stop reading in.');
   nrdatasp=input('\n');
   maxnumberoffiles=nrdatasp;
else
   nrdatast=0;
   nrdatasp=100;
end


%disp('>> Enter the number of Bits/Scan');
%bitperscan=input('   .\n');

		%If structure supports old scanning reciever (marine radios)
		%ReceiverType=0;
		%while (ReceiverType~=1 & ReceiverType~=2)
		%ReceiverType=2;%input('Enter type of scanning receiver, 1=old, 2=new PADS');
		%end   
		%if ReceiverType==1
   	%	[scanmatrix, lockmatrix, distancedata, timeperpt, nrdatapts]=...
      %		newreader(datadirectory, datafilename, nrdatafiles);
   	%	%if bitsperscan==8
		%	correctionfactor=-163.70+(8.775+9.1875)/2; % correction factor for antenna losses, etc.
   	%	%elseif bitsperscan==16   
   	%	%correctionfactor=-163.70+(8.775+9.1875)/2; % correction factor for antenna losses, etc.   
		%elseif ReceiverType==2
      nrdatafiles=100;
   disp(' ');
   disp(' ');
   disp('Reading data files. . .');
   if meas_sys=='PAD' | meas_sys=='pad' 
      [scanmatrix, lockmatrix, distancedata, BERmatrix, SNRmatrix, timeperpt,nrdatapts,distfile,...
            nrdatafiles,VGA,txatt,rxatt,deltatflag,deltat,disttype]=padsread(datadirectory, ...
            datafilename,attenoff,maxnumberoffiles,hTX,hRX,antheightadj,offdB);
         AoAon=0;
         timebaseoff=zeros(1,nrdatafiles);
   elseif  meas_sys=='DSO' | meas_sys=='dso'
      [AoAon,RXcoord,TXcoordrel,scanmatrix, lockmatrix, distancedata, BERmatrix, SNRmatrix, ...
            timeperpt,nrdatapts,distfile,nrdatafiles,VGA,txatt,rxatt,deltatflag,deltat,disttype,...
            timebaseoff]=dscoperead(datadirectory, datafilename,attenoff,maxnumberoffiles,hTX,hRX,...
         	antheightadj,offdB);
      		xtag=TXcoordrel(:,1);
      		ytag=TXcoordrel(:,2);
   else   
      disp(' ');
		disp(' ');
   	disp('>>No scan files found; Check path and/or file name and restart program.');
   	disp('>>press <CTRL>-C to end program');
   	disp(' ');
   	disp(' ');
   	pause;      
   end   
   correctionfactor=-163.70+(8.775+9.1875)/2;   % CAVEAT - need this number ASAP!!! Must be calibrated before power curves O.K.
   Ts=timeperpt*1e-9;
   
  
   %Force to meters
   if distinmeters==1
      if disttype==1
   		distancedata=distancedata/3.28;
   		disttype=2;
      end
   end   
%Shorten Matrices based upon chosen time-window      
   if tstop==1
      tstop=nrdatapts*timeperpt;
   end
   looklength=round(tstop/timeperpt);
   if looklength > nrdatapts
      looklength=nrdatapts;
      tstop=nrdatapts*timeperpt;
   end   	      
   nrdatapts=looklength;
   scanmatrix=scanmatrix(1:looklength,:);
   lockmatrix=lockmatrix(1:looklength,:);
   %pause
   if showtimes==1
      timeread=cputime-timenow
   end
 %Shorten Matrices based on data file numbers  
   if setrange==1
   	%Always read in 1st two scans
 		if nrdatast<=2
    		nrdatast=3;
 		end   
   	nrdatafiles=nrdatasp-nrdatast+1+2;
   	scanmatrix=[scanmatrix(:,1:2) scanmatrix(:,nrdatast:nrdatasp)];
 		lockmatrix=[lockmatrix(:,1:2) lockmatrix(:,nrdatast:nrdatasp)];
 		distancedata=[distancedata(1:2) distancedata(nrdatast:nrdatasp)];
       if AoAon==1
        xtag=[xtag(1:2);xtag(nrdatast:nrdatasp)];
        ytag=[ytag(1:2);ytag(nrdatast:nrdatasp)];
       end 
   	BERmatrix=[BERmatrix(1:2);BERmatrix(nrdatast:nrdatasp)];
    
 		SNRmatrix=[SNRmatrix(1:2,:);SNRmatrix(nrdatast:nrdatasp,:)];
    
   	VGA=[VGA(1:2) VGA(nrdatast:nrdatasp)];
 		txatt=[txatt(1:2) txatt(nrdatast:nrdatasp)];
 		rxatt=[rxatt(1:2) rxatt(nrdatast:nrdatasp)];
      deltat=[deltat(1:2) deltat(nrdatast:nrdatasp)];
      timebaseoff=[timebaseoff(1:2) timebaseoff(nrdatast:nrdatasp)];
      
      filenum=[1 2 nrdatast:nrdatasp];
   else
      filenum=[1:nrdatafiles];
      nrdatasp=nrdatafiles;
   end   
   
%Read in P300 Flag data
[los,stud,pol,genloc,walls]=p300read(nrdatafiles,datadirectory,setrange,nrdatast,nrdatasp);


%	Create a vector with the time at each data point (in nanoseconds)
pointtime=timeperpt*(0:nrdatapts-1)';

%	NB: This will have to be modified to combine data files if the scan
%	was done piecemeal to scan over a long period, e.g., more than
%	400 ns.
%
if deltatflag==0 & filterscans==1
	disp(' ');
	disp(' ');
	disp('Filtering data files. . .');
	[m n]=size(scanmatrix);
   
	filteredscanmatrix=zeros(m,n);
	mfactor=(timeperpt/0.0305);   
	B=fir1(80,[0.05*mfactor min(0.2*mfactor,.99)]);
	A=1;% create filter to eliminate both DC component and high frequency noise
	for whichfile=1:nrdatafiles
      temp=filter(B,A,[ones(100,1)*scanmatrix(1,whichfile);scanmatrix(:,whichfile)]);  % filter out DC and high frequency noise- temporary column
     	filteredscanmatrix(:,whichfile)= [temp(142:length(temp), 1); zeros(41,1) ];  % shift filtered signal by 41 samples
                               % to make up for time shift in FIR filter
	end; % whichfile
elseif deltatflag==1  
   filteredscanmatrix=scanmatrix;
   disp(' ')
   disp(' ')
   disp('>> Sampling time resolution different for different files')
   %disp('>> No noise filtering will be performed')
   disp('   All calculations will be made with step size of last scan in series')
   disp('    ( this will skew time step of other files )')
   disp('>> Press Space Bar to continue')
   pause
elseif filterscans==0
   %Only remove DC OFFSET
   for qq=1:nrdatafiles
      filteredscanmatrix(:,qq)=scanmatrix(:,qq)-mean(scanmatrix(:,qq));
   end   
end

% FIGURE 1

timetimes=cputime;
if wave_envelope==1
   figure(gcf)
end
disp(' ');
disp(' ');
disp('Calculating time statistics. . .');
stmatrix=zeros(1,nrdatafiles);
etmatrix=zeros(1,nrdatafiles);
counter=0;
for k=1:nrdatafiles
   counter=counter+1;
   p=counter;
   if rem(p,10)==0
   %if p==10 | p==20 | p==30 | p==40 | p==50 | p==60 | p==70 | p==80 | p==90 | p==100 | p==110 | p==120 | p==130 | p==140 | p==150 | p==160 | p==170 | p==180 | p==nrdatafiles
      p
   end    
   scan=filteredscanmatrix(:,k);%scanmatrix(:,k);
   lock=lockmatrix(:,k);
   t=pointtime;%[0:length(filteredscanmatrix) ]*timeperpt;	
   
   [starttime, endtime, errorcode, envelope,noiselvl,choice,glitchflag,noisestart,stepup]=startend(k,scan,t, lock, startthreshhold , timeperpt, endthreshhold,lockinterp,step);%1.4
   if wave_envelope==1
     starttime;
     endtime;
  end
  glitchflags(k)=glitchflag;
  choices(k)=choice;
  noiselevel(k)=noiselvl;
  stmatrix(k)=starttime;
  etmatrix(k)=endtime;
  ntmatrix(k)=noisestart;
  envel(k,:)=envelope;
  startlevel(k,:)=[endthreshhold*noiselvl*ones(1,stepup) step*endthreshhold*noiselvl*ones(1,length(envelope)-stepup)];
  
   
   if wave_envelope==1
      
   	subplot(2,1,1);
      plot(t,scan);
      %hold on;
      %plot(t,startlevel(k),'r')
      %hold off;
      stop=500;
   	if stop>max(t)
      	stop=max(t);
   	end  
   	axis([0 stop -max(max(scanmatrix)) max(max(scanmatrix))]);
   	%axis([0 stop -max(max(scanmatrix(:,counter))) max(max(scanmatrix(:,counter)))]);
   	xlabel('time - nS');
   	ylabel('amplitude');
   	title(strcat('Scan Waveform (Scan # ',filenum(counter), ' of #',num2str(nrdatafiles), ')'));
   	%title('scan of waveform');
   	x1location=round(0.25*length(t)*timeperpt);
   	x2location=round(0.80*length(t)*timeperpt);
   	y1location=round(0.5*max(scan));
   	%text(x1location,y1location,cellstr(datadirectory));
   	%text(x2location,y1location,strcat(cellstr(datafilename),cellstr(num2str(k)), '.dat'));
	   
   	subplot(2,1,2)
   	plot(t,envelope)
   	hold on;
   	xlabel('time - nS');
   	ylabel('amplitude')
   	title('standard deviation of intervals of waveform');
   
    
   	axis([0 stop 0 max(max(scanmatrix))]);
   	%axis([0 stop 0 max(max(scanmatrix(:,counter)))]);
   	
   	subplot(2,1,2);
   	plot(t,startlevel(k,:),'r')
   	x1location=round(0.25*length(t)*timeperpt);
   	x2location=round(0.80*length(t)*timeperpt);
   	y1location=round(0.5*max(envelope));
   	%text(x1location,y1location,cellstr(datadirectory));
   	%text(x2location,y1location,strcat(cellstr(datafilename),cellstr(num2str(k)), '.dat'));
   	if pauseon==1
      	pause;
   	end   
   	hold off;
   end %end wave_envelope   
end % k 
if showtimes==1
   timetimes=cputime-timetimes
end


% FIGURE 2
firstlobe_time=firstlobe(filteredscanmatrix, stmatrix, etmatrix, timeperpt);
maxlobe_time=highestpulse(filteredscanmatrix, timeperpt);

%Determine if maxlobe more than 1.5 ns behind firstlobe
pointer=[];
for bb=1:1:nrdatafiles
   if maxlobe_time(bb) > firstlobe_time + 1.5 
      pointer=[pointer bb];
   end
end   

if timestatplot==1
   if stuffon==1
   	figure(gcf+1)
	else
   	figure(gcf)
	end
	plot(1:nrdatafiles,ntmatrix,'ms:')
	hold on;
	plot(1:nrdatafiles,maxlobe_time,'go-',1:nrdatafiles,firstlobe_time,'bx-.')
	plot(1:nrdatafiles,stmatrix,'r*-',1:nrdatafiles,etmatrix,'kd-.')
	hold off;
	ple=['Time Arrival of Peak Lobe with Respect to First Lobe (' datafilename ')_' date];
	title(ple);
	%text(18,5, [datadirectory] );
	xlabel('scan number');
	ylabel('time (nS)');
	legend('Noise Calc','Peak Lobe','First Lobe','RMS Start','RMS End');
	grid on;
	axis([0 nrdatafiles+1 0 tstop]);%max(etmatrix)+10]);
	%if (nrdatafiles>40)
	%   axis([0 nrdatafiles -20 80]);
	%end;   

	if pauseon==1
   	pause;
   end
end %timestatplot   
 

% FIGURE 3

if writeoutput==1
   threshholdsmatrix=threshholds(filteredscanmatrix, timeperpt);
   valuefirstlobe=zeros(1,nrdatafiles);
	for k=1:nrdatafiles
   	valuefirstlobe(k)=filteredscanmatrix( round(maxlobe_time(k)/timeperpt) ,k);
	end % k 
end   
if oldstuffon==1
     
   figure(gcf+1);
	subplot(2,1,1);
	plot(valuefirstlobe./threshholdsmatrix(1,:),'b*-')
	%axis([ 0 40 0 200]);
	%if (nrdatafiles>40)
   axis([0 nrdatafiles 0 100]);
	%end; 
	title('highest lobe divided by standard deviation of ambient noise');
	%text(18, 20, [datadirectory] );
	xlabel('scan number');
	ylabel('ratio');
	grid on;
	subplot(2,1,2);
	plot(valuefirstlobe./threshholdsmatrix(2,:),'b*-')
	%axis([ 0 40 0 20]);
	%if (nrdatafiles>40)
   	axis([0 nrdatafiles 0 20]);
	%end; 
	title('highest lobe divided by standard deviation of entire waveform');
	xlabel('scan number');
	ylabel('ratio');
	grid on;
	if pauseon==1
		pause;
	end   
end %end oldstuffon

%Calculating Peaks ********************************************************************
disp(' ');
disp(' ');
disp('Calculating peaks. . .');
timepeaks=cputime;
tops=toppeaks(filteredscanmatrix,maxpeaks,.65,pulseduration,timeperpt);%.65
for m=1:nrdatafiles
	tpeakpts(:,m)=tops(:,2*m-1)-maxlobe_time(m)/timeperpt;  % subtract out delay for each run relative to maxlobe of each run
	tpeakval(:,m)=tops(:,2*m);
end
if showtimes==1
   timepeaks=cputime-timepeaks
end   
   %pause



% FIGURE 4
if oldstuffon==1
   figure(gcf+1); 
end

for whichfile=1: nrdatafiles  
   if oldstuffon==1
   subplot(2,1,1);
   [mm, nn]=size(filteredscanmatrix);
   pointtime=timeperpt*(0: mm-1)';   
   
   plot(pointtime,filteredscanmatrix(:,whichfile),'b-',...
        tpeakpts(1:8,whichfile)*timeperpt+maxlobe_time(whichfile),zeros(8,1),'rx'  );
     
   axis( [ 0 max(pointtime) min(min(filteredscanmatrix(:,:))) max(max(filteredscanmatrix(:,:))) ]);
   
   title(strcat('Filtered Scan Channel Data (Scan # ',num2str(filenum(whichfile)), ')'));
   %text(30,round(0.5*max(filteredscanmatrix(:,whichfile))),cellstr(datadirectory));
   %text(60,round(0.5*max(filteredscanmatrix(:,whichfile))),strcat(cellstr(datafilename),cellstr(num2str(whichfile)), '.dat'));
	xlabel('Time (ns)');
   ylabel('Amplitude');
   grid on;
            
   subplot(2,1,2);
   beginpoint=round((maxlobe_time(whichfile)-5)/timeperpt);
   if beginpoint<1 
      beginpoint=1;
   end;      
   [m n]=size(scanmatrix);
   endpoint=round((maxlobe_time(whichfile)+5)/timeperpt);
   if endpoint>m
      endpoint=m;
   end;      
   plot(pointtime(beginpoint:endpoint),filteredscanmatrix(beginpoint:endpoint,whichfile),'b-',...
      pointtime(beginpoint:endpoint),scanmatrix(beginpoint:endpoint,whichfile)-mean(scanmatrix(beginpoint:endpoint,whichfile)),'k:',...
      tpeakpts(1:8,whichfile)*timeperpt+maxlobe_time(whichfile),zeros(8,1),'rx'   );
   axis([round(beginpoint*timeperpt) round(endpoint*timeperpt) ...
         min(min(filteredscanmatrix(:,:))) max(max(filteredscanmatrix(:,:))) ]);
   
	title(strcat('Scan Channel Data (Scan # ', num2str(filenum(whichfile)), ')'));
	xlabel('Time (nS)');
   ylabel('Amplitude');
   legend('filtered','unfiltered');
   grid on;
   if pauseon==1
   	pause;   
   end   
   end  %end oldstuffon
end; % whichfile


% plot spectrum of scan channel - both filtered and unfiltered.
% FIGURE 5
if oldstuffon==1
figure(gcf+1); 
for whichfile=1: 1 %was nrdatafiles-  djh  
   subplot(2,1,1);
   f=abs(fft(scanmatrix(:,whichfile)));
   f(1)=0;
   freq=1/(timeperpt*1e-9)*(0:length(f)-1)/length(f);
   %freq=0: 1/(length(f)*timeperpt*1e-9): 1/(2*timeperpt*1e-9);
   for k=1:length(freq)
      if freq(k)>=maxfreqdisplay*1e9
         lim=k;
         break;
      else 
         lim=k;
      end %if
   end %k
   
   plot(freq(1:lim),f(1:lim),'b');
   axis([0 maxfreqdisplay*1e9 min(f(1:lim)) max(f(1:lim))]);
   title(strcat('Spectrum of Scan Channel Data (Scan # ', num2str(filenum(whichfile)), ')'));
   %text(2e9,0.5*max(f) ,cellstr(datadirectory));  
   %text(4e9,0.5*max(f),strcat(cellstr(datafilename), num2str(whichfile), '.dat'));
	xlabel('Freq (Hz)');
   ylabel('Amplitude');
   grid on;

   subplot(2,1,2);
   temp=filter(B,A,scanmatrix(:,whichfile));  % filter out DC and high frequency noise.
   f=abs(fft(temp));
   plot(freq(1:lim),f(1:lim),'b');
   axis([0 maxfreqdisplay*1e9 min(f(1:lim)) max(f(1:lim))]);
	title(strcat('Spectrum of FILTERED Scan Channel Data (Scan # ', num2str(filenum(whichfile)) ,')'));
	xlabel('Freq (Hz)');
   ylabel('Amplitude');
   grid on;
   if pauseon==1
      pause;
   end   
end; % whichfile
end %oldstuffon







%   Lock Channel   ************************************************************************
bigsnrmatrix=zeros(6,nrdatafiles);
if SNRon==1
	disp(' ');
	disp(' ');
	disp('Calculating Lock Channel. . .');
	timedolock=cputime;
	numframes=ceil(nrdatafiles/3);
	counter=0;
	for k=1:numframes
   	if lockon==1
   		figure(gcf+1);
		end
      for l=1:3
         if lockon==1
   			subplot(3,1,l)
			end      	
         counter=counter+1;
         whichfile=counter;
         p=counter;
         if rem(p,10)==0
         %if p==10 | p==20 | p==30 | p==40 | p==50 | p==60 | p==70 | p==80 | p==90 | p==100 | p==110 | p==120 | p==130 | p==140 | p==150 | p==160 | p==170 | p==180 | p==nrdatafiles
      		p
   		end 
         if (counter <= nrdatafiles)
            if lockon==1
               plot(lockmatrix(:,whichfile),'.');
   				title(strcat('Lock Channel - raw noise measurement (Scan # ', num2str(filenum(whichfile)), ')'));
   				%text(500,0,[cellstr(datadirectory)]);  text(3000,0,strcat(cellstr(datafilename), num2str(whichfile), '.dat'));
      			axis([0 length(lockmatrix) -max(max(lockmatrix(:,counter)))-.1*max(max(lockmatrix(:,counter))) max(max(lockmatrix(:,counter)))+.1*max(max(lockmatrix(:,counter)))]);
      			ylabel('Amplitude');
               grid on;
            end
            [snr, sig, nos,output0]=dolockchannel(lockmatrix(:,whichfile),lockinterp,counter);
            bigsnrmatrix(:,whichfile)=snr';  
  	 			bigsig(:,whichfile)=sig'; 
            bignos(:,whichfile)=nos';
            locknoise(:,whichfile)=output0';   
         end; %if
      end; %l
      if lockon==1
      	xlabel('ramp number');
      end   
      if pauseon==1
   		pause;
		end 
  	end; %k
  	if showtimes==1
     	timedolock=cputime-timedolock
  	end
end %SNRon==1

%Set distance limits and calculate Eb/No from scans
if max(distancedata)<=100
   maxxpoint=ceil(max(distancedata)/10)*10;
else
  	maxxpoint=ceil(max(distancedata)/100)*100;
end    
if min(distancedata)>=10
   minpoint=10;
else
  	minpoint=0;
end 
[snrinmatrix, signalmatrix, noisematrix]=findsnrin(scanmatrix,ntmatrix,timeperpt);

%   SNR vs Distance   ********************************************************************
	%   Plot the following SNR's :
	%   (1)  SNR read from file
	%   (2)  SNR calculated from lock/data channel
	%   (3)  SNR calculated from scan waveform (unfiltered)
scannumber=filenum;   
if SNRon==1   
   figure(gcf+1)%filtered
   subplot(1,1,1);
   aveSNR=(SNRmatrix(:,1)+SNRmatrix(:,2))/2;
   if distfile==0
      xlabel('scan number');
      plot(distancedata,aveSNR,'b*',...
        distancedata,SNRmatrix(:,3),'gd',...
        distancedata,snrinmatrix' ,'rs');
     axis([0 max(distancedata)+1 0 max(snrinmatrix)+6]);
   else
   	%semilogx  
      plot(distancedata,aveSNR,'b*',...
        distancedata,SNRmatrix(:,3),'gd',...
        distancedata,snrinmatrix' ,'rs');
     axis([minpoint maxxpoint 0 max(snrinmatrix)+6]);
     if disttype==1
        xlabel('Distance (feet)');
     elseif disttype==2
        xlabel('Distance (meters)');
     end   
   end  
   legend('Pos/Neg Ave','Composite','Scan',3)
   text(min(distancedata),max(snrinmatrix)+2.5,'Scan SNR will be higher due to integration of bits/scan'); 
   %plot(distancedata,[SNRmatrix bigsnrmatrix(1:2,:)' bigsnrmatrix(5,:)' snrinmatrix'],'*');
   %legend('positive,file','negative,file','composite,file','positive-calculated','negative-calculated','composite-calculated','calculated-scan ch.',3)
   %adj=snrinmatrix(1)-SNRmatrix(1,3)-1;
   %plot(distancedata',[SNRmatrix(:,3) snrinmatrix'-adj],'*-');legend('PAD Composite (lock dependent/shows radio performance)','Calculated from Scan (lock independent/shows propagation)',3)
   grid on;
   %axis([0 max(scannumber) 0 max(snrinmatrix)+5]);
	ple=['SNR vs Distance, (SNR=v^2\sigma^2)' date];
	title(ple);
   
   ylabel('SNR (dB)');
   if pauseon==1
      pause;
   end 
end %SNRon==1

%   Signal & Noise Power vs Distance   ****************************************************
	if timestatplot==0 & stuffon==0 & oldstuffon==0
      figure(gcf)
   else
      figure(gcf+1)
   end      
   %off=max(noisematrix)-max(max(bignos(1:2,:)));
if SNRon==1   
   off=noisematrix(1)-(bignos(1,1));
   %Normalize to Signal level of Scan #1
   off2=-(signalmatrix(1)+correctionfactor);
   plot(1:nrdatafiles,  bigsig(1,:)'+off+correctionfactor+off2, 'bd', ...
   1:nrdatafiles,  signalmatrix'+correctionfactor+off2, 'rs', ...
   1:nrdatafiles,  bignos(1,:)'+off+correctionfactor+off2 ,'bx', ...
   1:nrdatafiles,  noisematrix'+correctionfactor+off2,'r+');
   xlabel('scan number');
   axis([0 max(nrdatafiles) min(min(bignos(1,:)))+correctionfactor-5+off2 max(max(signalmatrix),max(bigsig(1,:)))+correctionfactor+5+off2]);
   hold on;  
   plot(pointer,(signalmatrix(pointer))'+correctionfactor+off2, 'gs')
   hold off;  
  	legend('lock signal','scan signal','lock noise','scan noise','multipath peaks',3)
	ple=['Signal & Noise Level (noise levels scaled to overlay) (' datafilename ')_' date];
	title(ple);
   grid on;
   ylabel('Relative signal level (dB)');
   if pauseon==1
     	pause;
   end 
else
   off2=-signalmatrix(1);
   plot(1:nrdatafiles,  signalmatrix'+off2,'rs',1:nrdatafiles,noisematrix'+off2,'r+');
   xlabel('scan number');
   axis([0 max(nrdatafiles) floor(min(min(noisematrix+off2))/10)*10-5 ceil(max(max(signalmatrix+off2))/10)*10+5]);
   legend('scan signal','scan noise',3)
	ple=['Signal & Noise Level (' datafilename ')_' date];
	title(ple);
   grid on;
   ylabel('Relative signal level (dB)');
end %SNR==1

%   PDF vs Distance   ********************************************************************
if oldstuffon==1
figure(gcf+1);
for m=1:8   % was maxpeaks -djh
   [histogram,x]=hist(timeperpt.*tpeakpts(m, :));
   %   plot(x,histogram,'b');
   hist(histogram,x);
   axis([-20 80 0 15]);    
   title(strcat('Time of Arrival of Lobe #' ,num2str(m) ));
   %text(30,3,cellstr(datadirectory));  
	xlabel('Time of Arrival (ns)');
	ylabel('pdf');

   hold on;
   mu=mean(timeperpt.*tpeakpts(m,:));
   sd=std(timeperpt.*tpeakpts(m,:));
     
   x=-20:.1:80;
   y=zeros(length(x),1);
   for k=1:length(x)
      y(k)=maxpeaks*exp(-(x(k)-mu)^2/(2*sd^2))/(sqrt(2*pi*sd));
   end  %k      
   plot(x,y,'r-.');
   axis([-20 80 0 15]);
     
   if pauseon==1
      pause;
   end   
   
   hold off;
end; %m
end  %end stuffon


%   Pathloss vs Distance   ********************************************************************

timepathloss=cputime;
if distfile==1 %Only do this if distance file present
	figure(gcf+1);
 	% correction factor for antenna losses, etc.
 	colorstring=['b-','m-','k-','g-'];
 
	%********************************************************************
	%By letting power=0 and removing loops, calculate only with main peak.
	%********************************************************************
	
	%find energy using peak points with this number of correlators
     
   powersum=zeros(1,nrdatafiles);
   	%for l=1:correlators
      %	powersum=powersum+tpeakval(l,:).^2;
      %end;

      
   powersum1=powersum;
   	for l=1:corr1
      	powersum1=powersum1+tpeakval(l,:).^2;
      end;
   powersum2=powersum;
   	for l=1:corr2
      	powersum2=powersum2+tpeakval(l,:).^2;
      end;
   powersum3=powersum;
   	for l=1:corr3
      	powersum3=powersum3+tpeakval(l,:).^2;
      end;     
        
   %Reference to 1st scan, not Absolute power in dBm
   	refnorm=powersum1(1);
      refd=distancedata(1);
      powersum1=powersum1/refnorm;
      powersum2=powersum2/refnorm;
      powersum3=powersum3/refnorm;
      
   	freeref=-20*log10(distancedata/min(distancedata));
      relpower=(20*log10(sqrt(powersum1)));
      difpow=-(freeref-relpower);
           
      %Linear 1/r^n Curve Fit   
      distdat1=min(distancedata):(max(distancedata)-min(distancedata))/20 : 2*max(distancedata);   
      %if nrdatafiles==86
      %   distancedata=distancedata(41:86);
      %   powersum1=powersum1(41:86);
      %   powersum2=powersum2(41:86);
      %   powersum3=powersum3(41:86);
      %end   
      
      [m b]=linefit(log10(distancedata), 20*log10(sqrt(powersum1)) );
      slope=m;
      intercept=b;
      n=m/-10;
      yhattilde1= 10.^( (m.*log10(distdat1)+b)./20    );  % this is the un-logarithmic curve fit 
       
      [m b]=linefit(log10(distancedata), 20*log10(sqrt(powersum2)) );
      yhattilde2= 10.^( (m.*log10(distdat1)+b)./20    );
      	%end 
      
      [m b]=linefit(log10(distancedata), 20*log10(sqrt(powersum3)) );
      yhattilde3= 10.^( (m.*log10(distdat1)+b)./20    ); 
      
      %Plot Reference Lines
		
      r2=-20*log10(distdat1/min(distdat1));
      
      r3=-30*log10(distdat1/min(distdat1));
      %semilogx
      plot(distdat1,r2,'r-^') 
      hold on;
      %plot(distdat1,r3,'g-s') 
    
      
  %Least Squares Curve fit to 1/d^n
		x=20*log10((sqrt(powersum1)));
        d=distancedata;
        counter=0;
      Nstart=1.0;
      Ninc=0.05;
      Nstop=5;
  		for N=Nstart:Ninc:Nstop
         counter=counter+1;  
         y=sqrt(1./d.^N);
         %Normalize to 1 meter
         if disttype==1
            y1=sqrt(1./(refd).^N);
         elseif disttype==2
            y1=sqrt(1./(refd).^N);
         end   
         y=20*log10((y./y1));
         Fa(counter)=sum( (x-y).^2 );         
      end
      N=Nstart:Ninc:Nstop;
      [q,i]=min(Fa);
      N=N(i);
      y=sqrt( 1 ./ (distdat1.^N) );
      %Normalize to 1 meter
      if disttype==1
         y1=sqrt(1./(refd).^N);
      elseif disttype==2
         y1=sqrt(1./(refd).^N);
      end   
      ya=20*log10((y./y1));
      
    %Plot 1/d^N curve fit
      plot((distdat1),(ya),'b')
      %figure(157)
      %N=Nstart:Ninc:Nstop;
      %plot(N,Fa)
      %hold on;
      %plot(N(i),Fa(i),'r*')
      %hold off;
      %pause
      %QQ
      
  %Least Squares Curve fit to exp(-Kd)/d^2
  		x=20*log10((sqrt(powersum1)));
        d=distancedata;
        counter=0;
      Kstart=-0.1;
      Kinc=0.001;
      Kstop=0.25;
  		for K=Kstart:Kinc:Kstop
         counter=counter+1;  
         y=sqrt(exp(-K*d)./d.^2);
         %Normalize to 1 meter
         if disttype==1
            y1=sqrt(exp(-K*(refd))./(refd).^2);
         elseif disttype==2
            y1=sqrt(exp(-K*refd)./refd.^2);
         end
         y=20*log10((y./y1));
         F(counter)=sum( (x-y).^2 );         
      end
      K=Kstart:Kinc:Kstop;
      [q,i]=min(F);
      K=K(i);
      y=sqrt( exp(-K*distdat1) ./ (distdat1.^2) );
      %Normalize to 1 meter
      if disttype==1
            y1=sqrt(exp(-K*(refd))./(refd).^2);
      elseif disttype==2
            y1=sqrt(exp(-K*refd)./refd.^2);
      end
      y=20*log10((y./y1));
      
      %figure(157)
      %K=Kstart:Kinc:Kstop;
      %plot(K,F)
      %hold on;
      %plot(K(i),F(i),'r*')
      %hold off;
      %pause
      %QQ
  %Plot exp(-Kd)/d^2 curve fit
  		plot(distdat1,(y),'m') 
      
  
  %Plot the actual data points         
     plot((distancedata),20*log10(sqrt(powersum1)),'k*');
  %Plot the multipath peak data points         
     plot((distancedata(pointer)),20*log10(sqrt(powersum1(pointer))),'g*');    
      
  %Set Axes, Notes
		n=round(n*100)/100;      
  		%ple1=[('n=') num2str(n)];
      ple1a=[('N=') num2str(N)];  
      if disttype==1
         %ple2=[('K_f =') num2str(K)];
         Km=3.28*K;
         Km=round(Km*100)/100;
         Lw=-10*log10(exp(-Km)); 
         Lw=round(Lw*100)/100;
         ple2=[('Km=') num2str(Km) ', Lw=' num2str(Lw)];
      elseif disttype==2
         Km=K;
         Km=round(Km*100)/100;
         Lw=-10*log10(exp(-Km));   
        	ple2=[('Km=') num2str(Km) ', Lw=' num2str(Lw)];
     	end 
      Lw=-10*log10(exp(-K));  
      
      pleoffdB=['offdB=', num2str(offdB)];
   	legend('Free Space',ple1a,ple2,'data','multipath peaks',pleoffdB)
  		smaller=min(-30*log10([max(distancedata)/min(distancedata)]),20*log10(sqrt(powersum1))-3);
      miny=(ceil(min(smaller+0)/3)*3-3);
      axis([minpoint maxxpoint miny 3]); %axis([0 3.0 -100 -20]);
      vecor=[];
      for gt=miny:3:3
         vecor=[vecor gt];
      end 
      set(gca,'yTick',vecor)
      grid on;
		if disttype==1
        xlabel('Distance (feet)');
     elseif disttype==2
        xlabel('Distance (meters)');
     end 
		ylabel('Relative Received Power (dB)');
		if disttype==1
			ple=[('Calculated from data: N=') num2str(N) ', Km =' num2str(Km) ' (calculated assuming ',num2str(corr1), ' peak)_' date];
   	elseif disttype==2
      	ple=[('Calculated from data: N=') num2str(N) ', Km =' num2str(Km) ' (calculated assuming ',num2str(corr1), ' peak)_' date];
   	end
   	title(ple);
      hold off;
	
	if pauseon==1
   	pause;
   end
else%distfile
   powersum1=(10.^(signalmatrix'+off2+correctionfactor)./20)';
   difpow=zeros(1,length(distancedata));
   freeref=zeros(1,length(distancedata));
   relpower=zeros(1,length(distancedata));
end %distfile
if showtimes==1
   timepathloss=cputime-timepathloss
end   
   
% find RMS delay spread  ********************************************************************
rms=zeros(1,nrdatafiles);
for k=1:nrdatafiles
   [rmsdelay,RMS_delay]=rmsdelay(  filteredscanmatrix(round(stmatrix(k)/timeperpt):round(etmatrix(k)/timeperpt),k)...
      ,timeperpt);
   rms(k)=rmsdelay;
   rms2(k)=RMS_delay;
end %k 

	if distfile==0;
      figure(gcf+1)
      rmsplot=gcf;
      plot(scannumber,rms,'bx');
      %legend('rms delay','relative noiselevel')
      ple=['RMS Delay Spread vs Distance (Threshold=' num2str(endthreshhold) '*noise)_' date];
   	title(ple);
   	xlabel('scan number');
   	ylabel('RMS Delay (ns)');
   	grid on;
   	axis([min(scannumber) max(scannumber) 0 max(10,max(rms)+10)])
   	rms;
   elseif distfile==1
      figure(gcf+1)
      rmsplot=gcf;
      %semilogx
      plot(distancedata,rms,'bx');
   	ple=['RMS Delay Spread (threshold=' num2str(endthreshhold) '*noise)_' date];
   	title(ple);
   	if disttype==1
        xlabel('Distance (feet)');
     	elseif disttype==2
        xlabel('Distance (meters)');
     	end 
   	ylabel('RMS Delay (ns)');
      
      hold on;
      [m b]=linefit((distancedata),rms);
      yhattilderms= m.*(distancedata)+b  ;  % this is the un-logarithmic curve fit 
      hold on;
      %Move curve fit to after rmsdelay2 so that legend makes sense
      if chanimpulse==0
         plot(distancedata,yhattilderms,'b');
      end   
      hold off;
      
      grid on;
   	axis([minpoint maxxpoint 0 max(10,max(rms)+5)])
      
      
   end   

   
% LED Waveforms **********************************************************
	if AoAon==1
      LEDon=1;
      %AoA Starting Constants
  		A=sqrt( ( RXcoord(2,1)-RXcoord(1,1) )^2 + ( RXcoord(2,2)-RXcoord(1,2) )^2 + ( RXcoord(2,3)-RXcoord(1,3) )^2); 							%antenna separation in feet
  		template_sizens= tempwidth; 	%Same as CLEAN Template ns
  		cable_delayns  = 8  ; 	%ns
	end   
if LEDon==1
   disp(' ');
	disp(' ');
	disp('Calculating leading edge. . .');
   for k=1:nrdatafiles
      %if rem(k,10)==0
      %	k
      %end
      LEDcount=filenum(k);
      AoAcount=filenum(k);
      if AoAon==1
         AoAcount
      else   
         LEDcount
      end   
      %LED Variable Inputs (Correlate,Envelope,Difference,Peak) **********
      c=3e8; %meters per second
		feet_per_meter=100/2.54/12;
		cftps=feet_per_meter*c/1e12; %feet per picosecond
		nsperft = 1/cftps/1000;%1.0167;
            
      step=10; %step=round(.768/(Ts/1e-9));  		%step in ~.768 ns; was 16 for Ts=48 ps
      cumsamps=20;%round(1/(Ts/1e-9));  %cumulate over 1 ns; was 21 for Ts=48 ps
      peakdiv=5;				  			%peak=peak/peakdiv;
      addtoLE=round(.384/(Ts/1e-9));					%add ~.38 ns; was 8 for Ts=48 ps
      
      %LED2 Variable Inputs (Correlate,Envelope,Mean Threshold) **********
      step2=step;
      meantimes2=2;	%envelopeMEAN=envelopeMEAN*meantimes;
      
      %LED3 Variable Inputs (Time-reverse Correlate,Peak/Mean Threshold) ***********
      threshdiv3=40;   %threshold=(peakvalue-meanvalue)/threshdiv + meanvalue;
      
      [leadingedge]=LED(nrdatapts,filteredscanmatrix(:,k),step,Ts,cumsamps,peakdiv,addtoLE,k);
      [leadingedge2]=LED2(nrdatapts,filteredscanmatrix(:,k),step2,Ts,meantimes2,k);
      [leadingedge3,gamma]=LED3(nrdatapts,filteredscanmatrix(:,k),Ts,threshdiv3,k);
      	PAR(k)=gamma; %Peak to mean ratio
      %if AoAon==1
      %   LEstop=cable_delayns
      %   LEDscanmatrix(:,k)=[filteredscanmatrix(1:LEstop,k) zeros(1,length(filteredscanmatrix(:,k)-AoAstop))];
      %end       
      LE(k)=leadingedge*timeperpt;
      LE2(k)=leadingedge2*timeperpt;
      LE3(k)=leadingedge3*timeperpt;
      
      if chooseLED==0
         leadingedgeAoA=leadingedge;
      elseif chooseLED==2
         leadingedgeAoA=leadingedge2;
      elseif chooseLED==3
         leadingedgeAoA=leadingedge3;
      end   
      LEAoA(k)=leadingedgeAoA*timeperpt;
      
      %Use LED to set starting point of CLEAN template
      if k==1
      	templatestart=leadingedgeAoA;
      end
      
      if AoAon==1
         %Assumes first measurement is 1 meter boresight (AoA=0 degrees)
         [aoa,correlation,Start,End,Template,cable_delayns,firstpeak,secondpeak] = AOA(nrdatapts, filteredscanmatrix(:,k), ...
            leadingedgeAoA, template_sizens, cable_delayns, A,k,nsperft,Ts);
         PEAK1(k)=firstpeak*timeperpt;
         PEAK2(k)=secondpeak*timeperpt;
         LE_2(k)=aoa*timeperpt;
         DIF1(k)=PEAK1(k)-LEAoA(k);
         DIF2(k)=PEAK2(k)-LE_2(k);
         if distfile==1
            DoA(k)=abs(LEAoA(k)-LE_2(k))-cable_delayns;
         	Ans = A * nsperft;
        	%Plane Wave Assumption
         	   thetaAoA(k)=asin(DoA(k)/Ans).*180/pi; %degrees
         	%Calculate TAG position with AoA angle and known distance
         	   xtagAoA(k)=cos(thetaAoA(k)*pi/180)*distancedata(k);
               ytagAoA(k)=sin(thetaAoA(k)*pi/180)*distancedata(k);
            %Truth Data
                thetaREAL(k)=atan( ytag(k)/(xtag(k)+1e-12) ).*180/pi;
                DoAtruth(k)=Ans*sin(thetaREAL(k)*pi/180);
                LE_2truth(k)=LEAoA(k)+DoAtruth(k)+cable_delayns;
          end      
      end
   end
   figure(gcf+1)
   subplot(311), plot(filenum,LE,'k*');hold on;plot(filenum,LE2,'rd');plot(filenum,LE3,'s','color',[.5 .5 .5]);hold off;
   title('Leading Edge Matrix')
   xlabel('Scan #')
   grid on;
   subplot(312), plot(distancedata,LE,'k*');hold on;plot(distancedata,LE2,'rd');plot(distancedata,LE3,'s','color',[.5 .5 .5]);hold off;
   if disttype==1
      xlabel('Distance (feet)');
   elseif disttype==2
      xlabel('Distance (meters)');
   end 
   grid on;
   subplot(313), plot(snrinmatrix',LE,'k*');hold on;plot(snrinmatrix',LE2,'rd');plot(snrinmatrix',LE3,'s','color',[.5 .5 .5]);hold off;
   xlabel('Scan SNR (Vpeak^2/sigma^2)')
   grid on;
   
   if AoAon==1 & distfile==1
   	
      figure(gcf+1)
      plot(filenum,DoAtruth*1000,'k*');hold on;plot(filenum,DoA*1000,'bd');hold off;
      %axis([1 nrdatafiles 0 30])
   	  title('DoA Calculation versus Truth')
   	  xlabel('Scan #')
      ylabel('DoA (ps)') 
      legend('DoA Truth','DoA Calculated')
      grid
       
      figure(gcf+1)
      plot(filenum,thetaREAL,'k*');hold on;plot(filenum,thetaAoA,'ro');plot(filenum,thetaAoA-thetaREAL,'bd');hold off;
      axis([1 max(filenum) -90 90])
   	  title('AoA Calculation')
      xlabel('Scan #')
      ylabel('AoA (degrees)') 
      legend('Truth','AoA Calculated','Error')
      grid
      
      
      figure(gcf+1)
      plot(RXcoord(1,1),RXcoord(1,2),'kd',RXcoord(2,1),RXcoord(2,2),'kd',RXcoord(3,1),RXcoord(3,2),'r.')
      hold on;
      colorstring=['b','r','g','m','k'];
      bb=0;
      for kk=1:nrdatafiles
         bb=bb+1;
         plot([RXcoord(3,1) xtag(kk)],[RXcoord(3,2) ytag(kk)],'.:','color',colorstring(bb)) %truth data
        	plot([RXcoord(3,1) xtagAoA(kk)],[RXcoord(3,2) ytagAoA(kk)],'.-','color',colorstring(bb)) %AoA calculated
         if bb==5
            bb=0;
         end   
      end   
      hold off
      grid on;
      if disttype==1
        	xlabel('Distance (feet)');
        	ylabel('Distance (feet)');
   	elseif disttype==2
        	xlabel('Distance (meters)');
        	ylabel('Distance (meters)');
      end 
      title('Position Error Based on Single AoA Reader')  
      %coordlimit=ceil(max(distancedata))+5;
      %axis([-5 coordlimit -coordlimit coordlimit])
      %axis([-2 12 -6 6])
      
      figure(gcf+1)
      plot(RXcoord(1,1),RXcoord(1,2),'kd',RXcoord(2,1),RXcoord(2,2),'kd',RXcoord(3,1),RXcoord(3,2),'r.')
      hold on;
      thetaDIF=abs(thetaAoA-thetaREAL);
      xtagp=[xtag-.5 xtag-.5 xtag+.5 xtag+.5];%xtagp=[xtagp;xtagp(length(xtag),:)];
      ytagp=[ytag-.5 ytag+.5 ytag+.5 ytag-.5];%ytagp=[ytagp;ytagp(length(ytag),:)];
      thetaDIFp=[thetaDIF' thetaDIF' thetaDIF' thetaDIF'];%thetaDIFp=[thetaDIFp;thetaDIFp(length(thetaDIF),:)];
      pcolor(xtagp,ytagp,thetaDIFp) %truth data
      hold off
      grid on;
      cmin=0;  %*minimum* error in feet (dark blue)
      cmax=5;%max(max(angleDIFF));
      caxis([cmin cmax]) %sets the max and min shading colors pcolor
      %colormap(jet(512))
      colorbar
      if disttype==1
        	xlabel('Distance (feet)');
        	ylabel('Distance (feet)');
   	  elseif disttype==2
        	xlabel('Distance (meters)');
        	ylabel('Distance (meters)');
      end 
      title('Angular Error Based on Single AoA Reader')  
      %coordlimit=ceil(max(distancedata))+5;
      %axis([-5 coordlimit -coordlimit coordlimit])
      axis([-2 12 -7 7])
      
      figure(gcf+1)
      plot(filenum,LEAoA,'r*',filenum,PEAK1,'rd',filenum,DIF1,'ro');
      %plot(filenum,DIF1*1000,'ro');
      hold on;
      plot(filenum,LE_2,'b*',filenum,PEAK2,'bd',filenum,DIF2,'bo');
      %plot(filenum,DIF2*1000,'bd');
      hold off;
      %axis([1 max(filenum) -90 90])
   	title('LE to Peak')
      xlabel('Scan #')
      ylabel('Time (ns)') 
      legend('LEAoA','PEAK1','DIF1','LE_2','PEAK2','DIF2')
      %legend('DIF1','DIF2')
      grid
      
      figure(gcf+1)
      %plot(filenum,LEAoA,'r*',filenum,PEAK1,'rd',filenum,DIF1,'ro');
      plot(filenum,DIF1*1000,'ro');
      hold on;
      %plot(filenum,LE_2,'b*',filenum,PEAK2,'bd',filenum,DIF2,'bo');
      plot(filenum,DIF2*1000,'bd');
      hold off;
      %axis([1 max(filenum) -90 90])
   	title('LE to Peak')
      xlabel('Scan #')
      ylabel('Time (ps)') 
      %legend('LEAoA','PEAK1','DIF1','LE_2','PEAK2','DIF2')
      legend('DIF1','DIF2')
      grid
      
      
      
      
  	end      
end   


%   Scanned Waveforms vs Time   **********************************************************

scanfig=gcf;
if scandisp==0
	numframes=ceil(nrdatafiles/3);
	counter=0;
	for k=1:numframes
   	figure(gcf+1);
      if k==1
         scanfig=gcf;
      end   
   	%subplot(3,1,1),title('SCAN CHANNEL DATA (FILTERED)- time domain');
   	%hold on;
   	for l=1:3
      	%figure(blue);
      	subplot(3,1,l)
      	counter=counter+1; 
      	if (counter <= nrdatafiles)
            
            grid on;
      		if LEDon==1
               plot([LE(counter) LE(counter)],[-1e5 1e5],'LineWidth',2,'color','k')
         		hold on;
         		plot([LE2(counter) LE2(counter)],[-1e5 1e5],':','LineWidth',2,'color','r')
         		plot([LE3(counter) LE3(counter)],[-1e5 1e5],'--','LineWidth',2,'color',[.5 .5 .5])
         		grid off;
               legend('LED0','LED2','LED3')
               text(tstart+1,.5,['PAR= ' num2str(PAR(counter))] );
               if AoAon==1
                  plot([LE_2(counter) LE_2(counter)],[-1e5 1e5],'LineWidth',2,'color','g')
                  plot([LE_2truth(counter) LE_2truth(counter)],[-1e5 1e5],'--','LineWidth',2,'color','m')
                  legend('LED0','LED2','LED3','LE_2','LE_2t')
               end   
      		end  
            
            
            if showunfiltered==1
            	plot(pointtime,scanmatrix(:,counter),'r-')%unfiltered
            end
            hold on;
            if normscans==1
               plot(pointtime,filteredscanmatrix(:,counter)/max(abs(filteredscanmatrix(:,counter))),'b-')%filtered
         		axis([tstart tstop -1 1]); 
            else
               plot(pointtime,filteredscanmatrix(:,counter),'b-')%filtered
         		axis([tstart tstop -max(max(abs(filteredscanmatrix(:,counter))))-.1*max(max(abs(filteredscanmatrix(:,counter)))) max(max(abs(filteredscanmatrix(:,counter))))+.1*max(max(abs(filteredscanmatrix(:,counter))))]); 
            end
            if showenvelope==1
               plot(t,envel(counter,:),'k')
               %legend('Scan','Envelope')
               plot(t,startlevel(counter,:),'r')
               axis([tstart tstop 0 max(max(abs(filteredscanmatrix(:,counter))))+.1*max(max(abs(filteredscanmatrix(:,counter))))]); 
            end   
            if showunfiltered==1
            	axis([tstart tstop -max(max(abs(scanmatrix(:,counter))))-.1*max(max(abs(scanmatrix(:,counter)))) max(max(abs(scanmatrix(:,counter))))+.1*max(max(abs(scanmatrix(:,counter))))]); 
            	legend('Un-Filtered','Filtered')   
            end
            %plot(pointtime,filteredscanmatrix(:,counter),'b-',...
         	%tpeakpts(1:correlators,counter)*timeperpt+maxlobe_time(counter),zeros(correlators,1),'rx'  );
         	peakpt=round((tpeakpts(1:correlators,counter)*timeperpt+maxlobe_time(counter))/timeperpt);
         	plot(tpeakpts(1:correlators,counter)*timeperpt+maxlobe_time(counter),filteredscanmatrix(peakpt,counter),'rx'  );      
            hold off;
            title(strcat('Filtered Scan Channel Data (Scan # ',num2str(filenum(counter)), ')'));
         	ylabel('Amplitude');
         	
         end; %if
   	end; %l
   	xlabel('Time (nS)');
   	if pauseon==1
   		pause;
		end 
   end; %k
   startfig=1000;
   %hold off
elseif scandisp==1
   startfig=gcf+1;
   for k=1:nrdatafiles
      counter=k;
      figure(gcf+1);
      if envelopeshow==1
         subplot(311)
      else   
         subplot(211)
      end   
      grid on;
      if LEDon==1
         plot([LE(counter) LE(counter)],[-1e5 1e5],'LineWidth',2,'color','k')
         hold on;
         plot([LE2(counter) LE2(counter)],[-1e5 1e5],':','LineWidth',2,'color','r')
         plot([LE3(counter) LE3(counter)],[-1e5 1e5],'--','LineWidth',2,'color',[.5 .5 .5])
         grid off;
         legend('LED0','LED2','LED3')
         if AoAon==1
            plot([LE_2(counter) LE_2(counter)],[-1e5 1e5],'LineWidth',2,'color','g')
            plot([LE_2truth(counter) LE_2truth(counter)],[-1e5 1e5],'--','LineWidth',2,'color','m')
            legend('LED0','LED2','LED3','LE_2','LE_2t')
            text(tstart+1,.5,['PAR= ' num2str(PAR(counter))] );
         end
      end   
      
      if showunfiltered==1
         plot(pointtime,scanmatrix(:,counter),'r-')%unfiltered
      end
      hold on;
      if normscans==1
         plot(pointtime,filteredscanmatrix(:,counter)/max(abs(filteredscanmatrix(:,counter))),'b-')%filtered
      	axis([tstart tstop -1 1]); 
      else
         plot(pointtime,filteredscanmatrix(:,counter),'b-')%filtered
      	axis([tstart tstop -max(max(abs(filteredscanmatrix(:,counter))))-.1*max(max(abs(filteredscanmatrix(:,counter)))) max(max(abs(filteredscanmatrix(:,counter))))+.1*max(max(abs(filteredscanmatrix(:,counter))))]); 
      end
      if showenvelope==1
         plot(t,envel(counter,:),'k')
         %legend('Scan','Envelope')
         plot(t,startlevel(counter,:),'r')
         axis([tstart tstop 0 max(max(abs(filteredscanmatrix(:,counter))))+.1*max(max(abs(filteredscanmatrix(:,counter))))]); 
      end 
      if showunfiltered==1
        	axis([tstart tstop -max(max(abs(scanmatrix(:,counter))))-.1*max(max(abs(scanmatrix(:,counter)))) max(max(abs(scanmatrix(:,counter))))+.1*max(max(abs(scanmatrix(:,counter))))]); 
        	legend('Un-Filtered','Filtered')   
      end
            
      %plot(pointtime,filteredscanmatrix(:,counter),'b-',...
      %tpeakpts(1:correlators,counter)*timeperpt+maxlobe_time(counter),zeros(correlators,1),'rx'  );
      peakpt=round((tpeakpts(1:correlators,counter)*timeperpt+maxlobe_time(counter))/timeperpt);
      plot(tpeakpts(1:correlators,counter)*timeperpt+maxlobe_time(counter),filteredscanmatrix(peakpt,counter),'rx'  );      
             
      hold off;
	   title(strcat('Filtered Scan Channel Data (Scan # ',num2str(filenum(counter)), ')'));
      ylabel('Amplitude');
      
	end %k      
end %scandisp


%Plot Envelope ***************************************************************   
   if envelopeshow==1
		%numframes=ceil(nrdatafiles/3);
		counter=0;
		for k=1:nrdatafiles
   		figure(startfig+counter)
   		%blue=gcf+1;
   		%subplot(3,1,1),title('SCAN CHANNEL DATA (FILTERED)- time domain');
   		%hold on;
            subplot(312)
            counter=counter+1;
            if (counter <= nrdatafiles)
              	plot(t,envel(counter,:))
            	hold on;
            	plot(t,startlevel(counter,:),'r')
            	hold off;
            	stop=200;
   				if stop>max(t)
      				stop=max(t);
            	end 
               axis([tstart tstop 0 max(max((1000*ceil(envel(counter,:)/1000))))]);
   				ylabel('Amplitude')
            	title(strcat('Envelope (Scan # ',num2str(filenum(counter)), ')'));
         	end      
  			%xlabel('Time (nS)');
   		if pauseon==1
   			pause;
			end 
		end; %k
		%hold off
	end %envelope

%Calculate Peak to RMS voltage
for bb=1:1:nrdatafiles
   [SpeakV(bb),SrmsV(bb)]=calcrmsV(filteredscanmatrix(:,bb));
end   
SrmsV=SrmsV/SpeakV(1);
SpeakV=SpeakV/SpeakV(1);


%Calculate Actual LOS for P300 measurement setup
if P300stuffon==1
   %Speed of light related stuff
		c=3e8;                          %speed of light, meters per second
		feet_per_meter=100/2.54/12;     %conversion factor
		cftps=feet_per_meter*c/1e12;    %c, in feet per picosecond
		nsperft = 1/cftps/1000;         %distance light travels in one nsec
   tlos=distancedata.*39.36/12*nsperft; %ns
   %for bb=1:length(distancedata)
   %   n=floor( (timebaseoff+100-22-14.8-5.5-tlos) / 104.17 );
   %tcalclos=n.*104.17+22+14.8+5.5+tlos-timebaseoff;
   tcalclos=22+14.8+5.5+tlos - rem(timebaseoff,104.17);
else
   tcalclos=zeros(1,nrdatafiles);
end 

%   Channel Impulse Response vs Time   *****************************************************
%Find starting time of the first scan to eliminate noise from the template
if chanimpulse==1
   timechan=cputime;
   %If not doing LED, use old stmatrix for CLEAN templatestart
   if LEDon==0
      for bb=1:1:length(pointtime)
   		if pointtime(bb)==stmatrix(1)
         	templatestart=bb-8;%The 8 is empirically chosen
   		end
      end
   end   
   disp(' ');
   disp(' ');
   disp('Calculating Channel Impulse Response. . .');
      
%Find Shift time
	[q,i]=max(filteredscanmatrix(:,1));
	shifttime=t(i);
   
   if scandisp==2
     %scandisp=0;
     startfig=100;
   end   
   [CIRout,CIRpeakV,CIRrmsV,Numpeaks,PNratio,RAKEdB,PEAKSused,excessdelay,peakpower,meanexcessdelay,...
       rms2delay,numpaths,peakpowerratio,totpower,relerror,angerror,CIRLOS]=chan_clean(tempwidth,rakes,CLEANNit,...
       distancedata,writeCIR,datafilename,datadirectory,direct,filteredscanmatrix, nrdatafiles, Ts,...
       templatestart,scandisp,startfig,tstart,tstop,shifttime,envelopeshow,chandisp,chan_threshdB,...
       scanfig,normscans,ver,filenum,zoomon,threshdBpre,P300stuffon);
   if showtimes==1
      timechan=cputime-timechan
   end
else
   rms2delay=zeros(1,nrdatafiles);
   numpaths=zeros(1,nrdatafiles);
   peakpowerratio=zeros(1,nrdatafiles);
   totpower=zeros(1,nrdatafiles);
   chan_threshdB=0; 
end %chanimpulse

 
 %Plot RMS Delay spread calculated from Channel Impulse
 if chanimpulse==1
 	fig=gcf;
 	if distfile==0;
      figure(rmsplot)
      hold on;
      plot(scannumber,rms2delay,'r*');
      plot(scannumber,meanexcessdelay,'gd');
      plot(scannumber,excessdelay,'ks');
      hold off;
      legend('Scan calculated','Chan calculated','Mean Excess Delay','Excess Delay')
     	axis([min(scannumber) max(scannumber) 0 max(10,ceil(max(rms)/10)*10+5)])
   	grid on;
   elseif distfile==1
      figure(rmsplot)
      hold on;
      %semilogx
      plot(distancedata,rms2delay,'r*');
      plot(distancedata,meanexcessdelay,'gd');
      plot(distancedata,excessdelay,'ks');
      hold off;
      legend('waveform rms','chan impulse rms','mean excess delay','excess delay')
       
      [m b]=linefit((distancedata),rms2delay);
      yhattilde= m.*(distancedata)+b  ;  % this is the un-logarithmic curve fit 
      
      [m b]=linefit((distancedata),meanexcessdelay);
      yhattildemean= m.*(distancedata)+b  ;  % this is the un-logarithmic curve fit 
      
      [m b]=linefit((distancedata),excessdelay);
      yhattildeexc= m.*(distancedata)+b  ;  % this is the un-logarithmic curve fit 
     
      hold on;
      plot(distancedata,yhattilderms,'b');
      plot(distancedata,yhattilde,'r');
      plot(distancedata,yhattildemean,'g');
      plot(distancedata,yhattildeexc,'k');
      hold off;
      
      grid on;
   	axis([minpoint maxxpoint 0 max( max(10,ceil(max(excessdelay)/10)*10) , ceil(max(rms)/10)*10)])
      ple=['RMS Delay Spread (threshold=' num2str(endthreshhold) '*noise, ', num2str(chan_threshdB), ' dB threshold)_' date];     
      title(ple)
      
   end  
   figure(fig)
 end %if chanimpulse  
 
 %Plot RAKE gain and number of peaks used
	if chanimpulse==1 & RAKEplot==1;
      figure(gcf+1)
      plot(distancedata,RAKEdB,'b*')
      hold on;
      plot(distancedata,PEAKSused,'rs')
      [m b]=linefit((distancedata),RAKEdB);
      yhattilde= m.*(distancedata)+b  ;  % this is the un-logarithmic curve fit 
      hold on;
      %semilogx
      plot(distancedata,yhattilde,'b');
      hold off;
      
      
      title(strcat('RAKE Gain Assuming (',num2str(rakes), ' Available Rakes)_', date));
   	if disttype==1
        xlabel('Distance (feet)');
     	elseif disttype==2
        xlabel('Distance (meters)');
     	end 
      ylabel('RAKE Gain (dB),peaks used');
      legend('RAKE Gain','# Teeth Used')  
      grid on;
      axis([minpoint maxxpoint 0 max(10, ceil(max(max(RAKEdB),max(PEAKSused)))) ])
    end    
   
   
 %Plot the number of scatterers within a given threshold ****************************  
 if chanimpulse==1 & scatdisplay==1
 	if distfile==0;
      figure(gcf+1)
      plot(scannumber,numpaths,'b*');
     	axis([min(scannumber) max(scannumber) 0 max(10,ceil(max(numpaths)/5)*5+5)])
      grid on;
      title(strcat('Number of Scaterers (',num2str(chan_threshdB), ' dB threshold)_', date));
   	xlabel('Scan number');
   	ylabel('Number of Scaterers');
   	grid on;
   elseif distfile==1
      figure(gcf+1)
      %semilogx
      plot(distancedata,numpaths,'b*');
      title(strcat('Number of Scaterers (',num2str(chan_threshdB), ' dB threshold)_', date));
   	if disttype==1
        xlabel('Distance (feet)');
     	elseif disttype==2
        xlabel('Distance (meters)');
     	end 
   	ylabel('Number of Scaterers');
      
      hold on;
      [m b]=linefit((distancedata),numpaths );
      yhattilde= m.*(distancedata)+b  ;  % this is the un-logarithmic curve fit 
      hold on;
      %semilogx
      plot(distancedata,yhattilde,'b');
      hold off;
      
      axis([minpoint maxxpoint 0 max(10,ceil(max(numpaths)/5)*5+5)])
      grid on;
         
      
   end  
end %if chanimpulse   

%Plot the peak power ratio ****************************  
 if chanimpulse==1 & ratiodisplay==1
 	if distfile==0;
      figure(gcf+1)
      plot(scannumber,peakpowerratio,'b*');
     	axis([min(scannumber) max(scannumber) 0 1])
      grid on;
      title('Ratio of peak impulse power to sum of all impulse powers');
   	xlabel('Scan number');
   	ylabel('ratio');
   	grid on;
   elseif distfile==1
      figure(gcf+1)
      %semilogx
      plot(distancedata,peakpowerratio,'b*');
      title('Ratio of peak impulse power to sum of all impulse powers');
   	if disttype==1
        xlabel('Distance (feet)');
     	elseif disttype==2
        xlabel('Distance (meters)');
     	end 
   	ylabel('ratio');
      
      hold on;
      [m b]=linefit((distancedata),peakpowerratio);
      yhattilde= m.*(distancedata)+b  ;  % this is the un-logarithmic curve fit 
      hold on;
      %semilogx
      plot(distancedata,yhattilde,'b');
      hold off;
      
      axis([minpoint maxxpoint 0 1])
      grid on;
         
      
   end  
end %if chanimpulse   


%   Frequency Spectrum vs   ***********************************************************
if calcspec==1
   timespec=cputime;  
   
   disp(' ');
	disp(' ');
   disp('Calculating Spectrum. . .');
   disp(' ');
	%  Remove the DC component from the scan data, do exponential filtering
	scanmatrix=removedc(scanmatrix);

	scanmatrixnew=expgate(scanmatrix,windowsize,smoothingfactor,windowsize,... 
   smoothingfactor,2);
	%
	%	Calculate spectrum
	psdmatrix=spectralanalysis(scanmatrixnew,timeperpt); 
	%Find Max Freq Display
	if isempty(find(psdmatrix(:,1)==maxfreqdisplay))==0
   	toppt=find(psdmatrix(:,1)==maxfreqdisplay);
	else 
   	toppt=max(find(psdmatrix(:,1)<maxfreqdisplay));
	end
   
 %Compare UWB received power to power at 2.4 GHz  
 if narrowcompare==1  
   for y=1:1:length(psdmatrix(1:toppt,1))
      if psdmatrix(y,1)<=2.402
         CWfreq=psdmatrix(y,1);
         CWind=y;
      end
   end
   counter=0;
   for yy=1:nrdatafiles
      counter=counter+1;
      %CWmag(yy)=psdmatrix(CWind,counter+1);
      CWmag(yy)=mean(psdmatrix(CWind-1:CWind+1,counter+1))
   end
   
  	%Interpolate meter Spectrum
     
   psdinterp=resample(psdmatrix(1:toppt,2),1,30);
   finterp=resample(psdmatrix(1:toppt,1),1,30);
   
   figure(gcf+1)
   plot(psdmatrix(1:toppt,1),psdmatrix(1:toppt,2));
   hold on
   plot(finterp,psdinterp,'r'); 
   hold off
   for y=1:1:length(finterp)
      if finterp(y,1)<=2.404
         iCWfreq=finterp(y,1);
         iCWind=y;
      end
   end
   
   if psdinterp(iCWind)>CWmag(1)
      CWmag(1)=psdinterp(iCWind);
   elseif psdinterp(iCWind)<CWmag(1)-3
      CWmag(1)=psdinterp(iCWind);
   end   
   CWmag=CWmag-CWmag(1);
   figure(gcf+1)
   plot(distancedata,20*log10(sqrt(powersum1)),'b*')
   hold on;
   plot(distancedata,CWmag,'r*')
   CWfreq=round(CWfreq*10)/10;
   ple=[num2str(CWfreq),' GHz Sys'];
   legend('UWB',ple)
   ple=['Comparison of UWB to ',num2str(CWfreq),' GHz System'];
   grid on;
   title(ple)
   if disttype==1
        xlabel('Distance (feet)');
     elseif disttype==2
        xlabel('Distance (meters)');
     end 
   ylabel('Relative Received Power (dB)')  
 end %if narrowcompare  
end %if calcspec   
   
if spectrumdisp==1;   
numframes=ceil(nrdatafiles/3);
counter=0;
for k=1:numframes
   figure(gcf+1);
   title('SCAN CHANNEL DATA (UNFILTERED)- frequency domain');
   for l=1:3
      subplot(3,1,l)
      counter=counter+1; 
      if (counter <= nrdatafiles)         
         

		plot(psdmatrix(1:toppt,1),psdmatrix(1:toppt,counter+1));  
		title(strcat('Spectrum of Scanned Data (Scan # ',num2str(filenum(counter)), ')'));
		%text(2.5,0.8*max(psdmatrix(1:toppt,counter+1))+0.2*min(psdmatrix(1:toppt,counter+1)) ,...
      %cellstr(datadirectory));
   	%text(4.5,0.8*max(psdmatrix(1:toppt,counter+1))+0.2*min(psdmatrix(1:toppt,counter+1)),...
      %[datafilename num2str(counter) '.dat']);
		%xlabel(strcat('Frequency (GHz) ------ Equivalent RBW = ', num2str(1000/(2*nrdatapts*timeperpt)), ' MHz'));
		ylabel('PSD (dB)');
		axis([0 max(max(psdmatrix(1:toppt,1))) min(min(psdmatrix(1:toppt,counter+1)))+10 max(max(psdmatrix(1:toppt,counter+1)))+10]); 
		grid on;        
         
%          f=abs(fft(scanmatrix(:,whichfile)));
%          f(1)=0;
%          freq=0: 1/(length(f)*timeperpt*1e-9): 1/(2*timeperpt*1e-9);
%          plot(freq(1:round(nrdatapts/2)),f(1:round(nrdatapts/2)),'b');
%          title(strcat('Scan Channel Spectrum (Scan # ',num2str(counter), ')'));
%          text(8e9,0.5*max(f),cellstr(datadirectory)); ...
%             text(14e9,0.5*max(f),strcat(cellstr(datafilename), num2str(counter), '.dat'));
%			 xlabel('Freq (Hz)');
%   		 ylabel('Amplitude');
%   		 grid on;
   	end; %if
   end; %l
   xlabel(strcat('Frequency (GHz) ------ Equivalent RBW = ', num2str(1000/(2*nrdatapts*timeperpt)), ' MHz'));
   if pauseon==1
   	pause;
	end 
end; %k

	if showtimes==1
      timespec=cputime-timespec
   end   
end %spectrumdisp





%   Cumulative Proportion of Power   ********************************************************************

if stuffon==1
	delayspreadprofile=delayprofile(scanmatrix, stmatrix, etmatrix, timeperpt);
	figure(gcf+1);
	plot(pointtime,delayspreadprofile);
	title('Normalized Delay Spread Profile');
	%text(45,0.15,[datadirectory]);  
	xlabel('time relative to beginning of pulse (nS)');
	ylabel('Cumulative Proportion of Power');
	grid on;
   if pauseon==1
      pause;
   end 
end %stuffon

%   Cumulative Power vs Number of Lobes   *************************************************

if stuffon==1
	tpeakval2=tpeakval.^2;
	powernorm=sum(tpeakval2);
	cumltve_power=cumsum(tpeakval2)./(ones(maxpeaks,1)*powernorm);
	figure(gcf+1);
	plot(cumltve_power);
	grid on;
	title( strcat('Cumulative Power of Top ', num2str(maxpeaks),' Lobes') );
	%text(27,0.15,[datadirectory]);  
	xlabel('number of lobes');
	ylabel('cumulative power');
	axis([ 0 maxpeaks 0 1]);
   if pauseon==1
      pause;
   end 
end %stuffon


%   Captured Power vs Number of Correlators   ************************************************
if powcap==1
figure(gcf+1)
tpeakval2=tpeakval.^2;
powernorm=sum(tpeakval2);
cumltve_power=cumsum(tpeakval2)./(ones(maxpeaks,1)*powernorm);
xx=1:maxpeaks;
kappamatrix=zeros(1,nrdatafiles);
for k=1:1%nrdatafiles   
   kappaout=fitexponential( cumltve_power(:,k)');
   kappamatrix(k)=kappaout;
   y=1-exp(-xx./kappaout);
   plot(xx,10*log10(y),'b-');
   axis([0 maxpeaks 0 1]);
   hold on;
   plot(xx,10*log10(cumltve_power(:,k)),'kx')
   axis([0 maxpeaks -round(-min(10*log10(cumltve_power(:,k)))/10)*10 0]);
   xlabel('Number of correlators');
   ylabel('Energy relative to total');
   grid on;
   %text(15,0.4,cellstr(datadirectory));
   %text(30,0.4,strcat(cellstr(datafilename), num2str(k), '.dat'));
   title(strcat('Implementation Loss vs Number of Correlators (Scan # ',num2str(k), ')'));
   
   if pauseon==1
      pause;
   end   
   
   hold off;
end;   
kappamatrix;
kappamatrix';
end %stuffon

  
%   Write Data to Output File   ***********************************************************
if writeoutput==1 & chanimpulse==1
   [g]=writefile(t,filteredscanmatrix, scanmatrix, nrdatafiles, datafilename, distancedata,SNRmatrix,...
      bigsnrmatrix,snrinmatrix,signalmatrix,noisematrix,correctionfactor,off2,relpower,freeref,difpow,...
      VGA,txatt,rxatt,rms,rms2delay,writeWAVE,datadirectory,direct,disttype,numpaths,peakpowerratio,...
      totpower,peakpower,meanexcessdelay,excessdelay,RAKEdB,PEAKSused,Numpeaks,PNratio,SpeakV,SrmsV,...
      CIRpeakV,CIRrmsV,filenum,chan_threshdB,writeCIR,CIRout,P300stuffon,los,stud,pol,genloc,walls,...
      relerror,angerror,tcalclos,CIRLOS);
elseif writeoutput==1 & chanimpulse==0
   disp(' ')
	disp(' ')
   disp('CIR calculation not performed; output file will not be written ');
end
   
if distfile==1
	disp(' ')
	disp(' ')
	disp('  Scan#    d  FreePL RelPow DifPL VGA  TXatt  RXatt ');
	distancedatap=round(distancedata);   
	[(filenum)' distancedatap' round(freeref)' round(relpower)' round(difpow)' VGA' txatt' rxatt']
	disp(' ')
	disp(' ')
	disp('  Scan#    d  rmsScan rmsChan NumScats ');
   	[(filenum)' distancedatap' round(rms)' round(rms2delay)' round(numpaths)']
else
   disp(' ')
	disp(' ')
	disp('  Scan#    d    VGA  TXatt  RXatt ');
	distancedatap=round(distancedata);   
	[(filenum)' distancedatap' VGA' txatt' rxatt']
	   
end

cd(datadirectory)
if chanimpulse==1 & setrange==0 & distfile==1
   save outputfile hRX hTX distancedata tpeakval relpower freeref difpow rms rms2delay numpaths chanimpulse chan_threshdB pointer disttype offdB endthreshhold peakpowerratio totpower peakpower meanexcessdelay excessdelay RAKEdB PEAKSused Numpeaks PNratio    
   %elseif  setrange==0
%   save outputfile hRX hTX distancedata tpeakval rms chanimpulse pointer disttype offdB endthreshhold
end
cd(direct)

%Print all figures
if printallfigure==1
	for n=1:1:gcf
   	figure(n)
   	print
	end
end

if attenoff==1
 figure(222)
 plot(signalmatrix,'*b')
 hold on;
 plot(noisematrix,'*r')
 grid on;
 hold off;
 title('Scan Channel')
 
 figure(444)
 plot(bigsig(1,:),'*')
 hold on;
 plot(bignos(1,:),'*r')
 grid on;
 hold off;
 title('Lock Channel')
end


elapsedtime=round((cputime-timenow)/30)/2;
%elapsedtime=((cputime-timenow));
ple=[('Elapsed time: ') num2str(elapsedtime) (' minutes')];
disp(' ')
disp(' ')
disp(ple)
disp(' ');
disp(' ');
