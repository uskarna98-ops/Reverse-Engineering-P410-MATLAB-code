function [g]=calc_spectrum(narrowcompare,spectrumdisp,filteredscanmatrix,filenum,nrdatapts,timeperpt,...
                maxfreqdisplay,nrdatafiles,distancedata,powersum1,disttype)
    g=1;


	%Remove the DC component from the scan data, do exponential filtering
	listmeanval=mean(filteredscanmatrix);
    filteredscanmatrix=filteredscanmatrix-ones(size(filteredscanmatrix,1),1)*listmeanval;
    
    %Exponential decrease beginning and end of waveform to zero to suppress high freqeuncy crap in FFT
    x1=100;x2=x1;     %window size at beginning and end of waveform
    dx1=.95;dx2=dx1;  %dampling factor
    x3=size(filteredscanmatrix,1)-x2;
    scanmatrixnew=filteredscanmatrix.*([dx1.^(x1:-1:1),ones(1,x3-x1-1),dx2.^(0:x2)]'*ones(1,size(filteredscanmatrix,2)));
   
    %Calculate spectrum
	ndp=size(scanmatrixnew,1);
    fftlist=fft(scanmatrixnew,2*ndp); %zero pad the FFT
    fullspectrum=20*log10(abs(conj(fftlist(1:ndp+1,:))));
    fullfreq=[0:1/(2*timeperpt*ndp):1/(2*timeperpt)]';
    psdmatrix=[fullfreq fullspectrum];
    
    
    %Find Max Freq Display
	if isempty(find(psdmatrix(:,1)==maxfreqdisplay))==0
   	    toppt=find(psdmatrix(:,1)==maxfreqdisplay);
	else 
   	    toppt=max(find(psdmatrix(:,1)<maxfreqdisplay));
	end
   
    %Compare UWB received power to power at 2.4 GHz ************************************************ 
    if narrowcompare==1  
    for y=1:1:length(psdmatrix(1:toppt,1))
      if psdmatrix(y,1)<=2.402
         CWfreq=psdmatrix(y,1);
         CWind=y;
      end
    end
    counter=0;
    for yy=1:nrdatafiles
      counter=counter+1;
      %CWmag(yy)=psdmatrix(CWind,counter+1);
      CWmag(yy)=mean(psdmatrix(CWind-1:CWind+1,counter+1));
    end
   
   %Interpolate meter Spectrum
   psdinterp=resample(psdmatrix(1:toppt,2),1,30);
   finterp=resample(psdmatrix(1:toppt,1),1,30);
   figure(gcf+1)
   plot(psdmatrix(1:toppt,1),psdmatrix(1:toppt,2));
   hold on
   plot(finterp,psdinterp,'r'); 
   hold off
   title('Interpolated Spectrum')
   ylabel('PSD (dB)');
   xlabel('Frequency (GHz)');
   for y=1:1:length(finterp)
      if finterp(y,1)<=2.404
         iCWfreq=finterp(y,1);
         iCWind=y;
      end
   end
   
   if psdinterp(iCWind)>CWmag(1)
      CWmag(1)=psdinterp(iCWind);
   elseif psdinterp(iCWind)<CWmag(1)-3
      CWmag(1)=psdinterp(iCWind);
   end   
   CWmag=CWmag-CWmag(1);
   figure(gcf+1)
   plot(distancedata,20*log10(sqrt(powersum1)),'b*')
   hold on;
   plot(distancedata,CWmag,'r*')
   CWfreq=round(CWfreq*10)/10;
   ple=[num2str(CWfreq),' GHz Sys'];
   legend('UWB',ple)
   ple=['Comparison of UWB to ',num2str(CWfreq),' GHz System'];
   grid on;
   title(ple)
   if disttype==1
        xlabel('Distance (feet)');
     elseif disttype==2
        xlabel('Distance (meters)');
     end 
   ylabel('Relative Received Power (dB)')  
  end %if narrowcompare  
   

%Display Spectrum ******************************************************************************  
if spectrumdisp==1;   
numframes=ceil(nrdatafiles/3);
counter=0;
for k=1:numframes
   figure(gcf+1);
   title('SCAN CHANNEL DATA - Frequency Domain');
   for l=1:3
      subplot(3,1,l)
      counter=counter+1; 
      if (counter <= nrdatafiles)         
      	plot(psdmatrix(1:toppt,1),psdmatrix(1:toppt,counter+1));  
		title(strcat('Spectrum of Scanned Data (Scan # ',num2str(filenum(counter)), ')'));
		ylabel('PSD (dB)');
		axis([0 max(max(psdmatrix(1:toppt,1))) min(min(psdmatrix(1:toppt,counter+1)))+10 max(max(psdmatrix(1:toppt,counter+1)))+10]); 
		grid on;        
      end; %if
   end; %l
   xlabel(strcat('Frequency (GHz) ------ Equivalent RBW = ', num2str(1000/(2*nrdatapts*timeperpt)), ' MHz'));
end; %k
end %spectrumdisp
