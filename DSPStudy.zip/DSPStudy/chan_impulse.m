function [peakpower,meanexcessdelay,rms2delay,numpaths,threshdB,hout,tout,hpeaksout,tpeaksout,peakpowerratio,totpower]=chan_impulse(distancedata,writeCIR,datafilename,datadirectory,direct,filteredscanmatrix, nrdatafiles,Ts,templatestart, stmatrix, etmatrix,scandisp,startfig,tstart,tstop,shifttime,envelopeshow,chandisp,chan_threshdB,scanfig)
%load chan_impulse scanmatrix nrdatafiles

g=150;
g1=g;
corr=0;
Ts1=Ts;
fs=1/Ts;

numframes=ceil(nrdatafiles/3);
counter=0;
if chandisp==1 
   figure(g)
end   
for k=1:numframes
   if scandisp==0 & chandisp==1 
      figure(g+1);
   elseif scandisp==0 & chandisp==0
      if k==1
         figure(scanfig)
      else
         figure(g+1);
      end   
   end  
      
   for l=1:3
      Ts=Ts1;
      fs=1/Ts;
      if scandisp==0 
         subplot(3,1,l)
      end   
      counter=counter+1; 
      if (counter <= nrdatafiles) 
         
      if rem(counter,10)==0   
        p=counter;
        p
   	end    
         

		reducenoise=1;

		%Template Waveform
      x=filteredscanmatrix(:,1);
      
		%Load Multipath Waveform   
		t=(0:1:length(x)-1)*Ts/1e-9;         
      y=filteredscanmatrix(:,counter);

		if reducenoise==1
       %Cut out beginning and ending noise on x  
       	x(1:templatestart)=0;
       	%Set template as 2 ns after stmatrix
         cutoff=round((stmatrix(1)+2)/Ts/1e9);
         %cutoff=round(etmatrix(1)/Ts/1e9)+20;
                  
      %Cut out beginning noise on y 
      	if stmatrix(counter)>=1
            more=20;
         else
            more=0;
         end   
      	begcut=round(stmatrix(counter)/Ts/1e9)-more;
      	y(1:begcut)=0;
      %Cut out ending noise on y
      	if etmatrix(counter)<=max(t)-1
            more=20;
         else
            more=0;
         end  
      	endcut=round(etmatrix(counter)/Ts/1e9)+more;
%%%%%%Turn off endcut%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%         
         %y=[y(1:endcut)];
			%y=[y;zeros(length(x)-endcut,1)];   
      else
      	cutoff=length(x);
      end  


	%Get waveforms of the same length
	if length(x)>=length(y)
   	%x=x(1:length(y));
   	y=[y;zeros(length(x)-length(y),1)];
	else
   	y=y(1:length(x));
	end   
   

	

	%Truncate any small amount of multipath in Template
	%cutoff assigned above
	los=[x(1:cutoff)];
   los=[los;zeros(length(x)-cutoff,1)];
   
   
   if counter==1 & chandisp==1 
      figure(g1)
      hold on;
      if counter==1
         subplot(311),plot(t,los/max(abs(los)),'b')
      else   
         subplot(311),plot(t,los/max(abs(los)),'r')
      end   
      axis([shifttime-5 shifttime+10 -1 1])
      title('Template Waveform (d=1 m)')
      xlabel('time (ns)')
      ylabel('normalized amplitude')
      hold off;
      if scandisp==0
      	figure(g+1)
   	end 
   end   
   Y=(fft(y)); Y(1)=1e-9; YA=Y;
	L=(fft(los)); L(1)=1e-9; LA=L;
   %if counter==1
   	f=fs*(0:length(Y)-1)/length(Y);fa=f;
	%end
   %Convolution
      C=Y.*conj(L);
      C=C.*exp(j*2*pi*f'*(-shifttime)*1e-9);
	%De-convolution
   	H=Y./L;
   	H=H.*exp(j*2*pi*f'*(-shifttime)*1e-9);
  
	%Convolution (Multiplication in Frequency)
   	%Stop @ 6 GHz
   	fs=6e9;
      for bb=1:length(Y)
         if f(bb)>=fs
            stopfreq=bb;%451
            break;
         end
      end   
   	Y=Y(1:stopfreq); L=L(1:stopfreq); C=C(1:stopfreq); f=f(1:stopfreq);%fs=3e9;
      fa=fa(1:stopfreq);%fsa=3e9;
      
   %curfig=gcf;   
   %if counter==1 
   %   figure(counter+1)
   %   hold on
   %   subplot(2,1,2),plot(fa/1e9,20*log10(abs(Y)+1e-2),'r');  
	%	title(strcat('Spectrum of Scanned Data (Scan # ',num2str(counter), ')'));
	%	ylabel('PSD (dB)');
	%	%axis([0 max(max(psdmatrix(1:toppt,1))) min(min(psdmatrix(1:toppt,2)))-20 max(max(psdmatrix(1:toppt,:)))+10]); 
   %   grid on;
   %   hold off
   %end
   %figure(curfig);
   
   
      
   c=(ifft(C));
   if counter==1  
      cref=c;
   end   
	tt=(0:length(c)-1)/fs;
	tt=tt.*1e9;
%Deconvolution (Division in Frequency)
%Stop @ 3 GHz
   %YA=YA(1:451);LA=LA(1:451);H=H(1:451);fa=fa(1:451);fs=3e9;
%Only look at from .75 to 2.6 GHz
	%YA=YA(113:391);LA=LA(113:391);H=H(113:391);fa=fa(1:451);fs=3e9;
  	%YA=[zeros(112,1);YA;zeros(60,1)]; 
 	%LA=[zeros(112,1);LA;zeros(60,1)]; 
   %H=[zeros(112,1);H;zeros(60,1)]; 
%Only look at from .75 to 2.5 GHz
	%YA=YA(113:376);LA=LA(113:376);H=H(113:376);fa=fa(1:451);fs=3e9;
  	%YA=[zeros(112,1);YA;zeros(75,1)]; 
 	%LA=[zeros(112,1);LA;zeros(75,1)]; 
   %H=[zeros(112,1);H;zeros(75,1)];
   
%Only look at 3 dB BW
	tot=stopfreq;
   LA1=(abs(LA(1:tot))/max(abs(LA(1:tot))));
   counter;
   stf=find(LA1>.25 & LA1<.6);
	startf=stf(1);%151;
   stopf=stf(length(stf));%301;
   
   
   YA=YA(startf:stopf);  YA=[zeros(startf-1,1);YA;zeros(tot-stopf,1)]; 
 	LA=LA(startf:stopf);  LA=[zeros(startf-1,1);LA;zeros(tot-stopf,1)]; 
  	H=H(startf:stopf);    H=[zeros(startf-1,1);H;zeros(tot-stopf,1)]; 
   %tot=stopfreq;
     
   if counter==1 & chandisp==1  
      figure(g1)
      subplot(312),plot(fa/1e9,20*log10(abs(LA1)+1e-2),'b-')%LA
      %hold on;
      %subplot(212),plot(fa/1e9,20*log10(abs(H)/max(abs(H(1:tot)))+1e-2),'r-')%LA
      axis([0 6 -40 0])
      title(strcat('Channel X-fer Function (Scan # ',num2str(counter), ')'));
      %legend('Template','X-fer')
      xlabel('frequency (GHz)')
      ylabel('PSD (dB)')
      hold off;
      subplot(313),plot(fa/1e9,angle(L)*180/pi,'b-')
      axis([1 3 -200 200])
      xlabel('frequency (GHz)')
      ylabel('Phase (degrees)')
      if scandisp==0
      	figure(g+1)
   	end      
   %pause   
   end    
   
   %YA=YA(151:301);LA=LA(151:301);H=H(151:301);fa=fa(1:451);fsa=3e9;
  	%YA=[zeros(150,1);YA;zeros(150,1)]; 
 	%LA=[zeros(150,1);LA;zeros(150,1)]; 
  	%H=[zeros(150,1);H;zeros(150,1)]; 
   h=(ifft(H));
   if counter==1  
      href=h;
   end   
     
   %tt2=(0:length(h)-1)/fs;
	%tt2=tt;%tt2.*1e9;
   
   
%Calculate Statistics on Channel Impulse Response**************************************
	[thpeaks,hpeaks,rmsdelay,meandelay,thresh,threshdB,peakratio,totalpower]=chan_stats(tt,h,Ts,chan_threshdB);
   normref=href;
   numpaths(counter)=length(hpeaks);
   rms2delay(counter)=rmsdelay;
   thresh=thresh / max(abs(normref));
   
   %Prep h to be sent out to main program
   size(h);
   hout(counter,:)=(abs(h)./max(abs(href)))';
   size(tt);
   tout(counter,:)=tt;
   size(hpeaks);
   %Send a single CIR out to main program for check
   if counter==8
   	hpeaksout(counter,:)=(hpeaks/max(abs(normref)));%hpeaks
      tpeaksout(counter,:)=thpeaks;
   end
   
   peakpower(counter)=max(abs(h)).^2 ./ max(abs(href)).^2; %Normalize to first at end of this program
   peakpowerratio(counter)=peakratio;
   meanexcessdelay(counter)=meandelay;
   
   if counter==1
      powerref=totalpower;
   end
   %Normalize to 1st CIR
   totpower(counter)=totalpower/powerref;
   
   %Compare Convolution to De-convolution
   		if scandisp==0 & chandisp==1 
           	%plot(tt,(abs(c)./max(abs(cref))),'b')
				hold on;
            plot(tt,(abs(h)./max(abs(href))),'r');
            plot(thpeaks,hpeaks/max(abs(normref)),'k*');
            plot(tt,thresh,'g');
            if counter==1 | counter==2
               axis([tstart tstop 0 max((abs(h)./max(abs(href))))+.1*max((abs(h)./max(abs(href))))])
            else
               axis([tstart tstop 0 max((abs(h)./max(abs(href))))+.1*max((abs(h)./max(abs(href))))])
            end                  
            hold off;
         	title(strcat('Channel Impulse Response (Scan # ',num2str(counter), ')'));			
            ylabel('normalized h(t)')
            xlabel('Time (nS)');
            %legend('Correlation','De-convolution')
            
         elseif scandisp==1
            figure(startfig+counter-1)
            if envelopeshow==1
         		subplot(313)
      		else   
         		subplot(212)
      		end 
            %plot(tt,(abs(c)./max(abs(cref))),'b')
				hold on;
            plot(tt,(abs(h)./max(abs(href))),'r');
				plot(thpeaks,hpeaks/max(abs(normref)),'k*');
            plot(tt,thresh,'g');
            xlabel('Time (nS)');
       
            if counter==1 | counter==2
               axis([tstart tstop 0 max((abs(h)./max(abs(href))))+.1*max((abs(h)./max(abs(href))))])
            else
               axis([tstart tstop 0 max((abs(h)./max(abs(href))))+.1*max((abs(h)./max(abs(href))))])
            end                 
            hold off;
         	title(strcat('Channel Impulse Response (Scan # ',num2str(counter), ')'));
				ylabel('normalized h(t)')
            %legend('Correlation','De-convolution')
            xlabel('Time (nS)');
         end%if
         
       CIRout(counter,:)=(abs(h)./max(abs(h)))'; 
              
       end; %if (counter <= nrdatafiles)
    end; %l
    %if counter==1+2 
    %		xlabel('time (ns)')
    %else
    %   close
    %end   
    if scandisp==0 & chandisp==1 
       xlabel('time (ns)')
       g=g+1;
    end   
 end; %k

 
 if writeCIR==1
    [g]=chan_write(distancedata,datafilename,datadirectory,direct,tt,CIRout,nrdatafiles);
 end


