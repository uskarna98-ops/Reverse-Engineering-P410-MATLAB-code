
function [rmsplot,yhattilderms]=plot_rmsdelay(distfile,filenum,disttype,distancedata,rms,chanimpulse,minpoint,maxxpoint,endthreshhold)

	if distfile==0;
        figure(gcf+1)
        rmsplot=gcf;
        plot(filenum,rms,'bx');
        %legend('rms delay','relative noiselevel')
        ple=['RMS Delay Spread vs Distance (Threshold=' num2str(endthreshhold) '*noise)_' date];
   	    title(ple);
   	    xlabel('scan number');
   	    ylabel('RMS Delay (ns)');
   	    grid on;
   	    axis([min(filenum) max(filenum) 0 max(10,max(rms)+10)])
   	    rms;
        yhattilderms=zeros(length(distancedata),1);
   elseif distfile==1
        figure(gcf+1)
        rmsplot=gcf;
        plot(distancedata,rms,'bx');
   	    ple=['RMS Delay Spread (threshold=' num2str(endthreshhold) '*noise)_' date];
   	    title(ple);
   	    if disttype==1
            xlabel('Distance (feet)');
     	elseif disttype==2
            xlabel('Distance (meters)');
     	end 
   	    ylabel('RMS Delay (ns)');
        hold on;
        [m b]=linefit((distancedata),rms);
        yhattilderms= m.*(distancedata)+b  ;  % this is the un-logarithmic curve fit 
        hold on;
        %Move curve fit to after rmsdelay2 so that legend makes sense
        if chanimpulse==0
            plot(distancedata,yhattilderms,'b');
        end   
        hold off;
        grid on;
   	    axis([minpoint maxxpoint 0 max(10,max(rms)+5)])
    end   