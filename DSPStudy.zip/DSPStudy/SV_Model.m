% S-V channel model generation

clear;
close all;

% S-V model parameters
Lam=1/11;               % Cluster arrival rate
lambda=1/0.35;          % Ray arrival rate 
Gam=16;                 % Cluster decay factor
gamma=8.5;              % Ray decay factor
std_ln=4.8;             % Standard deviation of log-normal variable
ts=0.167;               % sampling time (nsec)
%ts=1;
% ts=0.5;
% ts_resample_desired=0.5;
ts_resample_desired=ts;
P=1;
Q=round(ts_resample_desired/ts);
ts_resample=ts*Q/P;      % this defines the resampling time for any integer P and Q

std_L=sqrt(1/(2*Lam));
std_lam=sqrt(1/(2*lambda));

num_channels=1;

index_imp_resp=floor((10*Gam+10*gamma)/ts)+1;
imp_response=zeros(index_imp_resp,num_channels);

index_imp_resp_resample=ceil(P/Q*index_imp_resp);
imp_response_resample=zeros(index_imp_resp_resample,num_channels);

for k=1:num_channels
if (mod(k,10)==0)
    k
end;
% Determine Cluster arrivals
Tc=0;                   % First cluster arrival occurs at time 0
while (Tc<10*Gam)
    tmp_imp_response=zeros(floor((10*Gam+10*gamma)/ts)+1,1);
    tmp_imp_response_index=floor(Tc/ts)+1;
    
    mu=(-10*Tc/Gam)/log(10)-(std_ln)^2*log(10)/20;
    ln_rv=mu+std_ln*randn;
    pk=2*round(rand)-1;
    tmp_imp_response(tmp_imp_response_index)=10^(ln_rv/20)*pk;
    
    % Determine Ray arrivals for each cluster
    Tr=(std_lam*randn)^2+(std_lam*randn)^2;
    while (Tr<10*gamma)
        tmp_imp_response_index=floor((Tc+Tr)/ts)+1;
    
        mu=(-10*Tc/Gam)/log(10)+(-10*Tr/gamma)/log(10)-(std_ln)^2*log(10)/20;  % this assumes log(Omega)=0
        ln_rv=mu+std_ln*randn;
        pk=2*round(rand)-1;
        tmp_imp_response(tmp_imp_response_index)=10^(ln_rv/20)*pk;
        Tr=Tr+(std_lam*randn)^2+(std_lam*randn)^2;
    end;
    
    imp_response(:,k)=imp_response(:,k)+tmp_imp_response;   % this sums cluster and ray arrivals
    Tc=Tc+(std_L*randn)^2+(std_L*randn)^2;
end;

imp_response_resample(:,k)=resample(imp_response(:,k),P,Q);
imp_response_resample(:,k)=imp_response_resample(:,k)/sqrt(imp_response_resample(:,k)'*imp_response_resample(:,k));


% determine excess delay
sq_imp_response=imp_response_resample(:,k).^2;
max_tap=floor((10*Gam+10*gamma)/ts_resample)+1;
t=(0:(max_tap-1))'*ts_resample;
excess_delay(k)=t'*sq_imp_response;

% determine RMS delay
RMS_delay(k)=sqrt((t.^2)'*sq_imp_response-(excess_delay(k))^2);

% determine number of significant paths (paths within 10 dB from peak)
threshold_dB=-10;   % dB
threshold=10^(threshold_dB/20);
temp_imp_resp=abs(imp_response_resample(:,k));
max_imp=max(temp_imp_resp);
norm_imp=temp_imp_resp/max_imp;
a=find(norm_imp>threshold);
num_sig_paths(k)=length(a);

% determine number of sig. paths (captures x % of energy in channel)
x=0.85;
energy=0;
index_e=0;
temp_sort=sort(temp_imp_resp);
max_index=index_imp_resp_resample;
while (energy<x)
    energy=energy+temp_sort(max_index-index_e)^2;
    index_e=index_e+1;
end;
num_sig_e_paths(k)=index_e;

end;    % num_channels

mean_excess_delay=mean(excess_delay)
mean_RMS_delay=mean(RMS_delay)
mean_sig_paths=mean(num_sig_paths)
mean_sig_e_paths=mean(num_sig_e_paths)
Std_RMS_delay=std(RMS_delay)
Variance_RMS_delay=var(RMS_delay)

figure(1)
stem(t,imp_response_resample)
grid
title('Impulse response realizations')

%figure(2)
%plot(excess_delay)
%grid
%title('Excess delay')

%figure(3)
%plot(RMS_delay)
%grid
%title('RMS delay')

%figure(4)
%plot(num_sig_paths)
%grid
%title('Number of significant paths > 10 dB from peak')

%figure(5)
%plot(num_sig_e_paths)
%grid
%title('Number of significants capturing > 85% energy')

%figure(6)
%plot(hist(RMS_delay))
%grid

%load of the TDC template file%
template=load('c:\analysis\scan1.dat');
figure(7)
plot(conv(template,upfirdn(imp_response_resample,7,1)))
grid

%figure(8)
%plot(load('c:\analysis\scan144.dat'));
%grid

figure(9)
plot(template)
grid

figure(10)
stem(upfirdn(imp_response_resample,7,1))
grid

figure(11)
stem(imp_response_resample)
grid