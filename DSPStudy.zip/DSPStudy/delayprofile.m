function out=delayprofile( list, stmatrix, etmatrix, timeperpt)
% delayprofile.m
%  calculates the delay spread profile
%		i.e., time vs. normalized cumulative received power.
%
% operation:
% 
% Usage: 
%   out=delayprofile(list, starttimematrix, endtimematrix, timeperpt)
%      Where list is a matrix of scan data with each column
%      of the matrix a unique scan.
%   stmatrix = vector containing start times (nS) of waveform
%   etmatrix  =  vector containing end times (nS) of waveform
%   timeperpt = time per point (nS)

% based on:
% 
%   Paul Withington
%   Time Domain
%   February 1999
%
% last edited by:
%   David J. Hall
%   Time Domain Systems, Inc.
%   31 July 2000
%   15:49

%	Calculate total power with scan (to use to normalize plots)
%
ndp=size(list,1);
ndf=size(list,2);

out=zeros(ndp,ndf);  % output matrix containing normalized delay spread profile.

scanpower=list.^2;

for k=1:ndf
   y=cumsum( scanpower( round(stmatrix(k)/timeperpt) : round(etmatrix(k)/timeperpt ),k ));
   y=y/sum( scanpower( round(stmatrix(k)/timeperpt) : round(etmatrix(k)/timeperpt ),k ) );
   y=[ y ; ones(ndp-length(y), 1) ];
   out(:,k)=y;
end %k   

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%