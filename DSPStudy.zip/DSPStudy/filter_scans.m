function [filteredscanmatrix]=filter_scans(scanmatrix,deltatflag,filterscans,nrdatafiles)


if deltatflag==0 & filterscans==1
	disp(' ');
	disp(' ');
	disp('Filtering data files. . .');
	[m n]=size(scanmatrix);
   
	filteredscanmatrix=zeros(m,n);
	mfactor=(timeperpt/0.0305);   
	B=fir1(80,[0.05*mfactor min(0.2*mfactor,.99)]);
	A=1;% create filter to eliminate both DC component and high frequency noise
	for whichfile=1:nrdatafiles
      temp=filter(B,A,[ones(100,1)*scanmatrix(1,whichfile);scanmatrix(:,whichfile)]);  % filter out DC and high frequency noise- temporary column
     	filteredscanmatrix(:,whichfile)= [temp(142:length(temp), 1); zeros(41,1) ];  % shift filtered signal by 41 samples
                               % to make up for time shift in FIR filter
	end; % whichfile
elseif deltatflag==1  
   filteredscanmatrix=scanmatrix;
   disp(' ')
   disp(' ')
   disp('>> Sampling time resolution different for different files')
   %disp('>> No noise filtering will be performed')
   disp('   All calculations will be made with step size of last scan in series')
   disp('    ( this will skew time step of other files )')
   disp('>> Press Space Bar to continue')
   pause
elseif filterscans==0
   %Only remove DC OFFSET
   for qq=1:nrdatafiles
      filteredscanmatrix(:,qq)=scanmatrix(:,qq)-mean(scanmatrix(:,qq));
   end   
end