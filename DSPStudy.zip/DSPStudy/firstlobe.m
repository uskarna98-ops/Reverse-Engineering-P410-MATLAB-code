function out=firstlobe(list,starttimematrix,endtimematrix,timeperpoint)
% firstlobe.m
% 
% operation:
%   points to the first arriving lobe in a the scan channels,
%     by looking at the power profile.
% 
% usage:
%   firstlobe(list, starttimematrix, endtimematrix, timeperpoint)
%		Where:
%			list is a matrix of scan data with each column
%				representing a unique scan.
%        starttimematrix is a matrix containing the starting times in nS
%        endtimematrix is a matrix containing the ending times in nS
%			timeperpoint is the time increment per point (nS)
%
%	The function returns the estimated time of arrival of the
%	first lobe.
%

% last edited by:
%   David J. Hall
%   Time Domain 
%   10 Aug 2000
%   09:03

ndp=length(list(:,1));  % can use size
ndf=length(list(1,:));  % can use size

delayspreadprofile=delayprofile(list, starttimematrix, endtimematrix, timeperpoint);
%
%	Next work from the beginning of each scan and find when the
%	amount of power that precedes that point is sufficiently
%	small. In this formulation I use less than 2%
%  of total power.
%
%	NB: Need a better way to determine "sufficiently small"
%
firstpoint=zeros(1, ndf); 
for m=1:ndf
	k=1;
   while delayspreadprofile(k,m)<0.02
      k=k+1;
	end
	firstpoint(1,m)=k;
end %m
out=firstpoint.*timeperpoint;
out=out+starttimematrix;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%