
		disp('>> Enter the datafile to LED');
		cc=input(' \n');
      for i=1:nrdatafiles
         if filenum(i)==cc;
            cc=i;
         end
      end   
      CBDEL=cable_delayns;
      k=1;
      figure(500)
      firsttemporg=firsttemp;
      firsttemp=3; %Use same template
      
      %TAKE INPUTS FROM MAIN PROGRAM:
      
      %LED Variable Inputs (Correlate,Envelope,Difference,Peak) **********
      	%c=3e8; %meters per second
			%feet_per_meter=100/2.54/12;
			%cftps=feet_per_meter*c/1e12; %feet per picosecond
			%nsperft = 1/cftps/1000;%1.0167;
        	%step=round(.768/(Ts/1e-9));  		%step in ~.768 ns; was 16 for Ts=48 ps
      	%cumsamps=round(1/(Ts/1e-9));  %cumulate over 1 ns; was 21 for Ts=48 ps
      	%peakdiv=10;%5;				  			%peak=peak/peakdiv;
      	%addtoLE=round(.384/(Ts/1e-9));					%add ~.38 ns; was 8 for Ts=48 ps
      %LED2 Variable Inputs (Correlate,Envelope,Mean Threshold) **********
      	%step2=step;
      	%meantimes2=1.5;%2;	%envelopeMEAN=envelopeMEAN*meantimes;
      %LED3 Variable Inputs (Time-reverse Correlate,Peak/Mean Threshold) ***********
      	%threshdiv3=40;   %threshold=(peakvalue-meanvalue)/threshdiv + meanvalue;
      
      [leadingedge]=LED(nrdatapts,filteredscanmatrix(:,cc),step,Ts,cumsamps,peakdiv,addtoLE,k,tstart,tstop);
      [leadingedge2]=LED2(nrdatapts,filteredscanmatrix(:,cc),step2,Ts,meantimes2,k,tstart,tstop);
      [leadingedge3,gamma]=LED3(nrdatapts,filteredscanmatrix(:,cc),Ts,threshdiv3,k,tstart,tstop);
      [leadingedge4,Template]=LED4(nrdatapts,filteredscanmatrix(:,cc),step2,Ts,meantimes2...
         ,k,firsttemp,template_sizens,Template,firstpeak4,tstart,tstop);
      LE(k)=leadingedge*timeperpt;
      LE2(k)=leadingedge2*timeperpt;
      LE3(k)=leadingedge3*timeperpt;
      LE4(k)=leadingedge4*timeperpt;
      
      if chooseLED==0
         leadingedgeAoA=leadingedge;
      elseif chooseLED==2
         leadingedgeAoA=leadingedge2;
      elseif chooseLED==3
         leadingedgeAoA=leadingedge3;
      elseif chooseLED==4
         leadingedgeAoA=leadingedge4;   
      end   
      LEAoA(k)=leadingedgeAoA*timeperpt;
      
      if AoAon==1
      	[aoa,correlation,Start,End,Template,cable_delayns,firstpeak,secondpeak] = AOA(nrdatapts,...
            filteredscanmatrix(:,cc),leadingedgeAoA, template_sizens, cable_delayns, A,k,...
            nsperft,Ts,firsttemp,Template,tstart,tstop);
         LE_2(k)=aoa*timeperpt;
      end
      
      cable_delayns=CBDEL
      firsttemp=firsttemporg;
      
