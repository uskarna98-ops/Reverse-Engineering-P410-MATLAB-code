function [AoAon,xtag,ytag,RXcoord,scanmatrix, lockmatrix, distancedata, BER, EbNeff,timeperpt,nrdatapts,...
        distfile,nrdatafiles,VGA,txatt,rxatt,deltatflag,deltat,disttype,timebaseoff,tempwidth,Ts]=...
        read_data(meas_sys,datadirectory,datafilename,attenoff,maxnumberoffiles,hTX,hRX,antheightadj,offdB)

%PAD - *********************************
if meas_sys=='PAD' | meas_sys=='pad' 
       tempwidth=3.3;	%Width of CLEAN template in ns
       [scanmatrix, lockmatrix, distancedata, BER, EbNeff, timeperpt,nrdatapts,distfile,...
            nrdatafiles,VGA,txatt,rxatt,deltatflag,deltat,disttype]=read_PAD(datadirectory, ...
            datafilename,attenoff,maxnumberoffiles,hTX,hRX,antheightadj,offdB);
         AoAon=0;
         xtag=0;ytag=0;RXcoord=0;
         timebaseoff=zeros(1,nrdatafiles);
   
%DSO - Early P200 ***********************      
elseif  meas_sys=='DSO' | meas_sys=='dso'
       tempwidth=1.7;	%Width of CLEAN template in ns
       [AoAon,RXcoord,TXcoordrel,scanmatrix, lockmatrix, distancedata, BER, EbNeff, ...
            timeperpt,nrdatapts,distfile,nrdatafiles,VGA,txatt,rxatt,deltatflag,deltat,disttype,...
            timebaseoff]=read_DSO(datadirectory,datafilename,attenoff,maxnumberoffiles,hTX,hRX,...
         	antheightadj,offdB);
      		xtag=TXcoordrel(:,1);
            ytag=TXcoordrel(:,2);

%EVK - P200 ***************************** 
elseif  meas_sys=='EVK' | meas_sys=='evk'
       tempwidth=1.7;	%Width of CLEAN template in ns
       [AoAon,RXcoord,TXcoordrel,scanmatrix, lockmatrix, distancedata, BER, EbNeff, ...
            timeperpt,nrdatapts,distfile,nrdatafiles,VGA,txatt,rxatt,deltatflag,deltat,disttype...
            ]=read_EVK(datadirectory,datafilename,attenoff,maxnumberoffiles,hTX,hRX,...
         	antheightadj,offdB);
       
      		xtag=TXcoordrel(:,1);
            ytag=TXcoordrel(:,2);
            timebaseoff=0;
            
%Files not Found ************************          
else   
    disp(' ');
	disp(' ');
   	disp('>>No scan files found; Check path and/or file name and restart program.');
   	disp('>>press <CTRL>-C to end program');
   	disp(' ');
   	disp(' ');
   	pause;      
end   
Ts=timeperpt*1e-9;