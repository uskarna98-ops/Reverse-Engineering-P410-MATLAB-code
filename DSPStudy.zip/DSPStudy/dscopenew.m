%function [rmsdelay,RMS_delay]=rmsdelay(wave, timeperpt)


%Read In Initial Sample Set *******************************************   
close all
clear

ncycles=3;
lev1=.1;
lev2=.1;
 
snapshot=1; 
otherprogram=0;

 
datapoints=4096;
%craplength=943;%proplab files 
%craplength=935;%propcal files
%craplength=932;%walprop files
%craplength=948;%noise files
%datname= sprintf('data/2GHzwired');
%disp('>> Enter the base name of the data files.');
%datname=input('    (for example, 2GHzwired)\n','s');
datname='aoa';
%disp('>> Enter the number of files to read in.');
%nrdatafiles=input('   (for example, "8" ) NB: This assumes the 1st file suffix is 1 & increments by 1.\n');
nrdatafiles=8;


for n=1:nrdatafiles
   dat = sprintf('%d.dat',n);
   datfile=['c:\analysis\AOA\initial\' datname dat];
   %datfile=['' datname dat];
   fid = fopen(datfile,'r');
   if n==1
   	%Strip Off Header Crap
   	linedata=fgets(fid);
      while (strncmp(linedata,'%CHANNEL1 time step (Seconds):',25))==0;
   	   linedata = fgets(fid);
      end
      linedata = fgets(fid);
      Ts=str2num(linedata(2:length(linedata)));
      disp('   ')
      pleTs=['Time Step = ' num2str(Ts/1e-12) ' ps']; 
      disp(pleTs)
      %disp('  (Press <Enter> to continue)')
      disp('   ')
      %pause
   end   
   data(:,n)=load(datfile);
   fclose(fid);
end
%Ts=100e-9/datapoints;
timeperpt=Ts*1e9;
t=0:Ts:(length(data)-1)*Ts;

%Find Maximums ----------------------------------------------------

for n=1:nrdatafiles
	figure(n)
   plot(t/1e-9,data(:,n));
   title(strcat('Filtered Scan Channel Data (Scan # ',num2str(n), ')'));
	xlabel('time (ns)')
	ylabel('amplitude')
	grid
end