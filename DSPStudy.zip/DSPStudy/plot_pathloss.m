

function [g]=plot_pathloss(term,nrdatafiles,corr,tpeakval,distancedata,choptozero,percent_less,calc_N90,...
        Kmon,calc_Km90,disttype,offdB,distdat1,N,K,ya,y,y90N,y90K,M_N,stdev_N,M_K,stdev_K,percent);
  g=1;
  
%Set axes for log scale   
  if max(distancedata)<=100
   	    maxxpoint=ceil(max(distancedata)/100)*100;
  else
  		maxxpoint=ceil(max(distancedata)/100)*100;
  end    
  if min(distancedata)>=10
   	minpoint=10;
  else
      if disttype==1
         minpoint=1;
      else
         minpoint=.1;
      end   
  end

  figure(gcf+1);
  %Plot Reference Lines
	  r2=-20*log10(distdat1/min(distdat1));semilogx(distdat1,r2,':','linewidth',2,'color','r') 
      hold on;
      %r3=-30*log10(distdat1/min(distdat1));semilogx(distdat1,r3,'g-s')     
      
  %Plot 1/d^N curve fit
      semilogx((distdat1),(ya),'linewidth',2,'color','b')
      if calc_N90==1
      	semilogx(distdat1,(y90N),'linewidth',2,'color',[0 .8 1])
      end
      
  %Plot exp(-Kd)/d^2 curve fit
  	  if Kmon==1
     	semilogx(distdat1,(y),'linewidth',2,'color','m')
      end     
      if calc_Km90==1 & Kmon==1
      	semilogx(distdat1,(y90K),'linewidth',2,'color',[1 .5 .7])
      end
      
  %Plot the actual data points         
     semilogx((distancedata),term,'k*');   
     
  %Re-Plot Lines to overlay points ------------------------
      semilogx(distdat1,r2,':','linewidth',2,'color','r') 
      hold on;
      semilogx((distdat1),(ya),'linewidth',2,'color','b')
      if Kmon==1
      	semilogx(distdat1,(y),'linewidth',2,'color','m')
      end   
      if calc_N90==1
         semilogx(distdat1,(y90N),'linewidth',2,'color',[0 .8 1])
      elseif calc_Km90==1 & Kmon==1  
         semilogx(distdat1,(y90K),'linewidth',2,'color',[1 .5 .7])
      end   
        
  %Set Axes, Notes    
  	  %ple1=[('n=') num2str(n)];
      ple1a=[('N=') num2str(N)];  
      if disttype==1
         %ple2=[('K_f =') num2str(K)];
         Km=3.28*K;
         Km=round(Km*100)/100;
         Lw=-10*log10(exp(-Km)); 
         Lw=round(Lw*100)/100;
         ple2=[('Km=') num2str(Km) ', Lw=' num2str(Lw)];
      elseif disttype==2
         Km=K;
         Km=round(Km*100)/100;
         Lw=-10*log10(exp(-Km));   
        	ple2=[('Km=') num2str(Km) ', Lw=' num2str(Lw)];
     	end 
      
      if calc_Km90==1
         plePER=[num2str(round(percent*10)/10) '% Rel to Km'];
         pleMAR=['Margin = ', num2str( round(M_K*10)/10 ) ' dB'];
      elseif calc_N90==1   
         plePER=[num2str(round(percent*10)/10) '% Rel to N'];
         pleMAR=['Margin = ', num2str( round(M_N*10)/10 ) ' dB'];
      else
         plePER=[];
         pleMAR=['Margin = ', num2str( round(M_N*10)/10 ) ' dB'];
      end
      
      if calc_N90==1
         if Kmon==1
         	legend('Free Space',ple1a,plePER,ple2,'data')%legend('Free Space',ple1a,ple2,'90% Rel','data','multipath peaks',pleoffdB)
         else
            legend('Free Space',ple1a,plePER,'data')
         end   
      else   
         legend('Free Space',ple1a,'data',3)%legend('Free Space',ple1a,ple2,'90% Rel','data','multipath peaks',pleoffdB)
      end   
      pleoffdB=['offdB = ', num2str(offdB)];
      %text(8,-1.5,pleoffdB)
      pleSTD=['\sigma_N = ' num2str(round(stdev_N*100)/100) ' dB'];
      text(20,-5,pleSTD,'fontsize',12,'color','b')
      %text(20,-7.5,pleMAR,'fontsize',12,'color','b')
      smaller=min(-30*log10([max(distancedata)/min(distancedata)]),min(term)-6);
      miny=(ceil(min(smaller)/3)*3-3);
      axis([minpoint maxxpoint miny 3]); %axis([0 3.0 -100 -20]);
      vecor=[];
      for gt=miny:3:3
         vecor=[vecor gt];
      end 
      set(gca,'yTick',vecor)
      grid on;
		if disttype==1
        xlabel('Distance (feet)','fontsize',12);
     elseif disttype==2
        xlabel('Distance (meters)','fontsize',12);
     end 
		ylabel('-PL_P_E_A_K  (dB)','fontsize',12);
		ple=[('Calculated from ') num2str(length(distancedata)) ' scans (calculated assuming ',num2str(corr), ' peak)  '  date];
   	  title(ple);
      hold off;
%----------------------------------------------------------------------------------   