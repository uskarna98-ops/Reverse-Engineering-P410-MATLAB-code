function [g]=scan_write(distancedata,datafilename,datadirectory,direct,tt,CIRout,nrdatafiles,RAKEdB,...
   PEAKSused,excessdelay,meanexcessdelay,rms2delay,totpower,peakpower,CIRpeakV,CIRrmsV,filenum,...
   threshdB)


FID4=fopen([datafilename '_WAVE' num2str(round(threshdB)) '.out'],'w');
      %Header
      
      fprintf(FID4,'\n');
		fprintf(FID4,'SCAN WAVEFORMS\n\n');
      
      fprintf(FID4,'d      ');
      for bb=1:1:nrdatafiles
         fprintf(FID4,' %6.1f   ',distancedata(bb));
      end
      fprintf(FID4,'\n');
      
      fprintf(FID4,'Pow(dB)');
      for bb=1:1:nrdatafiles
         fprintf(FID4,' %6.1f   ',10*log10(peakpower(bb)));
      end
      fprintf(FID4,'\n');
      
      fprintf(FID4,'Tot(dB)');
      for bb=1:1:nrdatafiles
         fprintf(FID4,' %6.1f   ',10*log10(totpow(bb)));
      end
      fprintf(FID4,'\n');
                  
      fprintf(FID3,'PeakV  ');
      for bb=1:1:nrdatafiles
         fprintf(FID3,' %6.4f   ',SpeakV(bb));
      end
      fprintf(FID3,'\n');
      
      fprintf(FID3,'RMSV   ');
      for bb=1:1:nrdatafiles
         fprintf(FID3,' %6.4f   ',SrmsV(bb));
      end
      fprintf(FID3,'\n');
            
      fprintf(FID4,'RMS(ns)');
      for bb=1:1:nrdatafiles
         fprintf(FID4,' %6.1f   ',rms2delay(bb));
      end
      fprintf(FID4,'\n');
      
      fprintf(FID4,'MN(ns) ');
      for bb=1:1:nrdatafiles
         fprintf(FID4,' %6.1f   ',meanexcessdelay(bb));
      end
      fprintf(FID4,'\n');
      
      fprintf(FID4,'EX(ns) ');
      for bb=1:1:nrdatafiles
         fprintf(FID4,' %6.1f   ',excessdelay(bb));
      end
      fprintf(FID4,'\n');
      
      fprintf(FID4,'RAK(dB)');
      for bb=1:1:nrdatafiles
         fprintf(FID4,' %6.2f   ',RAKEdB(bb));
      end
      fprintf(FID4,'\n');
      
      fprintf(FID4,'RAKPEAK');
      for bb=1:1:nrdatafiles
         fprintf(FID4,' %6.0f   ',PEAKSused(bb));
      end
      fprintf(FID4,'\n');
      
      
      fprintf(FID4,'\n');      
      fprintf(FID4,'t       ');
      for bb=1:1:length(distancedata)
         if filenum(bb)<10
            fprintf(FID4,'Scan#%1.0f    ',filenum(bb));
         elseif filenum(bb)<100
            fprintf(FID4,'Scan#%1.0f   ',filenum(bb));
         else
            fprintf(FID4,'Scan#%1.0f  ',filenum(bb));
         end   
      end
      fprintf(FID4,'\n');
      %End Header
      
      ple=['%.2f'];
      for bb=1:1:length(distancedata)
         ple=[ple ' %9.1f'];
      end   
      ple=[ple '\n'];
      
      for m=1:length(t)
      	tempmatrix=[t(m) ; filteredscanmatrix(m,:)'];
         fprintf(FID4,ple,tempmatrix);
      	%y=filteredscanmatrix(:,bb)';
      	%fprintf(FID3,'%.2f\n',y);
      end %m
      g=1;
      fclose(FID4);