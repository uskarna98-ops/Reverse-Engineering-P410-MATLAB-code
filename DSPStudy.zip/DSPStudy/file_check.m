%we will check for the files used 
% Find all dependencies for a specific file
[fList, pList] = matlab.codetools.requiredFilesAndProducts('CATCIR.m');

% Display the dependent files
disp(fList');
