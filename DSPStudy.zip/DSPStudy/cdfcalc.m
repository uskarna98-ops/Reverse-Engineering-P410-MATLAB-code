function [z,cdf]=cdfcalc(AA,binnum)

[bins,z]=hist(AA,binnum);
      
sum1=0;
for s=1:length(bins)
 	sum1=sum1+bins(s);
 	cd(s)=sum1;
 	cdf(s)=cd(s)/length(AA);	
end;
