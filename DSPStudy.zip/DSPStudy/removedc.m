function out=removedc(list);
% removedc.m
% 
% operation:
%    Removes any DC offset in the data
% 
% usage:
% out=removedc(list);
%    inputs:   list [nrdatapts X nrdatafiles] matrix containing scan channel data
%    outputs:  out

% Paul Withington
% Time Domain 
%
% last edited by:
%   David J. Hall
%   Time Domain Systems, Inc.
%   01 Jan 2000
%   17:06

%	NB Assumes no DC drift during the scan.

listmeanval=mean(list);
out=list-ones(size(list,1),1)*listmeanval;