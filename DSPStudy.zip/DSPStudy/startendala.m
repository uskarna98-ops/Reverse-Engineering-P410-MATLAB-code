function [starttime, endtime, errorcode, envelope, noiselvl,choice,glitchflag,noisestart]= ...
   startendala(scanfile,scanwave, lockwave, startthreshhold, timeperpt, endthreshhold)
% startend.m
%
% operation:
%   finds the beginning wavefront and ending wavefront.
%   
% usage: function [starttime, endtime, errorcode, envelope, noiselvl]= startend(scanwave, lockwave, startthreshhold, timeperpt,endthreshhold)
% 
% inputs:   scanwave         scan waveform            
%           lockwave         lock/data channel waveform
%           startthreshhold       number of standard deviations above ambient noise needed to be to trigger start of pulse.
%           timeperpt        sampling time in nS
%           endthreshhold  number of standard deviations above noise threshhold scan waveform standard deviation
%                                  has to fall below to trigger end of scan waveform detection
%
% outputs:  starttime        start time of pulse inside scanwave (in nS)
%           endtime          end time of pulse inside scanwave (in nS)
%           errorcode        error code returned from function - values TBD

% last edited by:
%    David J. Hall
%    Time Domain Corp.
%    20 Dec 2000
%    14:00
%

% find ambient noise level
%size(scanwave)
%pause

%Check to see if noise preceeding lock point is corrupted by a multipath, 
%if so, use end of scan to get calculation of noise

glitchflag=0;
scanfile;
numlook=round(3/timeperpt); %look at first 3 ns
noiselvla=std(scanwave(1:numlook));
noiselvlb=std(scanwave(length(scanwave)-numlook*2:length(scanwave)-numlook));
if noiselvla < 3*(noiselvlb)
   noiselvl=noiselvla;
   choice=1;
else  
   noiselvl=noiselvlb;
   choice=2;
end   


% artificially set values of starttime and endtime
starttime=timeperpt;
endtime=length(scanwave)*timeperpt;

% find when ambient noise level is surpassed by threshhold of standard deviation - this is starttime
for k=1:length(scanwave)
   if abs(scanwave(k))>startthreshhold*noiselvl
      starttime=k*timeperpt;
      break;
   end %if
end %k 
	if k==length(scanwave)
   	message=['Warning: startthreshhold set too high for scan #',num2str(scanfile), '. Will be reduced by 1/2']
   	%pause;
   	startthreshhold=startthreshhold/2;
   	for k=1:length(scanwave)
   		if abs(scanwave(k))>startthreshhold*noiselvl
      		starttime=k*timeperpt;
      		break;
   		end %if
		end %k 
   end %if
   if k==length(scanwave)
   	message=['Warning: startthreshhold still set too high for scan #',num2str(scanfile), '. Will be set to level of noise']
   	%pause;
   	startthreshhold=1;
      starttime=10;
   end   
      


% now update noise level
	if choice==1
      choice;
      
      % now update noise level but only if starttime is more than 5 ns into scan
      
      if starttime>=8
         shift=round(6/timeperpt);
         noiselvl=std(scanwave(1:round(starttime/timeperpt)-shift));
         noisestart=starttime-timeperpt*shift;
         %Limit noise calculation to first 10 ns
         noiselim=10;
         if noisestart>=noiselim
            noisestart=noiselim;
            noiselvl=std(scanwave(1:round(noisestart/timeperpt)));
         end   
      elseif starttime>=2 
         shift=round(1/timeperpt);
         noiselvl=std(scanwave(1:round(starttime/timeperpt)-shift));
         noisestart=starttime-timeperpt*shift;
      end 
  	elseif choice==2
      choice;  
      noiselvl=std(scanwave(length(scanwave)-500:length(scanwave)));
      noisestart=(length(scanwave)-500)*timeperpt;
	end   

   
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% calculate standard deviation of noise from lock/data channel
avg=mean(lockwave);
output1=zeros(1,length(lockwave));
output0=zeros(1,length(lockwave));
for k=1:length(lockwave)
   if lockwave(k)>=avg
      output1(k)=lockwave(k);
   else
      output0(k)=lockwave(k);
   end
end;  

% Look for strings of consecutive zeros in output1[] and output0[].
% Eliminate them by performing linear interpolation between values 
% on either side of each string.

% force all ending 0 values equal to the last non-zero value
pointer=length(output0);

while(output0(pointer)==0)
   pointer=pointer-1;  
end;

for(k=pointer:length(output0))
   output0(k)=output0(pointer);
end   

pointer=1;

while (output0(pointer)==0) 
   pointer=pointer+1;
end;

% force all leading 0 values equal to the first non-zero value
for(k=1:pointer-1)
   output0(k)=output0(pointer) ;
end;   

while(pointer<(length(output0)))
   
   y0=output0(pointer);

   zerocount=0;
   pointer=pointer+1;
   while(output0(pointer)==0  & pointer<length(output0))
      pointer=pointer+1;
      zerocount=zerocount+1;
   end;   

   y1=output0(pointer);
   x0=pointer-zerocount-1;
   x1=pointer;
   for k=(x0+1):(x1-1)
      output0(k)=y1+(y1-y0)*(k-x1)/(x1-x0);
   end   

   x0=x1;
end;
mean0=mean(output0);



% force all ending 0 values equal to the last non-zero value
pointer=length(output1);
while(output1(pointer)==0)
   pointer=pointer-1;
end;
for(k=pointer:length(output1))
   output1(k)=output1(pointer);
end   


pointer=1;

while (output1(pointer)==0) 
   pointer=pointer+1;
end;

% force all leading 0 values equal to the first non-zero value
for(k=1:pointer-1)
   output1(k)=output1(pointer) ;
end;   

while(pointer<(length(output1)))
   
   y0=output1(pointer);

   zerocount=0;
   pointer=pointer+1;
   while(output1(pointer)==0 & pointer<length(output1))
      pointer=pointer+1;
      zerocount=zerocount+1;
   end;   

   y1=output1(pointer);
   x0=pointer-zerocount-1;
   x1=pointer;
   for k=(x0+1):(x1-1)
      output1(k)=y1+(y1-y0)*(k-x1)/(x1-x0);
   end   

   x0=x1;
end;

%  CAVEAT: for some reason, lock/data channel noise needs to be multiplied by a factor of
%      approximately 3 to equal noise on scan channel.
%      This could be attributed to a difference of gains in the VGA's
std0=std(output0)*2.615;
std1=std(output1)*2.615;
%snr(1)=(((mean1-mean0)/2)^2)/std(output0)^2;
%snr(2)=((mean1-mean0)^2)/std(output1)^2;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% create envelope, which plots standard deviation of approximately 1 nS windows
windowlength=1.0;   % length of envelope window in nS
envelope=zeros(1,length(scanwave));
interval=round(windowlength/timeperpt);
for k=1:interval:length(scanwave)-interval
   envelope( k:k+interval-1)=ones(1,interval)*std(scanwave(k:k+interval-1));
end %k   

% find when ambient noise level is reached again after main pulse - this is TENTATIVE endtime
for k=length(envelope):-1:round(starttime/timeperpt)+10
   if envelope(k)>endthreshhold*noiselvl
      endtime=k*timeperpt;
      break;
   end %if    
end %k   

% now create TENTATIVE delay profile to check that at least 5% of the cumulative energy has appeared
%   within 10 nS of the initial pulse.
sw=scanwave.^2;
y=cumsum( sw( round(starttime/timeperpt) : round(endtime/timeperpt) ));
y=y/sum( sw( round(starttime/timeperpt) : round(endtime/timeperpt ) ));
y=[ y ; ones(length(scanwave)-length(y), 1) ];

if y(round(10/timeperpt))<0.05
   scanfile;
   glitchflag=1;
   oldstarttime=starttime;
   
   % This means that initial point was wrong.  
   % find new ambient noise level - look at noise 3 to 6 nS after starttime
   noiselvl=std(scanwave(   round(starttime/timeperpt+3/timeperpt) : ...
      round(starttime/timeperpt+6/timeperpt)   ));

   % find when ambient noise level is surpassed by threshhold of standard deviation - this is starttime
   for k= round((starttime+5)/timeperpt) :length(scanwave)
      if scanwave(k)>startthreshhold*noiselvl*1.5
         newstarttime=k*timeperpt;
         break;
      else   
         newstarttime=oldstarttime;
      end %if
   end %k   
   
   % now update noise level
   starttime=newstarttime;
   if starttime>=8
         shift=round(6/timeperpt);
         noiselvl=std(scanwave(1:round(starttime/timeperpt)-shift));
         noisestart=starttime-timeperpt*shift;
         %Limit noise calculation to first 10 ns
         noiselim=10;
         if noisestart>=noiselim
            noisestart=noiselim;
            noiselvl=std(scanwave(1:round(noisestart/timeperpt)));
         end   
   else 
         shift=round(1/timeperpt);
         noiselvl=std(scanwave(1:round(starttime/timeperpt)-shift));
         noisestart=starttime-timeperpt*shift;
   end   
   newstarttime;
end %if   

starttime;  % delete these - djh
endtime;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% find at 100 nS intervals after first arriving pulse, zero values from 15 ns before to 25 nS after
numintervals=floor((length(scanwave)*timeperpt - starttime)/100);
if(numintervals>0)
   for k=1:numintervals
      startpoint=round(starttime/timeperpt + k*100/timeperpt - 15/timeperpt);
      if (startpoint<1)
         startpoint=1;
      end; %if
      endpoint=round(starttime/timeperpt + k*100/timeperpt + 25/timeperpt);
      if (endpoint > length(envelope))
         endpoint=length(envelope);
      end; %if
      %whos envelope;
      startenvelope=startpoint-40;
      endenvelope=startpoint-5;
      m=mean(envelope(startenvelope:endenvelope));
      envelope(startpoint-1:endpoint)=ones(1,2+endpoint-startpoint)*m;     
   end %k
end % if 

% find when ambient noise level is reached again after main pulse
for k=length(envelope):-1:round(starttime/timeperpt)+10
   if envelope(k)>endthreshhold*noiselvl
      endtime=k*timeperpt;
      break;
   end %if    
end %k   

errorcode=0;
% possible error codes for following conditions:
% 
%  error in input files - expected variable(s) not present
%  no ambient noise preceding initial pulse
%  initial pulse does not decay before the end of the scan 

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%