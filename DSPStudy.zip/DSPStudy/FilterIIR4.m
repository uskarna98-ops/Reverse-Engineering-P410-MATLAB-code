%// This routine implements an IIR filter of the following form:
%// (1 - z^-2) / (1 - 1.40512*z^-1 + 0.67475*z^-2)
%// The impulse response of this filter gives a template that
%// very closely approximates the leading edge of our waveform
%// and this algorithm should be pretty fast. (2 multiplies per sample
%// as apposed to 24 multiplies per sample with the original algorithm)
%// The return value is the intersample power (y[n] * y[n-1])
%// David Langford 10/13/2000
%long int tdRADIO::FilterIIR(long int input,long int x[3], long int y[3])
%{
%static long int a1 =  22; //  1.405512 * 16
%static long int a2 = -10; // -0.67475  * 16

function [outputt,x1,x2,x3,y1,y2,y3]=FilterIIR4(inputt,x1,x2,x3,y1,y2,y3)

ArrayIN=[x1;x2;x3;y1;y2;y3];


a1= 22; % 1.405512 * 16
a2=-10; %-0.67475  * 16

%slide down input array and store new input
x1=x2;  x2=x3;  x3=inputt;

%slide down output array
y1=y2;  y2=y3;

%compute new output
y3 = x3 - x1 + a1*y2 + a2*y1;

%now re-scale output
%this C command shifts the digits in y to the left 4 spaces, truncating the 
%lower 4 bits.  this is needed to stay within the fixed integer math range
%of the calculations on the ARM.  Not needed here
%y[3]>>=4L;
y3=y3/16;

%IIR 1 used by Dave Langford
%Output is a square of y(3) only it is shifted by 1 sample
outputt=y3.*abs(y3);

%IIR 2 used by Dave Langford
%Output is squared
%outputt=y3^2;

ArrayOUT=[x1;x2;x3;y1;y2;y3];
%[ArrayIN ArrayOUT]
%   pause
