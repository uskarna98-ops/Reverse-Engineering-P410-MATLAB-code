%// returns the sample number of the direct path or -9999999 if can't find it
%// Envelope Difference First Peak with Dynamic Scaling
%int tdRADIO::LeadingEdgeDetection0(int numPts, long *iDataIn)

function [output,gamma]=LED3(numPts,iDataIN,Ts,threshdiv,k,tstart,tstop)
TS=Ts/1e-9;
inMean=0;
peak=1;
%x=[0,0,0];
%y=[0,0,0];
x1=0;
x2=0;
x3=0;
y1=0;
y2=0;
y3=0;

%Calculate Waveform Mean Voltage
for i=1:numPts
   inMean=inMean+iDataIN(i);
end
inMean=inMean/numPts;

%Correlate with IIR Filter
for i=0:numPts-1
   inputt=[iDataIN(numPts-i)-inMean];
   [outputt,x1,x2,x3,y1,y2,y3]=FilterIIR(inputt,x1,x2,x3,y1,y2,y3);
   iDataINLocal(numPts-i)=outputt;
end
%for i=1:numPts
%   inputt=[iDataIN(i)-inMean];
%   [outputt,x1,x2,x3,y1,y2,y3]=FilterIIR(inputt,x1,x2,x3,y1,y2,y3);
%   iDataINLocal(i)=outputt;
%end
%figure(999)
%plot((0:numPts-1),iDataIN)
%hold on
%plot((0:numPts-1),iDataINLocal,'r')
%hold off
%pause

%find the average of the correlated signal
	meanvalue=0;
	peakvalue=0;
	for i=1:numPts
		meanvalue=meanvalue + iDataINLocal(i);
		if iDataINLocal(i) > peakvalue
			peakvalue = iDataINLocal(i);
		end
   end
   meanvalue = meanvalue / numPts;
   threshold=(peakvalue-meanvalue)/threshdiv + meanvalue;
   gamma=round((peakvalue/meanvalue)*10)/10;
%lets find the first place we break this mean value
	for i=1:numPts
		if iDataINLocal(i)>=threshold
         peak = i-1;
         break
      end
   end
   
%logic in LE3 algorithm   
   if peak<50 
      output=5;
   elseif peak> (numPts-100)
      output=5;
   else
      output=peak;
   end   
   
if k==1
	figure(gcf+1)
   %subplot(211), 
   plot((0:numPts-1)*TS,iDataIN./max(abs(iDataIN)),'k.-')
	hold on
   %subplot(211), 
   plot((0:numPts-1)*TS,iDataINLocal./max(abs(iDataINLocal)),'r.-','LineWidth',2)
	%subplot(211), plot((0:numPts-1)*TS,iDataINLocal2./max(abs(iDataINLocal2)),'m.-')
   %axis([49.6 51 -.8 1.2])
   grid on
   %plot((0:numPts-step-1)*.03052,envelope/max(abs(envelope)),'g','LineWidth',2)
	plot([output output]*TS, [-1 1],'LineWidth',2,'color','b')
   axis([tstart tstop -.8 1.2])
   xlabel('time (ns)')
	ylabel('normalized amplitude')
	title('LED3')
   %legend('Impulse Excitation','Manual IIR','MATLAB IIR')
   legend('iDataIN','iDataINLocal','LE3')
   hold off
end 


