function [pointer,maxlobe_time]=calc_plot_times(filteredscanmatrix, stmatrix, etmatrix, ntmatrix,timeperpt,timestatplot,...
        templatewidth,datafilename,nrdatafiles,tstop);


    
    
    

%Points to the first arriving lobe in a the scan channels by looking at the power profile.
% 
    ndp=size(filteredscanmatrix,1);
    ndf=size(filteredscanmatrix,2);
    out=zeros(ndp,ndf);  % output matrix containing normalized delay spread profile.
    scanpower=filteredscanmatrix.^2;

for k=1:ndf
   y=cumsum( scanpower( round(stmatrix(k)/timeperpt) : round(etmatrix(k)/timeperpt ),k ));
   y=y/sum( scanpower( round(stmatrix(k)/timeperpt) : round(etmatrix(k)/timeperpt ),k ) );
   y=[ y ; ones(ndp-length(y), 1) ];
   out(:,k)=y;
end %k   
delayspreadprofile=out;
%
%	Next work from the beginning of each scan and find when the
%	amount of power that precedes that point is sufficiently
%	small. In this formulation I use less than 2%
%  of total power.	NB: Need a better way to determine "sufficiently small"
%
firstpoint=zeros(1, ndf); 
for m=1:ndf
	k=1;
   while delayspreadprofile(k,m)<0.02
      k=k+1;
	end
	firstpoint(1,m)=k;
end %m
out=firstpoint.*timeperpt;
firstlobe_time=out+stmatrix;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%Finds the largest arriving pulse in a measurement
ndp=length(filteredscanmatrix(:,1));  % can use size
ndf=length(filteredscanmatrix(1,:)); 
highestpoint=[];

for m=1:ndf
   maxpoint=max(filteredscanmatrix,[],1);
	k=1;
	while filteredscanmatrix(k,m)<maxpoint(m) 
		k=k+1;
	end
	highestpoint(1,m)=k;
end
maxlobe_time=highestpoint.*timeperpt;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
 
%Determine if maxlobe more than 1/2 pulse width behind firstlobe to give a 1st order metric of multipath
    pointer=[];
    for bb=1:1:nrdatafiles
        if maxlobe_time(bb) > firstlobe_time + templatewidth/2 
            pointer=[pointer bb];
        end
    end   
  if timestatplot==1
	plot(1:nrdatafiles,ntmatrix,'ms:')
	hold on;
	plot(1:nrdatafiles,maxlobe_time,'go-',1:nrdatafiles,firstlobe_time,'bx-.')
	plot(1:nrdatafiles,stmatrix,'r*-',1:nrdatafiles,etmatrix,'kd-.')
	hold off;
	ple=['Time Arrival of Peak Lobe with Respect to First Lobe (' datafilename ')_' date];
	title(ple);
	%text(18,5, [datadirectory] );
	xlabel('scan number');
	ylabel('time (nS)');
	legend('Noise Calc','Peak Lobe','First Lobe','RMS Start','RMS End');
	grid on;
	axis([0 nrdatafiles+1 0 tstop]);%max(etmatrix)+10]);
    figure(gcf+1)
  end %timestatplot  