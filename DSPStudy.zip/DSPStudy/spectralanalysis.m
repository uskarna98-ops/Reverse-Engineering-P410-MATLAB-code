function out=spectralanalysis(list,tpp)
% spectralanalysis.m
% 
% operation:
%    calculates the spectrum of the scanned waveform
%
% usage:
%    spectralanalysis(list,tpp)
%
%    inputs:
%			list=scan matrix with each column a unique scan.
%			tpp=time per point (in ns).
%
%    outputs:
%     out=  a matrix in which:
%		The first column represents the frequency at each point.
%		The remaining columns represent the PSD in dB of the data
%			"list".

% based on: 
%   Paul Withington
%   Time Domain
%   February 1999
%
% last edited by:
%   David J. Hall
%   Time Domain Systems, Inc.
%   26 July 2000
%   09:39


ndp=size(list,1);
%
fftlist=fft(list,2*ndp);
fullspectrum=20*log10(abs(conj(fftlist(1:ndp+1,:))));
fullfreq=[0:1/(2*tpp*ndp):1/(2*tpp)]';
out=[fullfreq fullspectrum];
%
%	Next calculate the x-axis (freq.) scale in GHz.
%
%		Calculate "maxfreq" the highest possible frequency that
%			could be sampled, i.e., 1/(2 smallest time step).
%		Calculate "minfreq", the smallest possible frequency that
%			could be sampled, i.e., 1/(2 total sample span).
%
%		This minimum frequency is sort of equivalent to RBW in a
%			spectrum analyzer's measurement.
%
% minfreq=1/(2*ndp*tpp);
% ptstoplot=floor(ndp/2);
% freqstep=(maxfreqdisplay-minfreq)/ptstoplot;
%
%		Now create a vector with the frequency of each sample point.
%
% freqspan=zeros(ptstoplot,1);
% for m=1:ptstoplot
% 	freqspan(m,1)=minfreq+(m-1)*freqstep;
% 	if freqspan(m,1)<maxfreqdisplay
% 		topfreqpt=m;
% 	end;
% end;
%
%	NB: "topfreqpt" is the point number below which the FFT
%	values are for frequencies below 5 GHz. Plot the results
%	of the spectral analysis, but only up to 5 GHz, because
%	that's really the upper limit of system performance.
%
%	Calculate the PSD in dB.
%		-- Can this be calibrated against an absolute PSD?
%
% logspec=log10(abs(complexspectrum(1:topfreqpt,:)).^2).*10;
% out=[freqspan logspec];

