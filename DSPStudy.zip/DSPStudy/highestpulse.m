function out=highestpulse(list,timeperpoint)
% highestpulse.m
%  Operation:
%      finds the largest arriving pulse in a measurement
%
%	Usage: highestpulse(list,timeperpoint)
%
%  Inputs:
%			list = [nrdatapts X nrdatafiles] matrix of scan data 
%           with each column representing a unique scan.
%			timeperpoint = the time increment per point (in nS)
%
%  Outputs:
%      out =[nrdatafiles] dimensioned vector  - the estimated time of arrival of the
%	    first pulse of all scans
%

% originally by Paul Withington
% last edited by:
%   David J. Hall
%   Time Domain Systems, Inc.
%   07 Aug 2000
%   17:12


ndp=length(list(:,1));  % can use size
ndf=length(list(1,:)); 
highestpoint=[];

for m=1:ndf
   maxpoint=max(list,[],1);
	k=1;
	while list(k,m)<maxpoint(m) 
		k=k+1;
	end
	highestpoint(1,m)=k;
end
out=highestpoint.*timeperpoint;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%