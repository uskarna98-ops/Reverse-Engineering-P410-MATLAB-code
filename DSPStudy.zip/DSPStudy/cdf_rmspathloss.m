
function cdf_rmspathloss(XX,rms2delay,span)
		count10=0;
      count20=0;
      count30=0;
      count40=0;
      
      for bb=1:length(XX)
         if XX(bb)>=(10-span/2) & XX(bb)<=(10+span/2)
            count10=count10+1;
            dist10(count10)=XX(bb);
            rms10(count10)=rms2delay(bb);
         elseif XX(bb)>=(20-span/2) & XX(bb)<=(20+span/2)
            count20=count20+1;
            dist20(count20)=XX(bb);
            rms20(count20)=rms2delay(bb);
         elseif XX(bb)>=(30-span/2) & XX(bb)<=(30+span/2)
            count30=count30+1;
            dist30(count30)=XX(bb);
            rms30(count30)=rms2delay(bb);
         elseif XX(bb)>=(40-span/2) & XX(bb)<=(40+span/2)
            count40=count40+1;
            dist40(count40)=XX(bb);
            rms40(count40)=rms2delay(bb);   
         end
      end   
      
      %Calculate CDF
      binnum=100;
      [z10,cdf10]=cdfcalc(rms10,binnum);
      [z20,cdf20]=cdfcalc(rms20,binnum);
      [z30,cdf30]=cdfcalc(rms30,binnum);
      [z40,cdf40]=cdfcalc(rms40,binnum);
      figure(gcf+1)
      plot(z10,cdf10,'b',z20,cdf20,'r',z30,cdf30,'k',z40,cdf40,'m')
      
      [muhat,sigmahat,muci,sigmaci] = normfit(rms10);
      	p10 = normcdf(min(rms10):max(rms10),muhat,sigmahat);
		[muhat,sigmahat,muci,sigmaci] = normfit(rms20);
      	p20 = normcdf(min(rms20):max(rms20),muhat,sigmahat);
      [muhat,sigmahat,muci,sigmaci] = normfit(rms30);
      	p30 = normcdf(min(rms30):max(rms30),muhat,sigmahat);
      [muhat,sigmahat,muci,sigmaci] = normfit(rms40);
      	p40 = normcdf(min(rms40):max(rms40),muhat,sigmahat);
      hold on   
      plot(min(rms10):max(rms10),p10,'b:')
      plot(min(rms20):max(rms20),p20,'r:')
      plot(min(rms30):max(rms30),p30,'k:')
      plot(min(rms40):max(rms40),p40,'m:')
      hold off
      axis([0 50 0 1])
      grid on;
      %legend('10 dB','20 dB','30 dB','40 dB',2)
      text(2,.65,'-10\pm5 dB \rightarrow','fontsize',12)
      text(33,.35,'\leftarrow -40\pm5 dB','fontsize',12)
      xlabel('\tau_r_m_s (ns)','fontsize',12);
		ylabel('Prob [\tau_r_m_s \leq abscissa]','fontsize',12);
     % title('Cumulative Distribution Function');
      
      %Lognormally distributed
      %[z10,cdf10]=cdfcalc(10*log10(rms10+1),binnum);
      %[z20,cdf20]=cdfcalc(10*log10(rms20+1),binnum);
      %[z30,cdf30]=cdfcalc(10*log10(rms30+1),binnum);
      %[z40,cdf40]=cdfcalc(10*log10(rms40+1),binnum);
      %figure(gcf+1)
		%plot(z10,cdf10,'b',z20,cdf20,'r',z30,cdf30,'k',z40,cdf40,'m')
      %axis([0 50 0 1])
      %grid on;
      %legend('10 feet','20 feet','30 feet','40 feet',2)
      %xlabel('10log_1_0(rms delay) (dB)');
		%ylabel('CDF');
      %title('Cumulative Distribution Function');
      