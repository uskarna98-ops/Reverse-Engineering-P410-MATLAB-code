function [g]=genwrite(distancedata,datafilename,datadirectory,direct,tt,CIRout,nrdatafiles,RAKEdB,...
   PEAKSused,excessdelay,meanexcessdelay,rms2delay,totpower,peakpower,peakV,rmsV,filenum,...
   threshdB)

cd(datadirectory)
FID3=fopen([datafilename '_' type num2str(round(threshdB)) '.out'],'w');

   	%Header *************************************************
      fprintf(FID3,'\n');
      fprintf(FID3,Title);
      fprintf(FID3,'\n');
      fprintf(FID3,'\n');
      
      fprintf(FID3,'d      ');
      for bb=1:1:nrdatafiles
         fprintf(FID3,' %6.1f   ',distancedata(bb));
      end
      fprintf(FID3,'\n');
      
      fprintf(FID3,'Pow(dB)');
      for bb=1:1:nrdatafiles
         fprintf(FID3,' %6.1f   ',10*log10(peakpower(bb)));
      end
      fprintf(FID3,'\n');
      
      fprintf(FID3,'Tot(dB)');
      for bb=1:1:nrdatafiles
         fprintf(FID3,' %6.1f   ',10*log10(totpower(bb)));
      end
      fprintf(FID3,'\n');
      
      fprintf(FID3,'PeakV  ');
      for bb=1:1:nrdatafiles
         fprintf(FID3,' %6.4f   ',peakV(bb));
      end
      fprintf(FID3,'\n');
      
      fprintf(FID3,'RMSV   ');
      for bb=1:1:nrdatafiles
         fprintf(FID3,' %6.4f   ',rmsV(bb));
      end
      fprintf(FID3,'\n');
      
      fprintf(FID3,'RMS(ns)');
      for bb=1:1:nrdatafiles
         fprintf(FID3,' %6.1f   ',rms2delay(bb));
      end
      fprintf(FID3,'\n');
      
      fprintf(FID3,'MN(ns) ');
      for bb=1:1:nrdatafiles
         fprintf(FID3,' %6.1f   ',meanexcessdelay(bb));
      end
      fprintf(FID3,'\n');
      
      fprintf(FID3,'EX(ns) ');
      for bb=1:1:nrdatafiles
         fprintf(FID3,' %6.1f   ',excessdelay(bb));
      end
      fprintf(FID3,'\n');
      
      fprintf(FID3,'RAK(dB)');
      for bb=1:1:nrdatafiles
         fprintf(FID3,' %6.2f   ',RAKEdB(bb));
      end
      fprintf(FID3,'\n');
      
      fprintf(FID3,'RAKPEAK');
      for bb=1:1:nrdatafiles
         fprintf(FID3,' %6.0f   ',PEAKSused(bb));
      end
      fprintf(FID3,'\n');
      
      
      fprintf(FID3,'\n');
      fprintf(FID3,'t       ');
      for bb=1:1:nrdatafiles
         if filenum(bb)<10
            header=[type '_#%1.0f    '];    
            fprintf(FID3,header,filenum(bb));
         elseif filenum(bb)<100
            fprintf(FID3,'CIR_#%1.0f   ',filenum(bb));
         else
            fprintf(FID3,'CIR_#%1.0f  ',filenum(bb));
         end 
      end
      fprintf(FID3,'\n');
      %End Header
            
      ple=['%.2f'];
      for bb=1:1:nrdatafiles
         ple=[ple ' %9.4f'];
      end   
      ple=[ple '\n'];
      
      for m=1:length(tt)
      	tempmatrix=[tt(m) ; CIRout(:,m)];
         fprintf(FID3,ple,tempmatrix);
      	%y=filteredscanmatrix(:,bb)';
      	%fprintf(FID3,'%.2f\n',y);
   	end %m
		g=1;
		fclose(FID3);