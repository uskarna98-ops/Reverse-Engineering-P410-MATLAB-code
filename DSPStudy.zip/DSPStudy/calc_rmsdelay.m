function [rmsdelay]=calc_rmsdelay(wave, timeperpt)
% rmsdelay.m
% 
% operation:
%    finds rmsdelay of data in scan waveform,
%      based on timeperpt time between samples

%Calculation on Waveform
wave=wave';
tt=(1:length(wave))*timeperpt;

     	%Mean Excess Delay Spread
         pt=wave;
         Pt=abs(pt).^2;
         tPt=tt.*Pt;
         meandelay=sum(tPt)./sum(Pt);
         mean_excess_delay=meandelay/1e-9;
                         
         %RMS Delay Spread
         %t2Pt=(t.^2).*Pt;
         t2Pt=(tt.^2).*Pt;
         t2 = sum(t2Pt)./sum(Pt);
         st=sqrt( t2 - meandelay.^2 );
         rmsdelay=st;
 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%