function [AoAon,RXcoord,TXcoordrel,scanmatrix, lockmatrix, distancedata, BER, EbNeff, ...
      timeperpt, nrdatapts,distfile,nrdatafiles,gain,txatt,rxatt,deltatflag,deltat,disttype...
      ]=read_EVK(datadirectory, datafilename,attenoff,maxnumberoffiles,hTX,hRX,...
   	antheightadj,offdB)

disp('>> Enter the filename extension of the data files.');
datafileextension=input('    (for example, files scan1.dat thru scan8.dat, entry is "dat" ).\n','s');

%Get idea of start file number, how many, and end file number
flag=0;
started=0;
	for n=1:maxnumberoffiles
      %FID = fopen([datadirectory datafilename num2str(n) '.txt']);
       %if FID==-1
         FID = fopen([datadirectory datafilename num2str(n) '.' datafileextension]);
         %Kick out of loop because end is found
         if FID==-1 & started==2
            break
            %end
     else
      	if flag==0
      		nstart=n;
            flag=1;
            started=1;
      	elseif flag==1
            nstop=n;
            started=2;
         end
      	fclose(FID);   
    end   
   end
%Display message if no data files found   
if flag==0
   disp(' ');
	disp(' ');
   disp('>>No scan files found; Check path and/or file name and restart program.');
   disp('>>press <CTRL>-C to end program');
   disp(' ');
   disp(' ');
   pause;
end   

nrdatafiles=nstop-nstart+1;
BER = zeros(nrdatafiles,1);
EbNeff = zeros(nrdatafiles,3);

for n=1:nstop-nstart+1
   
   filen=nstart+n-1;
   %datfile=[datadirectory datafilename num2str(filen) '.txt'];
   %FID = fopen(datfile);
   %if FID==-1
      datfile=[datadirectory datafilename num2str(filen) '.' datafileextension];
      FID = fopen(datfile);
      %end 
   if rem(n,10)==0   
      n 
   end
   
      %CoreBoardSN
   	  linedata=fgets(FID);
      chars=11;
      while (strncmp(linedata,'CoreBoardSN',chars))==0;
   	   linedata = fgets(FID);
      end
   	  CoreBoardSN(n,:)=str2num(linedata(chars+1:length(linedata)));
      
   	  %VGA
   	  linedata=fgets(FID);
      chars=3;
      while (strncmp(linedata,'VGA',chars))==0;
   	   linedata = fgets(FID);
      end
   	  VGA(n,:)=str2num(linedata(chars+1:length(linedata)));
      
      %DataIntegration
   	  linedata=fgets(FID);
      chars=15;
      while (strncmp(linedata,'DataIntegration',chars))==0;
   	   linedata = fgets(FID);
      end
   	  DataInt(n,:)=str2num(linedata(chars+1:length(linedata)));
            
      %ScanStepSize_ps
   	  linedata=fgets(FID);
      chars=15;
      while (strncmp(linedata,'ScanStepSize_ps',chars))==0;
   	   linedata = fgets(FID);
      end
   	  ScanStep(n,:)=str2num(linedata(chars+1:length(linedata)));
      timeperpt=ScanStep(n)*1e-3;
      if n>1
        if ScanStep(n)~=ScanStep(n-1)
           disp('  ')
           disp('  ')
           disp('>> Warning:  Datafiles have different Scan Step Sizes')
           disp('>> Press Enter to continue')
           pause
       end
      end  
            
      %ScanNumWords
   	  linedata=fgets(FID);
      chars=12;
      while (strncmp(linedata,'ScanNumWords',chars))==0;
   	   linedata = fgets(FID);
      end
   	  NumPts(n,:)=str2num(linedata(chars+1:length(linedata)));
      nrdatapts=NumPts(n);
      if n>1
        if NumPts(n)~=NumPts(n-1)
           disp('  ')
           disp('  ')
           disp('>> Warning:  Datafiles have different numbers of points')
           disp('>> Press Enter to continue')
           pause
        end
      end  
      
      %BitIntegration
   	  linedata=fgets(FID);
      chars=14;
      while (strncmp(linedata,'BitIntegration',chars))==0;
   	   linedata = fgets(FID);
      end
   	  BitInt(n,:)=str2num(linedata(chars+1:length(linedata)));

      %BER
   	  linedata=fgets(FID);
      chars=3;
      while (strncmp(linedata,'BER',chars))==0;
   	   linedata = fgets(FID);
      end
      if linedata(5:6)=='NA'
          BER(n,:)=0;
      else    
   	      BER(n,:)=str2num(linedata(chars+1:length(linedata)));
      end
      
      %Temp
   	  linedata=fgets(FID);
      chars=4;
      while (strncmp(linedata,'Temp',chars))==0;
   	   linedata = fgets(FID);
      end
   	  Temp(n,:)=str2num(linedata(chars+1:length(linedata)));
      
      %EbNeff
   	  linedata=fgets(FID);
      chars=6;
      while (strncmp(linedata,'EbNeff',chars))==0;
   	   linedata = fgets(FID);
      end
   	  EbNeff(n,1)=str2num(linedata(chars+1:chars+5));
      
      %Eb
   	  linedata=fgets(FID);
      chars=2;
      while (strncmp(linedata,'Eb',chars))==0;
   	   linedata = fgets(FID);
      end
   	  EbNeff(n,2)=str2num(linedata(chars+1:length(linedata)));
      
      %Neff
   	  linedata=fgets(FID);
      chars=4;
      while (strncmp(linedata,'Neff',chars))==0;
   	   linedata = fgets(FID);
      end
   	  EbNeff(n,3)=str2num(linedata(chars+1:length(linedata)));
      
      %TXATTN
   	  linedata=fgets(FID);
      chars=7;
      while (strncmp(linedata,'TXATTN:',chars))==0;
   	   linedata = fgets(FID);
      end
      if linedata(14)=='X'
          txatt(n,:)=0;
      else
          txatt(n,:)=str2num(linedata(chars+1:length(linedata)));
      end
      
      %RXATTN
   	  linedata=fgets(FID);
      chars=7;
      while (strncmp(linedata,'RXATTN:',chars))==0;
   	   linedata = fgets(FID);
      end
      if linedata(14)=='X'
          rxatt(n,:)=0;
      else    
   	      rxatt(n,:)=str2num(linedata(chars+1:length(linedata)));
      end
      
      %DISTANCE
   	  linedata=fgets(FID);
      chars=6;
      while (strncmp(linedata,'DISTANCE',chars))==0;
   	   linedata = fgets(FID);
      end
      if linedata(12)=='X'
          DISTANCE(n,:)=0;
      else    
   	      DISTANCE(n,:)=str2num(linedata(chars+1:length(linedata)));
      end
      
      %Data
   	  linedata=fgets(FID);
      chars=4;
      while (strncmp(linedata,'Data',chars))==0;
   	   linedata = fgets(FID);
      end
   	  %data(n,:)=str2num(linedata(chars+1:length(linedata)));
      %linedata = fgets(FID);
      data(n,:)=fscanf(FID,'%d',[1 inf]);
      scandata=data';
      %Close File
      fclose(FID);
      
   
   %Normalize Waveforms by accounting for External Attenuation and VGA Setting
   % External Attenuation
   if n==1 | n==2
      attenuation = 10^(( rxatt(n) + txatt(n) + offdB)/20);%account for offdB on first two scans
   else
      attenuation = 10^(( rxatt(n) + txatt(n) )/20);
   end   
      %Normalize to 0 dB attenuation
      scanmatrix(:,n)=attenuation*scandata(:,n);
      
%Read in VGA file if available
FID=fopen([datadirectory 'distance.txt']);
if FID>-1
   distfile=1;
   fgetl(FID);	
   line=fgetl(FID);
   if line(2)=='f'
      disttype=1;
   elseif line(2)=='m'
      disttype=2;
   else
      disp(' ')
      disp(' ')
      disp('>> Specification of feet or meters was not found in distance file ')
      disp('>> Default of feet is assumed')
      %pause
      disttype=1;
   end   
   distancedata = fscanf(FID, '%f');
   distancedata = distancedata';
   fclose (FID);      
      
   % VGA Gain Setting
   	VGApossible=[0 1 2 3 4 5 6 7 8 9 10 11 12 13 14 15 16 17 18 19 20 21 22 23 24 25 26 27 28 29 30 31];
    VGAgain=[0 0 0 0 .02 .25 .45 .53 .57 1.12 1.28 3.77 6.69 9.68 10.86 12.97 14.56 16.14 17.29 18.64 19.62 20.75 21.59 22.53 23.45 24.53 25.47 26.64 28.08 32.84 33.17 33.21];
    plot(VGApossible,VGAgain,'s-')
    title('VGA Actual Gain Versus VGA Control Setting (3.3k Resistor)')
    xlabel('VGA Control Setting')
    ylabel('VGA Actual Gain (dB)')
    grid
    i = find(VGApossible==VGA(n));
    VGAscale= 10^(( VGAgain(i) )/20);
      %Normalize to A00 VGA setting
   	scanmatrix(:,n)=scanmatrix(:,n)/VGAscale;
      gain(n)=VGAgain(i);
      
  %Check to make sure all files have same sampling resolution
   deltat(n)=timeperpt;
end;  %n

Number_of_files_read=n

%Read in Distancefile if available
FID=fopen([datadirectory 'distance.txt']);
if FID>-1
   distfile=1;
   fgetl(FID);	
   line=fgetl(FID);
   if line(2)=='f'
      disttype=1;
   elseif line(2)=='m'
      disttype=2;
   else
      disp(' ')
      disp(' ')
      disp('>> Specification of feet or meters was not found in distance file ')
      disp('>> Default of feet is assumed')
      %pause
      disttype=1;
   end   
   distancedata = fscanf(FID, '%f');
   distancedata = distancedata';
   fclose (FID);
   
    %IF USED, MUST BE RE-DONE FOR P200 ANTENNA*************************************  
    if antheightadj==1 & distfile>0
        disp(' ')
        disp(' ')
        disp('>> Adjustments for height based on Diamond Dipole Antenna Pattern ')
    if hTX>hRX | hTX<hRX
      %Compute angle for each distance
      for bb=1:length(distancedata)
      	ant_angle=180/pi*atan( abs(hTX-hRX) ./ distancedata(bb) );
         %Correction factor to normalize out height differential
         %  Equation taken from Excell curve fit
         %  Can never add to pathloss
         height_adjust= -0.0062*ant_angle^2 + 0.0131*ant_angle; %in dB
         height_adjust=10^(height_adjust/20); %Linear Voltage
         height_adjustLin=0.0000133196*(ant_angle)^3-0.001063716*(ant_angle)^2+0.0047927035*(ant_angle)+1 ;  
            
         scanmatrix(:,bb)=scanmatrix(:,bb)./height_adjust;
         
         h_adjust(bb)=20*log10(height_adjust);
         h_adjustLin(bb)=20*log10(height_adjustLin);
      end   
      disp(' ')
      disp(' ')
      disp('>> Scans Adjusted for Antenna Height')
    end
    end
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    TXcoordrel=zeros(nrdatafiles,3);
    RXcoord=zeros(2,3);
    AoAon=0;
end %if FID    

FID2=fopen([datadirectory 'position.txt']);
if FID2>-1
   	fgetl(FID2);	
   	line=fgetl(FID2);
   	if line(2)=='f'
   	   disttype=1;
   	elseif line(2)=='m'
   	   disttype=2;
   	else
   	   disp(' ')
   	   disp(' ')
   	   disp('>> Specification of feet or meters was not found in distance file ')
   	   disp('>> Default of feet is assumed')
   	   %pause
   	   disttype=1;
    end   
    fgetl(FID2); %skip a line
    RXcoord = fscanf(FID2,'%f%f%f',[3 inf]);
    RXcoord=RXcoord';
    fgetl(FID2); %skip a line
    coord = fscanf(FID2,'%f%f%f',[3 inf]);
    coord=coord';
    
    sizeRX=size(RXcoord);
    if sizeRX(1)==2
        AoAon=1;
        %Calculate Zero point from antenna coordinates
      	if RXcoord(1,1)<RXcoord(2,1)
         	xlower=RXcoord(1,1);
      	else   
            xlower=RXcoord(2,1);
        end 
      	zero_x=abs(RXcoord(1,1)-RXcoord(2,1))/2 + xlower;
      	if RXcoord(1,2)<RXcoord(2,2)
         	ylower=RXcoord(1,2);
      	else   
            ylower=RXcoord(2,2);
        end   
        zero_y=abs(RXcoord(1,2)-RXcoord(2,2))/2 + ylower;
        if RXcoord(1,3)<RXcoord(2,3)
         	zlower=RXcoord(1,3);
      	else   
            zlower=RXcoord(2,3);
        end   
        zero_z=abs(RXcoord(1,3)-RXcoord(2,3))/2 + zlower;
        zerocoord=[zero_x zero_y zero_z];
    else
        AoAon=0;
        zerocoord=RXcoord;
    end
    RXcoord=[RXcoord;zerocoord];
    
    %Calculate tag coordinates relative to zero point 
        TXcoordrel=[coord(:,1)-zero_x coord(:,2)-zero_y coord(:,3)-zero_z];
            
    %Distance calculated relative to center point of 2 antennas
      distancedata = sqrt( TXcoordrel(:,1).^2 + TXcoordrel(:,2).^2 + TXcoordrel(:,3).^2 );
      distancedata=distancedata';
      fclose(FID2);
   	distfile=1;
end
   
if FID<0 & FID2<0
    AoAon=0;
    distancedata = 1:nrdatafiles;
   	distfile=0;
   	disp(' ')
   	disp(' ')
   	disp('>> No distance.txt or position.txt file found; this will prevent a path loss calculation.')
   	%disp('>>Press spacebar to continue')
   	disp(' ')
   	%pause
   	disttype=3;
    TXcoordrel=zeros(nrdatafiles,3);
    RXcoord=zeros(2,3);
end 
n=n;

for b=1:nrdatafiles-1
   if deltat(b)==deltat(b+1)
   	deltatflag=0;   
   else
      deltatflag=1;
   end
end 

lockmatrix = zeros(nrdatapts,nrdatafiles);