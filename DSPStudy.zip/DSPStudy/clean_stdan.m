function [A,numpeaks,posneg_ratio,threshdBpre,threshdB,energyratio] = clean_stdan(P,W,Nit,ver,t1ref,cleanstop,filenum)
%CLEAN algorithm as described by Dr. R.A. Scholtz - short version
%P - input noisy signal - can be row or column
%W - template - can be row or column
%P and W must have the same sampling rate !!!
%Nit - number of iterations of the CLEAN algorithm >= 1
%A - channel impulse response - has the same size as P!
%clean -  constructed signal - Nit X length(P) matrix (contains history) 
%remainder - Nit X length(P) matrix (contains history)
%Rww - autocorrelation function for W
%Rpw - cross-correlation function between P and W

%Ensure DC offset removed from template and signal
P=P-mean(P);
%meanW=mean(W)
W=W-mean(W);
threshdBpre=5; 

[r,c] = size(P);
if r == 1
	P = P.';   % make it a column
end
[r1,c1] = size(W);
if r1 == 1
	W = W.';   % make it a column
end
M=length(W);
P=[P; zeros(2*M+1,1)]; %extended P
N=length(P);
%1. calculate Rpw
%Rpw1=[];
%PP=[P' zeros(1,N)];
%for k=1:N+2*M+1
%   tempW=[zeros(1,k-1) W' zeros(1,2*N-M-k+1)];
%   Rpw1=[Rpw1; sum(tempW.*PP)]; 
%end
%clear tempW
Wa=[zeros(1,N-M) W'];
if ver=='Rel_11'
    Rpw2 = xcorr(Wa,P);Rpw2=Rpw2(M:N+3*M)'; %version 5.3, Rel 11
    Rpw1=Rpw2;
elseif ver=='Rel_12'
    Rpw2 = xcorr(P,Wa');Rpw2=Rpw2(M:N+3*M); %version 6, Rel 12
    Rpw1=Rpw2;
else
    Rpw1=[];
    PP=[P' zeros(1,N)];
    for k=1:N+2*M+1
        tempW=[zeros(1,k-1) W' zeros(1,2*N-M-k+1)];
        Rpw1=[Rpw1; sum(tempW.*PP)]; 
    end
    clear tempW
end    
%figure(433)
%plot(Rpw1,'b.-')
%hold on
%plot(Rpw2,'r.:')
%hold off
%pause

%2. calculate Rww
%Rww1=[];
%WW=[W' zeros(1,2*N-M)];
%for k=1:N+2*M+1
%   tempW=[zeros(1,k-1) W' zeros(1,2*N-M-k+1)];
%   Rww1=[Rww1 sum(tempW.*WW)]; 
%end
%clear tempW
Wa2=[zeros(1,N-M) W'];
Rww2=xcorr(Wa2);


Rww2=Rww2(N:2*N-1);
Rww1=Rww2;


%3. CLEAN procedure
A1=zeros(1,N);         %initial values
A2=A1;
sigclean=[];
sigremain=[];
sigcleancur=zeros(1,N+M);
sigremaincur=[P' zeros(1,M)];
Rpwcur=Rpw1;

posnum=0;
negnum=0;
count=0;
stop=0;
%normr=1e-12;
for k=1:Nit
   count=count+1;
   t=(1:1:N+2*M+1);
   [Vmax,tmax]=max(abs(Rpwcur)); 
   if k==1
      A1ref=Rpwcur(tmax)/Rww1(1);
   end
   
   %If statement added to prevent overwriting of impulses
   if A1(tmax)==0
        	A1(tmax)=Rpwcur(tmax)/Rww1(1);
         	%Do psuedo-LED by moving t1ref forward in time
         	%if A1(tmax)>=A1ref/2
         	%   if tmax<t1ref
         	%      t1ref=tmax;
         	%   end
         	%end
         
            
         %Condition for optimal stopping   
            %r=conv(W,A1);
            Pnew=conv(W,A1);
            s=zeros(1,length(P));r=s;
            for bb=1:length(P)
               if bb>t1ref
                  s(bb)=P(bb);
                  r(bb)=Pnew(bb);
               end
            end
            norms=  sqrt( sum(   s .^2) );
            %normrlast=normr;
            normr=  sqrt( sum(   r .^2) );
            norms_r=sqrt( sum((s-r).^2) );
            %normrlastpeak=sqrt(max(r.^2));
            %(normr^2 - normrlast^2) / normrlast^2
            %disps=norms
            %dispr=normr
            %figure(888);plot(s);hold on;plot(r,'r');hold off;
            
            resit(k)=normr^2/norms^2;
         	relerror(k)=norms_r^2/norms^2;
            if cleanstop>1
               %Method 1 - Threshold Method
               if 20*log10(abs(A1(tmax))) < 20*log10(abs(A1ref))-cleanstop
                  stop=1;
               end
               threshdB=cleanstop;
            elseif cleanstop<1
         		%Method 2 - ||r||^2/||s||^2 Method   
               if normr^2/norms^2 > cleanstop
                  stop=1;
               end
               threshdB=20*log10(abs(A1ref))-20*log10(abs(A1(tmax)));
            end   
               
            
         if stop==1
				%A1(tmax)=0;numpeaks=count-1;
         	numpeaks=count;
         	break
         else
            
         %Method 3 - ||ri||^2/||ri-1||^2 Method   
         %if  (normr^2 - normrlast^2) / normrlast^2 < alpha
         % 	%A1(tmax)=0;numpeaks=count-1;
         %   numpeaks=count;
         %   threshdB=20*log10(abs(A1ref))-20*log10(abs(A1(tmax)));
         %	break
         %else
         
         %Method 4 - [ ||P||^2 - 1.61e-15 ] / ||P||^2 Method   
			%if normr^2/norms^2 > Alphafly
         %	%A1(tmax)=0;numpeaks=count-1;
         %   numpeaks=count;
         %   threshdB=20*log10(abs(A1ref))-20*log10(abs(A1(tmax)));
         %	break
         %else
         
         %Method 5 - ||r||^2/||s||^2 Method   
         %if abs(norms_r.^2/norms^2 + normr.^2/norms^2 - 1) < alpha
         %	%A1(tmax)=0;numpeaks=count-1;
         %   numpeaks=count;
         %   threshdB=20*log10(abs(A1ref))-20*log10(abs(A1(tmax)));
         %	break
         %else
            
            
         	%Add step to make sure tmax is at least length(Rww1)/2
         	%Basically this is the case of a pulse being cut by the front of the scan
         		if max((abs(tmax-t) + 1)) > length(Rww1)
            		endit=length(Rpwcur)- (max((abs(tmax-t) + 1)) - length(Rww1));
         		else
            		endit=length(Rpwcur);
         		end   
         	%%%%%%%%%%%%%%%%%%%%%5
         	sctemp=A1(tmax).*W'; 
   			sigcleancur(tmax:tmax+M-1)=sigcleancur(tmax:tmax+M-1) + sctemp;
   			sigremaincur(tmax:tmax+M-1)=sigremaincur(tmax:tmax+M-1) - sctemp;
           	Rpwcur(1:endit)=Rpwcur(1:endit) - A1(tmax).*Rww1(abs(tmax-t(1:endit)) + 1)';
           	sigclean=[sigclean; sigcleancur(1:N)];
         	sigremain=[sigremain; sigremaincur(1:N)];
         	if 20*log10(abs(A1(tmax))) < 20*log10(abs(A1ref))-threshdBpre & tmax<t1ref  
         	   A1(tmax)=0;
         	   count=count-1;
         	end   
         	numpeaks=count;
      	end
      	if A1(tmax)>0
         	posnum=posnum+1;
      	elseif A1(tmax)<0
         	negnum=negnum+1;
      	end
      
   else%Remove residual from location where impulse already found and continue
      	A1(tmax)=A1(tmax)+Rpwcur(tmax)/Rww1(1);
      	
      	A2(tmax)=Rpwcur(tmax)/Rww1(1);
         difdB=round( (20*log10(abs(A1ref))-20*log10(abs(A2(tmax))))*10)/10;
         if length(filenum)<30
            ple=['Residual found at ', num2str(tmax), ' on iteration ' num2str(k) ', ' num2str(difdB) ...
               ' dB down from peak. CLEAN continuing. . .'];
         	disp(ple)
            disp('  ')
            showmess=0;
         else
            showmess=1;
         end   
              	%Add step to make sure tmax is at least length(Rww1)/2
      	%Basically this is the case of a pulse being cut by the front of the scan
      	if max((abs(tmax-t) + 1)) > length(Rww1)
         	endit=length(Rpwcur)- (max((abs(tmax-t) + 1)) - length(Rww1));
      	else
         	endit=length(Rpwcur);
      	end   
      	%%%%%%%%%%%%%%%%%%%%%5
      	sctemp=A2(tmax).*W'; 
   		sigcleancur(tmax:tmax+M-1)=sigcleancur(tmax:tmax+M-1) + sctemp;
   		sigremaincur(tmax:tmax+M-1)=sigremaincur(tmax:tmax+M-1) - sctemp;
      	Rpwcur(1:endit)=Rpwcur(1:endit) - A2(tmax).*Rww1(abs(tmax-t(1:endit)) + 1)';
      	sigclean=[sigclean; sigcleancur(1:N)];
      	sigremain=[sigremain; sigremaincur(1:N)];
      
         
    end%if A1(tmax)==0
    %k
    %Div1=(norms_r^2) / (norms^2)
    %Div2=(normr^2) / (norms^2)
    %Ortho=( (norms_r^2) / (norms^2) + (normr^2) / (norms^2) - 1)
    %pause
          
end%k
%pause

energyratio=round((normr^2/norms^2)*1000)/1000;
if k==Nit
   numpeaks=count;
   threshdB=20*log10(abs(A1ref))-20*log10(abs(A1(tmax)));
   disp('  ')
   pleA=['Alpha condition not met. . .||r||^2/||s||^2=', num2str(round((normr^2/norms^2)*100)/100)];
   disp(pleA)
   disp('  ')
end   
   
if negnum>0
   posneg_ratio=posnum/negnum;
else
   posneg_ratio=posnum;
end   
%return to the original size
A(1,1:N-2*M-1)=A1(1,1:N-2*M-1);
%clean=sigclean(:,1:N-2*M-1);
%remainder=sigremain(:,1:N-2*M-1);
%Rww=Rww1(1:N-2*M-1);
%Rpw=Rpw1(1:N-2*M-1);
if r == 1
else
   A=A.';
end

%resit'
%relerror'
%pause

%figure(gcf+1)
%plot(P);hold on;plot(Pnew,'r');plot(P'-Pnew(1:length(P)),'m');hold off;            
%pause

