clear all; close all;
dnm = uigetdir('Choose the directory of the CAT log files');
CATDir = dir(fullfile(dnm, '*.csv')); % Searches for CSVs inside the chosen folder

for i = 1:max(size(CATDir))
    CATFile = fullfile(dnm,CATDir(i).name);
    [cnfg,scn] = my_read_cat_log(CATFile);
    eval([genvarname(['cnfg' num2str(i)]) ' = cnfg']);
    eval([genvarname(['scn' num2str(i)]) ' = scn']);
    clear cnfg scn
end



Response = 'no';
if max(size(CATDir)) > 1
    Response = uigetpref('config','scanparameters','CAT Logs CIR scans',['There are ' num2str(max(size(CATDir))) ' CAT Logs in the directory. If they all have the same scan parameters do you want to combine them?'],'Yes|No');
    if strcmp(Response,'yes') == 1
        timeperpt =  scn1(1).ScnStepbins/(512 * 1.024);
        Ts = timeperpt * 1e-9;
        tempwidth=6.0;
        disttype = 1;
        direct=pwd;
        AoAon = 0;
        distfile = 0;
        timebaseoff = 0;
        nrdatast = 0;
        deltatflag = 0;
        datafilename = 'xxxxxxxxxxxxxx';
        nrdatapts = max(size(scn1(1).scndata));
        j = 0;
        for k = 1:max(size(CATDir))
            i = 0;
            for m = 1:max(size(eval(['scn' num2str(k)])))
                j = j + 1;
                i = i + 1;
                scanmatrix(:,j+1) = [eval(['scn' num2str(k) '(' num2str(i) ').scndata'])];
                deltat(j+1) = timeperpt;
                deltat(1) = timeperpt;
            end
        end
        nrdatafiles = j + 1;
        lockmatrix = zeros(nrdatapts,nrdatafiles);
        distancedata = zeros(1,nrdatafiles);
        xtag = zeros(nrdatafiles,1);
        ytag = xtag;
        BER = xtag;
        txatt = xtag;
        rxatt = xtag;
        RXcoord = zeros(2,nrdatafiles+1);
        EbNeff = RXcoord;
        VGA = zeros(1,nrdatafiles);
        nrdatasp = nrdatafiles;
        meas_sys = 'DSO';
        
        %Selecting which template to use
        Response = uigetpref('radio','transmitter','Radio Transmitter Model','Which model of radio is used as a transmitter?','P400 with Amp|P410 without Amp|P410 with Amp');
        uisetpref('clearall');
        if strcmp(Response,'p400 with amp') == 1
            %HHRevC w/Amp known as P400 w/Amp, Normalized Template at 32 bins stepsize
            P400_w_Amp_Tmplt;
            Template = P400_w_Amp_TmpltWfm;
        elseif strcmp(Response,'p410 without amp') == 1
            %Mako wo/Amp known as P410 wo/Amp, Normalized Template at 32 bins stepsize
            P410_wo_Amp_Tmplt;
            Template = P410_wo_Amp_TmpltWfm;
        elseif strcmp(Response,'p410 with amp') == 1
            P410_w_Amp_Tmplt;
            Template = P410_w_Amp_TmpltWfm;
        end
        Template = [Template;zeros(nrdatapts-max(size(Template)),1)];
        scanmatrix(:,1) = Template;
        
    elseif strcmp(Response,'no') == 1 %if response is no then the first CAT log in the directory is used for scans
        timepert = stepbins/(512*1.024);%timeperpt =  scn1(1).ScnStepbins/(512 * 1.024);
        Ts = timeperpt * 1e-9;
        nrdatapts = max(size(scn1(1).scndata));
        nrdatafiles = max(size(scn1)) + 1;
        tempwidth=6.0;
        disttype = 1;
        lockmatrix = zeros(nrdatapts,nrdatafiles);
        distancedata = zeros(1,nrdatafiles);
        xtag = zeros(nrdatafiles,1);
        ytag = xtag;
        BER = xtag;
        txatt = xtag;
        rxatt = xtag;
        RXcoord = zeros(2,nrdatafiles+1);
        EbNeff = RXcoord;
        deltatflag = 0;
        VGA = zeros(1,nrdatafiles);
        distfile = 0;
        timebaseoff = 0;
        nrdatast = 0;
        nrdatasp = nrdatafiles;
        meas_sys = 'DSO';
        AoAon = 0;
        datafilename = 'xxxxxxxxxxxxxx';
        direct=pwd;
        i = 0;
        for m = 2:max(size(scn1)) + 1
            i = i + 1;
            scanmatrix(:,m) = [scn1(i).scndata];
            deltat(m) = timeperpt;
            deltat(1) = timeperpt;
        end
        
        %Selecting which template to use
        Response = uigetpref('radio','transmitter','Radio Transmitter Model','Which model of radio is used as a transmitter','P400 with Amp|P410 without Amp|P410 with Amp');
        uisetpref('clearall');
        if strcmp(Response,'p400 with amp') == 1
            %HHRevC w/Amp known as P400 w/Amp, Normalized Template at 32 bins stepsize
            P400_w_Amp_Tmplt;
            Template = P400_w_Amp_TmpltWfm;
        elseif strcmp(Response,'p410 without amp') == 1
            %Mako wo/Amp known as P410 wo/Amp, Normalized Template at 32 bins stepsize
            P410_wo_Amp_Tmplt;
            Template = P410_wo_Amp_TmpltWfm;
        elseif strcmp(Response,'p410 with amp') == 1
            P410_w_Amp_Tmplt;
            Template = P410_w_Amp_TmpltWfm;
        end
        Template = [Template;zeros(nrdatapts-max(size(Template)),1)];
        scanmatrix(:,1) = Template;
    end
elseif max(size(CATDir)) == 1
    timeperpt =  scn1(1).ScnStepbins/(512 * 1.024);
    Ts = timeperpt * 1e-9;
    nrdatapts = max(size(scn1(1).scndata));
    nrdatafiles = max(size(scn1)) + 1;
    tempwidth=6.0;
    disttype = 1;
    lockmatrix = zeros(nrdatapts,nrdatafiles);
    distancedata = zeros(1,nrdatafiles);
    xtag = zeros(nrdatafiles,1);
    ytag = xtag;
    BER = xtag;
    txatt = xtag;
    rxatt = xtag;
    RXcoord = zeros(2,nrdatafiles+1);
    EbNeff = RXcoord;
    deltatflag = 0;
    VGA = zeros(1,nrdatafiles);
    distfile = 0;
    timebaseoff = 0;
    nrdatast = 0;
    nrdatasp = nrdatafiles;
    meas_sys = 'DSO';
    AoAon = 0;
    datafilename = 'xxxxxxxxxxxxxx';
    direct=pwd;
    i = 0;
    for m = 2:max(size(scn1)) + 1
        i = i + 1;
        scanmatrix(:,m) = [scn1(i).scndata];
        deltat(m) = timeperpt;
        deltat(1) = timeperpt;
    end

    
    %Selecting which template to use
    Response = uigetpref('radio','transmitter','Radio Transmitter Model','Which model of radio is used as a transmitter','P400 with Amp|P410 without Amp|P410 with Amp');
    uisetpref('clearall');
    if strcmp(Response,'p400 with amp') == 1
        %HHRevC w/Amp known as P400 w/Amp, Normalized Template at 32 bins stepsize
        P400_w_Amp_Tmplt;
        Template = P400_w_Amp_TmpltWfm;
    elseif strcmp(Response,'p410 without amp') == 1
        %Mako wo/Amp known as P410 wo/Amp, Normalized Template at 32 bins stepsize
        P410_wo_Amp_Tmplt;
        Template = P410_wo_Amp_TmpltWfm;
    elseif strcmp(Response,'p410 with amp') == 1
        P410_w_Amp_Tmplt;
        Template = P410_w_Amp_TmpltWfm;
    end
    Template = [Template;zeros(nrdatapts-max(size(Template)),1)];
    scanmatrix(:,1) = Template;
end
stepbins = scn1(1).ScnStepbins;
if isempty(stepbins) || ~isfinite(stepbins) || stepbins <= 0
    stepbins = 32;   % CatConfig ScanStepSizeBins
    warning('ScnStepbins invalid in scan rows; using CatConfig value (32).');
end
timeperpt = stepbins/(512*1.024);   % ns per sample, about 0.0610
Ts = timeperpt*1e-9;
STDANforCATDemo;


