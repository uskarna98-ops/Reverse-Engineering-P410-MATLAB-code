function waveinfo=waveshape(wave,peakval,peakpts,maxcorrelators,...
    timeperpt,filenum,maxlobe_time)
% waveshape.m
%   Operation:
%   
%   Usage: 
%   [waveinfo, waves]=waveshape(wave, peakval, peakpts, maxcorrelators,
%           timeperpt, filenum, maxlobe_time)
%
%   inputs:
%      wave   is a vector containing the input waveform
%      peakval  is a vector containing the sorted peak values of the lobes in the wave.
%      peakpts  is a vector containing the sorted times of the lobes in the wave.
%      maxcorrelators is a scalar containing the largest number of correlators in the wave
%		 timeperpt is the time per point in nS
%      filenum is the file number being used as the wave vector
%      maxlobe_time is the time in nS that the maximum lobe happens in the pulse.
%
%   outputs:
%      waveinfo is a matrix of dimension [maxcorrelators x 5],
%         each row of which contains the following data (in nS):
%         value        value of the maximum peak
%         peaktime     time of the maximum peak
%         fronttime    time between the maximum peak and the zero crossing before it
%         backtime     time between the maximum peak and the zero crossing after it
%         totaltime    fronttime+backtime
%
%      waves is a vector containing the 200 points evenly spaced about
%         the center of the main lobe.
%

% by David J. Hall
% Time Domain Corporation
% 21 Sep 2000
% 13:15
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% 

peakval;
peakpts;
maxcorrelators;
timeperpt;
filenum;
maxlobe_time;

waveinfo=zeros(maxcorrelators,5);
for k=1:maxcorrelators
   % find peak value
   %  look within 0.2 nS of maximum value indicated by tpeakpts.
   startpoint=max( [round(peakpts(k)-(0.2-maxlobe_time(filenum))/timeperpt)  1]);
   endpoint=min([ round(peakpts(k)+(0.2+maxlobe_time(filenum))/timeperpt)   length(wave)]);
   value=max( abs(wave(startpoint : endpoint  ) )  );
    
   % find peaktime
   peaktime=-999;
   for l = startpoint : endpoint
      if abs(wave(l))>=value
         peaktime=l;
      end;
   end
   peaktime;
   
   % find fronttime
   for l= peaktime: -1 : 2
      if sign(wave(l))*sign(wave(l-1))== -1
         fronttime=l;
         break;
      end;         
   end;
   fronttime=peaktime-fronttime;
   
   % find backtime
   for l= peaktime: length(wave)
      if sign(wave(l-1))*sign(wave(l))== -1
         backtime=l;
         break;
      end;         
   end;
   backtime=backtime-peaktime;
   
   % add fronttime + backtime = totaltime
   totaltime=fronttime+backtime;
   
   % multiply everything by tpeakpts to make output nS
   peaktime=peaktime*timeperpt;
   fronttime=fronttime*timeperpt;
   backtime=backtime*timeperpt;
   totaltime=totaltime*timeperpt;
   
   % output 5 parameters of interest
   waveinfo(k,:)=[value peaktime fronttime backtime totaltime];
     
end  % k
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%