function [powersum1,difpow,freeref,relpower]=calc_pathloss(nrdatafiles,corr,tpeakval,distancedata,choptozero,...
        percent_less,calc_N90,Kmon,calc_Km90,disttype,offdB);


   powersum=zeros(1,nrdatafiles);
   for l=1:corr 
      	powersum1=powersum+tpeakval(l,:).^2;
   end;
  
        
   %Reference to peak of 1st scan,
   	refnorm=powersum1(1);
    refd=distancedata(1);
    powersum1=powersum1/refnorm;


%Force PathlossData to be less than 0 dB ---------------------------------------------
if choptozero==1
	for bb=1:length(powersum1)
   	  if powersum1(bb)>1
      	powersum1(bb)=1;
   	  end;
    end  
end   

%Calculate Curve Fits on combined datasets ------------------------------------------
   freeref=-20*log10(distancedata/min(distancedata));
   relpower=(20*log10(sqrt(powersum1)));
   difpow=-(freeref-relpower);
   

   
%Pathloss -------------------------------------------------------------------------      
term=relpower;
[distdat1,N,K,ya,y,y90N,y90K,M_N,stdev_N,M_K,stdev_K,percent]=curvefit(distancedata,term,percent_less);

[g]=plot_pathloss(term,nrdatafiles,corr,tpeakval,distancedata,choptozero,percent_less,calc_N90,Kmon,calc_Km90,...
      disttype,offdB,distdat1,N,K,ya,y,y90N,y90K,M_N,stdev_N,M_K,stdev_K,percent);