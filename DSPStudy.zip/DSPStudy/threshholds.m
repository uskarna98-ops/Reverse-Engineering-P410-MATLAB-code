function out=threshholds(list,timeperpt)
% threshholds.m
% 
% operation:
%    finds the statistical characteristics of the array list
%
% usage: 
%    threshholds(list, timeperpt)
%
%    inputs:
%			list[][] is a matrix of scan data with each column
%				representing a unique scan.
%        timeperpt is the time per point in nS.
%
%    outputs:
%	      The function returns a variable that is 2 x (the number of columns in list[]).
%        The first row of out[] contains the standard deviation of the first 2 nS of each run.
%        The second row of out[] contains the standard deviation of each run in its entirety.
%

%
% last edited by:
%   David J. Hall
%   Time Domain Systems, Inc.
%   07 Aug 2000
%   13:22

ndp=length(list(:,1));  % number of data points on scan channel per file
ndf=length(list(1,:));  % number of input files
out=zeros(2,ndf);
numrows=round(2/timeperpt);  % number of points making up first 2 nS of run.
for m=1:ndf
   out(1,:)=std(list(1:numrows, :));  % standard deviation of first 2 nS
   out(2,:)=std(list(1:ndp, :));      % standard deviation of entire row
end;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%