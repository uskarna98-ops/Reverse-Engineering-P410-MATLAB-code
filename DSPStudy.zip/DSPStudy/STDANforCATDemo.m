% stdan.m
% close all
% clear

%User Defined Parameters ********************************************************************************
ver='Rel_12';	%Matlab Version
offdB=0;
%CLEAN Stuff
  alpha=0.7;		
  chanthreshdB=25; %CHAN rms threshold 
  cleanstop=chanthreshdB; %Set to either alpha or chanthreshdB to change CLEAN stopping criteria
  CLEANNit=200;
  rakes=4;
%AoA Stuff
  cable_delayns  = 8 ; 
  Naoa=2;
hRX=0.833;
hTX=3.33;
maxfreqdisplay=6;
maxpeaks=5;
startthreshhold=4.5; %SCAN rms 
endthreshhold=1.7;  %SCAN rms 
step=3;			    %SCAN rms step-up factor
corr1=1;  %Number of correlators for pathloss calc

%maindirectory=['c:\analysis\PRE-EVK\'];
%maindirectory=['c:\analysis\'];
%maindirectory=['q:\propagation\data\'];
%maindirectory=[];
%maindirectory= 'J:\40GB Hard Drive\Local Disk (G)\TDC\Tacom\Analysis Data\3.1.1 A Test';
maindirectory = 'J:\STDAN Matlab for CAT\CAT Matlab\Two scan Test - Copy'; %I wonder what this is. Might cause our file some errors
%maindirectory = "F:\Radio Tools\New folder\140-0023F Cat Sftw & Lit\140-0023F Cat Sftw & Lit\2-Host & Sample Code\CATCIR Delivery Files\CATCIR\CatLog_000.csv"; %I hope this fixes it 
datadirectory= maindirectory; %added to fake out functions below

scandisp		 =  1;  % 0=three per figure, 1=Compared with Channel Impulse, 2=off
   tstart        =  0;
   tstop         =  1;   %1=maximum window of scan file (ns)
   zoomon		 =  0;
  
setrange         =  0;
P300stuffon      =  1; %will be turned off if P300 description files not found
distinmeters	 =  1; %forces distance to meters
timestatplot    =   0;
%AoA Stuff
  firsttemp		 =  1;
  firstpeak4	 =  1;
  chooseLED		 =  4;
%Pathloss Stuff
  choptozero     =  0;
  percent_less   = 89;
  calc_N90       =  0;
  Kmon           =  0;
  calc_Km90      =  0;
antheightadj     =  0;
normscans		 =  0;
envelopeshow	=	0;	if envelopeshow==1;scandisp=1;end
windowlength    =   1.0;   % length of envelope window in nS
attenoff		 =  0; %Controls accounting for attenuation recorded in scan files
filterscans		 =  0; %Controls filtering 0=Remove DC Offset, 1=FIR filter
showunfiltered   =  0;
LEDon			 =  0;
printallfigure	=	0;
%CIR Stuff
  chanimpulse	 =  1;
  chandisp	     =  1;  if scandisp==2;chandisp=0;end   
  RAKEplot	     =  0;
  scatdisplay	 =  0;
  ratiodisplay   =  0;
%Frequency Stuff  
  calcspec       =  0;
  narrowcompare  =  0; %do comparison to 2.4 GHz 
  spectrumdisp	 =  0;  if spectrumdisp==1;calcspec=1;end
%Text File Stuff 
  writeoutput 	 =	0;
  writeCIR 		 =  0;
  writeWAVE		 =	0;    % whether or not waveform scan data is output in output file
   if setrange==0
      writeoutput=1;
   end   

maxnumberoffiles=550;

if scandisp==1 & chandisp==0 & envelopeshow==0
   scandisp=0;
end   


%Start clock to measure elapsed time ************************************************************* 
timenow=cputime;


%User Input and Displays to User *****************************************************************
%     [meas_sys,datadirectory,direct,datafilename,nrdatast,nrdatasp,maxnumberoffiles]=...
%         user_inputs(setrange,chanimpulse,maindirectory,maxnumberoffiles);

    
%Read in the datafiles ***************************************************************************
%    disp(' ');
%    disp(' ');
%    disp('Reading data files. . .');  
%    [AoAon,xtag,ytag,RXcoord,scanmatrix, lockmatrix, distancedata, BER, EbNeff,timeperpt,nrdatapts,...
%         distfile,nrdatafiles,VGA,txatt,rxatt,deltatflag,deltat,disttype,timebaseoff,tempwidth,Ts]=...
%         read_data(meas_sys,datadirectory,datafilename,attenoff,maxnumberoffiles,hTX,hRX,antheightadj,offdB);   
  
%Take care of distance units and scale according to setrange parameter ****************************
   [nrdatafiles,nrdatapts,nrdatasp,scanmatrix,lockmatrix,distancedata,xtag,ytag,RXcoord,BER,...
        EbNeff,VGA,txatt,rxatt,deltat,timebaseoff,filenum,tstop,disttype]=size_inputs(distinmeters,disttype,...
        distancedata,tstop,nrdatapts,timeperpt,scanmatrix,lockmatrix,setrange,nrdatast,nrdatasp,...
        nrdatafiles,AoAon,xtag,ytag,RXcoord,BER,EbNeff,VGA,txatt,rxatt,deltat,timebaseoff); 
   
%Read in P300 Flag data ****************************************************************************
[los,stud,pol,genloc,walls,datavalid,P300stuffon]=read_P300(nrdatafiles,datadirectory,setrange,nrdatast,nrdatasp);


%Create a vector with the time at each data point (in nanoseconds) *********************************
pointtime=timeperpt*(0:nrdatapts-1)';


%Either remove DC Offset or FIR filter incoming scans, check for uniform sampling resolution ******
[filteredscanmatrix]=filter_scans(scanmatrix,deltatflag,filterscans,nrdatafiles);


%Calculating time statistics on waveform *********************************************************
disp(' ');
disp(' ');
disp('Calculating time statistics. . .');
stmatrix=zeros(1,nrdatafiles);etmatrix=zeros(1,nrdatafiles);
counter=0;
for k=1:nrdatafiles
   counter=counter+1;p=counter;
   if rem(p,10)==0
      p
   end    
   t=pointtime;	
   [stmatrix(k),etmatrix(k), envelope,noiselevel(k),choices(k),glitchflags(k),ntmatrix(k),stepup]=...
       calc_times(k,filteredscanmatrix(:,k),t, startthreshhold , timeperpt, endthreshhold,step,windowlength);%1.4
    envel(k,:)=envelope;
    startlevel(k,:)=[endthreshhold*noiselevel(k)*ones(1,stepup) step*endthreshhold*noiselevel(k)*ones(1,length(envelope)-stepup)];
end
n

% Calculate and Plot arrival times of waveforms *************************************************
    [pointer,maxlobe_time]=calc_plot_times(filteredscanmatrix, stmatrix, etmatrix, ntmatrix,...
        timeperpt,timestatplot,tempwidth,datafilename,nrdatafiles,tstop);
 

%Calculating Peaks ******************************************************************************
disp(' ');
disp(' ');
disp('Calculating peaks. . .');
tops=calc_peaks(filteredscanmatrix,maxpeaks,1,(tempwidth/2),timeperpt);%.65
for m=1:nrdatafiles
	tpeakpts(:,m)=tops(:,2*m-1)-maxlobe_time(m)/timeperpt;  % subtract out delay for each run relative to maxlobe of each run
	tpeakval(:,m)=tops(:,2*m);
end


%Set distance limits ****************************************************************************
if max(distancedata)<=100
   maxxpoint=ceil(max(distancedata)/10)*10;
else
  	maxxpoint=ceil(max(distancedata)/100)*100;
end    
if min(distancedata)>=10
   minpoint=10;
else
  	minpoint=0;
end


%Calculate Eb, Neff, Eb/Neff from scans *******************************************************
for k=1:nrdatafiles
   Eb_scan(k) = 10*log10( max(abs(filteredscanmatrix(:,k)))^2);
   Neff_scan(k) = 10*log10(2*var( filteredscanmatrix(1: round(ntmatrix(k)/timeperpt),k)));
   EbNeff_scan(k)=10*log10( max(abs(filteredscanmatrix(:,k)))^2 / (2*var( filteredscanmatrix(1: round(ntmatrix(k)/timeperpt),k)))  );
end 


%FILE Eb, Neff, & Eb/Neff  **********************************************************
%    figure(gcf+1)
%    off2=-EbNeff(1,2);
%    EbNeff(:,2:3) = EbNeff(:,2:3)+off2;   
%    plot(1:nrdatafiles,  EbNeff(:,2),'rs',1:nrdatafiles,EbNeff(:,3),'r+',1:nrdatafiles,EbNeff(:,1),'bd');
%    xlabel('scan number');
%    axis([0 max(nrdatafiles) floor(min(min(EbNeff))/10)*10-5 ceil(max(max(EbNeff))/10)*10+5]);
%    legend('Eb','Neff','EbNeff',3)
% 	ple=['EVK Eb, Neff, and Eb/Neff (' datafilename ')_' date];
% 	title(ple);
%    grid on;
%    text(1,10,'Values DO NOT take into account VGA or External Attenuation')
%    ylabel('(dB)');


%SCAN Signal & Noise Power  **********************************************************
%    figure(gcf+1)
%    off2=-Eb_scan(1);
%    Eb_scan = Eb_scan+off2;   Neff_scan = Neff_scan+off2;
%    plot(1:nrdatafiles,  Eb_scan','rs',1:nrdatafiles,Neff_scan','r+',1:nrdatafiles,Eb_scan'-Neff_scan','bd');
%    xlabel('scan number');
%    axis([0 max(nrdatafiles) floor(min(min(Neff_scan))/10)*10-5 ceil(max(max(Eb_scan'-Neff_scan'))/10)*10+5]);
%    legend('scan Signal(V^2)','scan Noise(2sigma^2)','scan SNR',3)
% 	ple=['SCAN Signal, Noise and SNR (' datafilename ')_' date];
% 	title(ple);
%    grid on;
%    text(1,10,'Values DO take into account VGA and External Attenuation')
%    ylabel('(dB)');



%SCAN Pathloss vs Distance   ****************************************************************************
if distfile==1 %Only do this if distance file present
	[powersum1,difpow,freeref,relpower]=calc_pathloss(nrdatafiles,corr1,tpeakval,distancedata,choptozero,...
        percent_less,calc_N90,Kmon,calc_Km90,disttype,offdB);
else
   powersum1=(10.^(Eb_scan')./20)';
   difpow=zeros(1,length(distancedata));
   freeref=zeros(1,length(distancedata));
   relpower=zeros(1,length(distancedata));
end

   
%Calculate Scan RMS delay spread  ********************************************************************
rms=zeros(1,nrdatafiles);
for k=1:nrdatafiles
   [rms(k)]=calc_rmsdelay(filteredscanmatrix(round(stmatrix(k)/timeperpt):round(etmatrix(k)/timeperpt),k),timeperpt);
end %k 
% [rmsplot,yhattilderms]=plot_rmsdelay(distfile,filenum,disttype,distancedata,rms,chanimpulse,...
%     minpoint,maxxpoint,endthreshhold);


   
% LED Calculations ******************************************************************************
[startLE,stopLE,DoAfig,LE,LE2,LE3,LEAoA,LE_2,LE_2truth,DoA,DoAtruth,PEAK1,PEAK2,thetaAoA,...
            thetaREAL,NLOS,LEDon,templatestart]...
            =calc_LED(AoAon,LEDon,tempwidth,RXcoord,xtag,ytag,cable_delayns,...
            filenum,nrdatafiles,nrdatapts,filteredscanmatrix,timeperpt,chooseLED,Ts,firsttemp,...
            tstart,tstop,distfile,disttype,Naoa,EbNeff_scan,firstpeak4,distancedata);



%   Scanned Waveforms vs Time *****************************************************************
if scandisp~=2
[scanfig]=plot_scans(scandisp,nrdatafiles,envelopeshow,LE,LE2,LE3,LEAoA,LE_2,...
        LE_2truth,LEDon,AoAon,normscans,filteredscanmatrix,scanmatrix,pointtime,tstart,tstop,...
        filenum,showunfiltered,startlevel,envel);
end



%Calculate Peak to RMS voltage ****************************************************************
for bb=1:1:nrdatafiles
   [SpeakV(bb),SrmsV(bb)]=calc_rmsV(filteredscanmatrix(:,bb));
end   
SrmsV=SrmsV/SpeakV(1);
SpeakV=SpeakV/SpeakV(1);


%Calculate Actual LOS for P300 measurement setup *********************************************
if P300stuffon==1 & distfile==1
   %Speed of light related stuff
		c=3e8;                          %speed of light, meters per second
		feet_per_meter=100/2.54/12;     %conversion factor
		cftps=feet_per_meter*c/1e12;    %c, in feet per picosecond
		nsperft = 1/cftps/1000;         %distance light travels in one nsec
   tlos=distancedata.*39.36/12*nsperft; %ns
   tcalclos=22+14.8+5.93+tlos - rem(timebaseoff,104.17);
else
   tcalclos=zeros(1,nrdatafiles);
end 

%Calculate Channel Impulse Response *********************************************************
   disp(' ');
   disp(' ');
   disp('Calculating Channel Impulse Response. . .');
if chanimpulse==1 %Find starting time of the first scan to eliminate noise from the template
   %If not doing LED, use old stmatrix for CLEAN templatestart
   if LEDon==0
       %       for bb=1:1:length(pointtime)
       %    		if pointtime(bb)==stmatrix(1)
       %          	templatestart=bb-8;%The 8 is empirically chosen
       %    		end
       %       end
       templatestart = 1;
   end
   %Find Shift time
	 [q,i]=max(filteredscanmatrix(:,1));
	 shifttime=t(i);
   if scandisp==2;scanfig=100;end
   [CIRout,CIRpeakV,CIRrmsV,Numpeaks,PNratio,RAKEdB,PEAKSused,excessdelay,peakpower,meanexcessdelay,...
       rms2delay,numpaths,peakpowerratio,totpower,relerror,angerror,CIRLOS,Eratio,P,Pnew,DoAclean]=chan_clean(tempwidth,rakes,CLEANNit,...
       distancedata,writeCIR,datafilename,datadirectory,direct,filteredscanmatrix, nrdatafiles, Ts,...
       templatestart,scandisp,scanfig,tstart,tstop,shifttime,envelopeshow,chandisp,...
       scanfig,normscans,ver,filenum,zoomon,P300stuffon,tcalclos,cleanstop,AoAon,startLE,stopLE);
    DoAclean=DoAclean-cable_delayns;
else
   rms2delay=zeros(1,nrdatafiles);
   numpaths=zeros(1,nrdatafiles);
   peakpowerratio=zeros(1,nrdatafiles);
   totpower=zeros(1,nrdatafiles);
   cleanstop=0; 
end %chanimpulse

    if AoAon==1 & chanimpulse==1
      nowfig=gcf;
      figure(DoAfig)
      hold on;
      plot(filenum,DoAclean*1000,'rs');;
      plot(filenum,(DoAclean*1000)-(DoAtruth*1000),'b+');
      hold off;
      title('DoA Calculation versus Truth')
   	  xlabel('Scan #')
      ylabel('DoA (ps)') 
      legend('DoA Truth','DoA Calculated','Error','DoA Clean','Clean Error')
      grid on;
      figure(nowfig);
      [filenum' DoAtruth' DoA' DoAclean'];
    end  

 
%Plot:  RMS, Mean, and Excess Delay spread CIR ********************************************
        %RAKE gain/number of peaks used, Peak power ratio, Number of scatterers within threshold 
%  if chanimpulse==1
%      [g]=plot_chanstuff(RAKEplot,scatdisplay,ratiodisplay,rmsplot,rms2delay,meanexcessdelay,...
%             excessdelay,filenum,rms,endthreshhold,cleanstop ,RAKEdB,PEAKSused,distancedata,...
%             rakes,disttype,distfile,minpoint,maxxpoint,numpaths,peakpowerratio,yhattilderms);
%  end       
         

%Calculate Frequency Spectrum ***************************************************************
if calcspec==1
    disp(' ');
	disp(' ');
    disp('Calculating Spectrum. . .');
    disp(' ');
    [g]=calc_spectrum(narrowcompare,spectrumdisp,filteredscanmatrix,filenum,nrdatapts,timeperpt,...
        maxfreqdisplay,nrdatafiles,distancedata,powersum1,disttype);
end    
   

SaveCIR = uigetpref('RFChannel','CIR','Save CIR to a text File','Do you want to save the CIR results to a text file?','yes|no');
if strcmp(SaveCIR,'yes') == 1
    [CIRResultsFilename, CIRResultsPathname, FILTERINDEX] = uiputfile('*.*', 'Where do you want to save the CIR results and what is the filename?');
    datadirectory = CIRResultsPathname;
    datafilename = CIRResultsFilename;
    writeoutput==1;
    chanimpulse==1;
    writeCIR = 1;
end



%Write Data to Text File   ********************************************************************
if writeoutput==1 & chanimpulse==1
   if distfile==0
      distancedata=zeros(1,length(distancedata));
   end   
   [g]=writefile(t,filteredscanmatrix, scanmatrix, nrdatafiles, datafilename, distancedata,EbNeff,...
      EbNeff_scan,Eb_scan,Neff_scan,relpower,freeref,difpow,...
      VGA,txatt,rxatt,rms,rms2delay,writeWAVE,datadirectory,direct,disttype,numpaths,peakpowerratio,...
      totpower,peakpower,meanexcessdelay,excessdelay,RAKEdB,PEAKSused,Numpeaks,PNratio,SpeakV,SrmsV,...
      CIRpeakV,CIRrmsV,filenum,cleanstop,writeCIR,CIRout,P300stuffon,los,stud,pol,genloc,walls,datavalid,...
      relerror,angerror,tcalclos,CIRLOS,Eratio,meas_sys);
elseif writeoutput==1 & chanimpulse==0
   disp(' ')
	disp(' ')
   disp('CIR calculation not performed; output file will not be written ');
end
   
% %Write Output File used by STDANPLOT *********************************************************
% cd(datadirectory)
% if chanimpulse==1 & setrange==0 & distfile==1
%    save outputfile hRX hTX distancedata tpeakval relpower freeref difpow rms rms2delay numpaths chanimpulse cleanstop pointer disttype offdB endthreshhold peakpowerratio totpower peakpower meanexcessdelay excessdelay RAKEdB PEAKSused Numpeaks PNratio    
% end
% cd(direct)

%Print all figures  ***************************************************************************
if printallfigure==1
	for n=1:1:gcf
   	figure(n)
   	print
	end
end


%Show Elapsed Time *****************************************************************************
elapsedtime=round((cputime-timenow)/30)/2;
ple=[('Elapsed time: ') num2str(elapsedtime) (' minutes')];
disp(' ')
disp(' ')
disp(ple)
disp(' ');
disp(' ');


%Displays for AoA Analysis **********************************************************************
if AoAon==1
   chooseLED
   if chooseLED==2
      meantimes2
   elseif chooseLED==3   
      threshdiv3
   end   
   [Eb_scan' PEAK1' PEAK2' Neff_scan' (Eb_scan-Neff_scan)' (PEAK1-Neff_scan)' (PEAK2-Neff_scan)' (thetaAoA-thetaREAL)'];
   [Eb_scan' Neff_scan' (Eb_scan-Neff_scan)' (thetaAoA-thetaREAL)'];
   [NLOS' (DoA-DoAtruth)'];
   
   cd(datadirectory)
   save aoaoutputfile Eb_scan PEAK1 PEAK2 Neff_scan thetaAoA thetaREAL NLOS DoA DoAtruth
	cd(direct)
end   
