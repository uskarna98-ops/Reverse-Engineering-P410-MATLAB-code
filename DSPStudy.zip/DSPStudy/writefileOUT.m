function [g]=writefileOUT(distancedata,datafilename,datadirectory,direct,t,inputt,nrdatafiles,RAKEdB,...
   PEAKSused,excessdelay,meanexcessdelay,rms2delay,totpower,peakpower,peakV,rmsV,filenum,...
   cleanstop,ftype,tle,P300stuffon,los,stud,pol,genloc,walls,datavalid,relerror,angerror,...
   tcalclos,CIRLOS,Eratio,disttype)

cd(datadirectory)
if cleanstop<1
   FID3=fopen([datafilename '_' ftype '_alpha=' num2str((cleanstop)) '.out'],'w');
elseif cleanstop>1
   FID3=fopen([datafilename '_' ftype '_thresh=' num2str((cleanstop)) '.out'],'w');
end   
   
   	%Header *************************************************
      fprintf(FID3,'\n');
      fprintf(FID3,tle);
      fprintf(FID3,'\n');
      fprintf(FID3,'\n');
      
      if disttype==1
         fprintf(FID3,'?d(ft) ');
      elseif disttype==2   
         fprintf(FID3,'?d(m)  ');
      end   
      for bb=1:1:nrdatafiles
         fprintf(FID3,' %6.2f   ',distancedata(bb));
      end
      fprintf(FID3,'\n');
      
   if P300stuffon==1
      
      fprintf(FID3,'?los   ');
      for bb=1:1:nrdatafiles
         fprintf(FID3,' %6s   ',los(bb));
      end
      fprintf(FID3,'\n');
      
      fprintf(FID3,'?#walls');
      for bb=1:1:nrdatafiles
         fprintf(FID3,' %6s   ',walls(bb));
      end
      fprintf(FID3,'\n');
            
      fprintf(FID3,'?stud  ');
      for bb=1:1:nrdatafiles
         fprintf(FID3,' %6s   ',stud(bb));
      end
      fprintf(FID3,'\n');
      
      fprintf(FID3,'?pol   ');
      for bb=1:1:nrdatafiles
         fprintf(FID3,' %6s   ',pol(bb));
      end
      fprintf(FID3,'\n');
      
      fprintf(FID3,'?genloc');
      for bb=1:1:nrdatafiles
         fprintf(FID3,' %6s   ',genloc(bb));
      end
      fprintf(FID3,'\n');
      
      fprintf(FID3,'?datval');
      for bb=1:1:nrdatafiles
         fprintf(FID3,' %6s   ',datavalid(bb));
      end
      fprintf(FID3,'\n');
           
      
   end   
   
   	fprintf(FID3,'//AMPLITUDE STUFF:\n');
      fprintf(FID3,'?Pk_dB ');
      for bb=1:1:nrdatafiles
         fprintf(FID3,' %6.1f   ',10*log10(peakpower(bb)));
      end
      fprintf(FID3,'\n');
      
      fprintf(FID3,'?Tot_dB');
      for bb=1:1:nrdatafiles
         fprintf(FID3,' %6.1f   ',10*log10(totpower(bb)));
      end
      fprintf(FID3,'\n');
      
      pleP=['?' ftype(1) 'PeakV'];
      fprintf(FID3,pleP);
      for bb=1:1:nrdatafiles
         fprintf(FID3,' %6.4f   ',peakV(bb));
      end
      fprintf(FID3,'\n');
      
      pleR=['?' ftype(1) 'RMSV '];
      fprintf(FID3,pleR);
      for bb=1:1:nrdatafiles
         fprintf(FID3,' %6.4f   ',rmsV(bb));
      end
      fprintf(FID3,'\n');
      
      fprintf(FID3,'//DELAY SPREADS:\n');
      fprintf(FID3,'?RMS_ns');
      for bb=1:1:nrdatafiles
         fprintf(FID3,' %6.1f   ',rms2delay(bb));
      end
      fprintf(FID3,'\n');
      
      fprintf(FID3,'?MN_ns ');
      for bb=1:1:nrdatafiles
         fprintf(FID3,' %6.1f   ',meanexcessdelay(bb));
      end
      fprintf(FID3,'\n');
      
      fprintf(FID3,'?EX_ns ');
      for bb=1:1:nrdatafiles
         fprintf(FID3,' %6.1f   ',excessdelay(bb));
      end
      fprintf(FID3,'\n');
      
      fprintf(FID3,'//RAKE POTENTIAL:\n');
      fprintf(FID3,'?RAK_dB');
      for bb=1:1:nrdatafiles
         fprintf(FID3,' %6.2f   ',RAKEdB(bb));
      end
      fprintf(FID3,'\n');
      
      fprintf(FID3,'?RAKEPK');
      for bb=1:1:nrdatafiles
         fprintf(FID3,' %6.0f   ',PEAKSused(bb));
      end
      fprintf(FID3,'\n');
      
      fprintf(FID3,'//CLEAN PERFORMANCE:\n');
      fprintf(FID3,'?RelErr');
      for bb=1:1:nrdatafiles
         fprintf(FID3,' %6.3f   ',relerror(bb));
      end
      fprintf(FID3,'\n');
      
      fprintf(FID3,'?AngErr');
      for bb=1:1:nrdatafiles
         fprintf(FID3,' %6.3f   ',angerror(bb));
      end
      fprintf(FID3,'\n');
      
      fprintf(FID3,'?Eratio');
      for bb=1:1:nrdatafiles
         fprintf(FID3,' %6.3f   ',Eratio(bb));
      end
      fprintf(FID3,'\n');
           
      fprintf(FID3,'?DSO_ns');
      for bb=1:1:nrdatafiles
         fprintf(FID3,' %6.2f   ',tcalclos(bb));
      end
      fprintf(FID3,'\n');
      
      fprintf(FID3,'?CIR_ns');
      for bb=1:1:nrdatafiles
         fprintf(FID3,' %6.2f   ',CIRLOS(bb));
      end
      fprintf(FID3,'\n');
      
      fprintf(FID3,'?DIF_ns');
      for bb=1:1:nrdatafiles
         fprintf(FID3,' %6.2f   ',(tcalclos(bb)-CIRLOS(bb)));
      end
      fprintf(FID3,'\n');
            
      fprintf(FID3,'\n');
      fprintf(FID3,'?t      ');
      for bb=1:1:nrdatafiles
         if filenum(bb)<10
            header=['?' ftype '_#%1.0f   '];    
            fprintf(FID3,header,filenum(bb));
         elseif filenum(bb)<100
            header=['?' ftype '_#%1.0f  '];
            fprintf(FID3,header,filenum(bb));
         else
            header=['?' ftype '_#%1.0f '];
            fprintf(FID3,header,filenum(bb));
         end 
      end
      fprintf(FID3,'\n');
      %End Header
            
      ple=['%.2f'];
      for bb=1:1:nrdatafiles
      	ple=[ple ' %9.4f'];
      end   
      ple=[ple '\n'];
      
      %Format Data for output such that peak is 1 
      peak=max(max(inputt));
      inputt=inputt/peak;
      
      for m=1:length(t)
      	tempmatrix=[t(m) ; inputt(:,m)];
         fprintf(FID3,ple,tempmatrix);
      	%y=filteredscanmatrix(:,bb)';
      	%fprintf(FID3,'%.2f\n',y);
   	end %m
		g=1;
		fclose(FID3);