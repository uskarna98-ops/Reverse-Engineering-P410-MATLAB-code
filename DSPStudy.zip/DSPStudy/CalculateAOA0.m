
function [AoA,correlation,Start,End,Template] = CalculateAOA0(numPts, iDataIN, dpath)

%used in filter
x1 =0;
x2 =0;
x3 =0;
y1 =0;
y2 =0;
y3 =0;

% Other Constants
template_size = 50;
cable_delay = 599;
antenna_distance = 50;
inMean=0;

% lets filter the data first
for i=1:numPts
    inMean = inMean + iDataIN(i);
end
inMean = inMean/numPts;

%Correlate with IIR2 Filter
for i=0:numPts-1
   inputt=[iDataIN(numPts-i)-inMean];
   [outputt,x1,x2,x3,y1,y2,y3]=FilterIIR2(inputt,x1,x2,x3,y1,y2,y3);%FilterIIR2 does not square output
   iDataInLocal(numPts-i)=outputt;
end


% now lets snip out the leading edge for use in correlation
for k=1:template_size 
   Template(k) = iDataInLocal(dpath+k-1);
end

Start = cable_delay - antenna_distance + dpath;
End   = cable_delay + antenna_distance + dpath;

% now lets correlate this template through the data
for i=Start:End-1
    correlation(i) = 0;
    for j=1:template_size
       correlation(i) = correlation(i) + Template(j) * iDataInLocal(i+j-1);
    end
end

% now lets find the peak
%peak = cable_delay + dpath;
peak = cable_delay;

for m=Start:End-1
     if correlation(m) > correlation(peak)
      peak = m;
   end  
   AoA = peak;
end