%// returns the sample number of the direct path or -9999999 if can't find it
%// Envelope Difference First Peak with Dynamic Scaling
%int tdRADIO::LeadingEdgeDetection0(int numPts, long *iDataIn)

function [output]=LED2(numPts,iDataIN,step,Ts,meantimes,k,tstart,tstop)
TS=Ts/1e-9;
inMean=0;
peak=1;
%x=[0,0,0];
%y=[0,0,0];
x1=0;
x2=0;
x3=0;
y1=0;
y2=0;
y3=0;

%Calculate Waveform Mean Voltage
for i=1:numPts
   inMean=inMean+iDataIN(i);
end
inMean=inMean/numPts;

%Correlate with IIR Filter
for i=1:numPts
   inputt=[iDataIN(i)-inMean];
   [outputt,x1,x2,x3,y1,y2,y3]=FilterIIR(inputt,x1,x2,x3,y1,y2,y3);
   iDataINLocal(i)=outputt;
end   

%build envelope of correlated signal
	envelope=[];
	envelope(1) = 0;
	%compute first one
	for j=1:step
   	envelope(1)=envelope(1)+iDataINLocal(j);  
	end
   
   for i=2:numPts-step
   	envelope(i)=envelope(i-1)-iDataINLocal(i-1) + iDataINLocal(i+step-1);
   end
   
%find the average of the envelope 
envelopeMEAN=0;   
for i=1:numPts-step
	envelopeMEAN=envelopeMEAN+envelope(i);
end   
envelopeMEAN=envelopeMEAN/(numPts-step);
%Multiply mean by meantimes
%envelopeMEAN<<=1;
envelopeMEAN=envelopeMEAN*meantimes;

%find the first place we break this mean value
	for i=1:numPts-step
		if envelope(i)>=envelopeMEAN
         peak = i-1;
         peak*TS;
         break;
      end
   end   
   
%logic in LE2 algorithm   
   if peak<50 
      output=5;
   elseif peak> (numPts-100)
      output=5;
   else
      output=peak;
   end   
   
   
if k==1
	figure(gcf+1)
   %subplot(211), 
   plot((0:numPts-1)*TS,iDataIN./max(abs(iDataIN)),'k.-')
	hold on
   %subplot(211), 
   plot((0:numPts-1)*TS,iDataINLocal./max(abs(iDataINLocal)),'r.-','LineWidth',2)
	%subplot(211), plot((0:numPts-1)*TS,iDataINLocal2./max(abs(iDataINLocal2)),'m.-')
   %axis([49.6 51 -.8 1.2])
   grid on
   plot((0:numPts-step-1)*TS,envelope/max(abs(envelope)),'g-*','LineWidth',2)
   plot([output output]*TS, [-1 1],'LineWidth',2,'color','b')
   plot([tstart tstop], [envelopeMEAN envelopeMEAN]./max(abs(envelope)),'LineWidth',2,'color','b')
   axis([tstart tstop -.8 1.2])
   %axis([11 14 -.8 1.2])
   xlabel('time (ns)')
	ylabel('normalized amplitude')
	title('LED2')
   %legend('Impulse Excitation','Manual IIR','MATLAB IIR')
   legend('iDataIN','iDataINLocal','Envelope','LE2')
   hold off
end   


    