
function [aoa,correlation,Start,End,Template,cable_delayns,firstpeak,firstpeakmax,secondpeak,secondpeakmax] = AOA(numPts, iDataIN, ...
   dpath, template_sizens, cable_delayns, A,k,nsperft,Ts,firsttemp,Template,tstart,tstop)

template_size = round( template_sizens/(Ts/1e-9) ); %samples
cable_delay = round( cable_delayns/(Ts/1e-9) );     %samples
antenna_distance = round( (A*nsperft)/(Ts/1e-9) );  %samples
TS=Ts/1e-9;

%used in filter
x1 =0;
x2 =0;
x3 =0;
y1 =0;
y2 =0;
y3 =0;

%Find waveform peak relative to LE   
wavepeak=0;
threshstop=dpath+template_size;
for i=dpath:threshstop
   if iDataIN(i)>wavepeak
      wavepeak=iDataIN(i);
      firstpeakmax=wavepeak;
      firstpeak=i-1; %i-1 because i starts at 1 but time starts at 0
   end
end 

inMean=0;
% lets filter the data first
for i=1:numPts
    inMean = inMean + iDataIN(i);
end
inMean = inMean/numPts;

%Correlate with IIR2 Filter
for i=0:numPts-1
   inputt=[iDataIN(numPts-i)-inMean];
   [outputt,x1,x2,x3,y1,y2,y3]=FilterIIR3(inputt,x1,x2,x3,y1,y2,y3);%FilterIIR2 does not square output
   iDataINLocal(numPts-i)=outputt;
end


% now lets snip out the leading edge for use in correlation
%Always use template from 1-meter scan
if firsttemp==1
   if k==1
   	for kk=1:template_size 
   		Template(kk) = iDataINLocal(dpath+kk-1);
		end
   end  
elseif firsttemp==0
   for kk=1:template_size 
   	Template(kk) = iDataINLocal(dpath+kk-1);
   end   
end   
   
Start = dpath + cable_delay - antenna_distance;
End   = dpath + cable_delay + antenna_distance;

% now lets correlate this template through the data
wavepeak=0;
for i=Start:End-1
    correlation(i) = 0;
    for j=1:template_size
       correlation(i) = correlation(i) + Template(j) * iDataINLocal(i+j-1);
    end
end


% now lets find the peak
%peak = cable_delay + dpath;
peak = cable_delay;

for m=Start:End-1
     if correlation(m) > correlation(peak)
      peak = m;
   end  
   aoa = peak;
end

%Find Cable delay from 1-meter 0 degree measurement
if k==1
   cable_delayns
   cable_delayns=abs(aoa-dpath)*(Ts/1e-9)
end

%Find waveform peak relative to LE_2   
wavepeak=0;
threshstop=peak+template_size;
for i=peak:threshstop
   if iDataIN(i)>wavepeak
      wavepeak=iDataIN(i);
      secondpeakmax=wavepeak;
      secondpeak=i-1;	%i-1 because i starts at 1 but time starts at 0
   end
end 


if k==1
	figure(gcf+1)
   plot((0:numPts-1)*TS,iDataIN./max(abs(iDataIN)),'k.-')
	hold on
   plot((0:numPts-1)*TS,iDataINLocal./max(abs(iDataINLocal)),'r.-','LineWidth',2)
   grid on
   plot((Start:End-1)*TS,correlation(Start:End-1)/max(abs(correlation(Start:End-1))),'m','LineWidth',2)
	plot([aoa aoa]*TS, [-1 1],'LineWidth',2,'color','b')
   plot((dpath+(1:template_size)-2)*TS,Template./max(abs(Template)),'c','LineWidth',2)
   plot((aoa+(1:template_size)-2)*TS,Template./max(abs(Template)),'c','LineWidth',2)
   axis([tstart tstop -.8 1.2])
   %axis([11 14 -.8 1.2])
   xlabel('time (ns)')
	ylabel('normalized amplitude')
	title('AoA')
   %%%legend('Impulse Excitation','Manual IIR','MATLAB IIR')
   %legend('iDataIN','iDataINLocal','Correlation','LE_2','Temp')
   hold off
end  

   