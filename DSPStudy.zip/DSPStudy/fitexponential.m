function kappaout=fitexponential(x)
% fitexponential.m
% 
% operation:
%   fits data to asymptotically increasing exponential of form
%    f(x) = 1-exp(-x/kappa)
% 
% usage:
%   kappaout=fitexponential(x)
%     input:   x is input data vector
%     output:  kappaout is best LMS fit of x to equation f(x)=1-exp(-x/kappa)

% last edited by:
%   David J. Hall
%   Time Domain Systems, Inc.
%   25 July 2000
%   00:06

lowesterr=999999;
kappaout=1;
xx=1:length(x);
error=zeros(2000,1);
k=0;
for kappa=0.01: 0.01: 20
   k=k+1;
   testfit=1-exp(-xx./kappa);
   error(k)=sum((x-testfit).^2);
   if error(k)<lowesterr
      lowesterr=error(k);
      kappaout=kappa;
   end %if      
end %kappa
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


