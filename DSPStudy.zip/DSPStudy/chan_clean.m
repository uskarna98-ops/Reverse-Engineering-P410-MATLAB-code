function [CIRout,CIRpeakV,CIRrmsV,Numpeaks,PNratio,RAKEdB,PEAKSused,excessdelay,...
      peakpower,meanexcessdelay,rms2delay,numpaths,peakpowerratio,totpower,...
      relerror,angerror,CIRLOS,Eratio,P,Pnew,DoAclean]=chan_clean(tempwidth,rakes,Nit,...
      distancedata,writeCIR,datafilename,datadirectory,direct,filteredscanmatrix,...
      nrdatafiles,Ts,templatestart,scandisp,startfig,tstart,tstop,shifttime,...
      envelopeshow,chandisp,scanfig,normscans,ver,filenum,zoomon,P300stuffon,...
      tcalclos,cleanstop,AoAon,startLE,stopLE)
%load chan_impulse scanmatrix nrdatafiles


g=150;
g1=g;
corr=0;

numframes=ceil(nrdatafiles/3);
counter=0;
%if chandisp==1 
%   figure(g)
%end   
for k=1:numframes
   if scandisp==0 & chandisp==1 
      figure(g+1);
   elseif scandisp==2 & chandisp==1
  		figure(g+1);      
   elseif scandisp==0 & chandisp==0
      if k==1
         figure(scanfig)
      else
         figure(gcf+1);
      end   
   end  
   
   
   for l=1:3
      fs=1/Ts;
      if scandisp==0 
         subplot(3,1,l)
      elseif scandisp==2 & chandisp==1
         subplot(3,1,l)
      end   
      counter=counter+1; 
      if (counter <= nrdatafiles) 
         
      if nrdatafiles>30   
      	if rem(counter,10)==0 | counter==1  
        		CLEANcount=counter;
        		CLEANcount
      	end
      else
      	CLEANcount=filenum(counter);
        	CLEANcount  
      end
   
      %Template Waveform ***************************************
      x=filteredscanmatrix(:,1);
      %DC Offset removal in clean  %x=x-mean(x);
      x1=x;
      
           
		%Multipath Waveform **************************************  
      t=(0:1:length(x)-1)*Ts/1e-9;
      tt=t;
      y=filteredscanmatrix(:,counter);
      %DC Offset removal in clean %y=y-mean(y);
      
      %Reduce Noise from Template Waveform
      
      
      
      reducenoise=1;
      if reducenoise==1
      	%Cut out beginning noise  
       	x(1:templatestart)=0;
         %Set template as 2 ns after templatestart
         cutoff=templatestart+round((tempwidth)/Ts/1e9);
         x(cutoff:length(x))=0;   
      end
      
      %Calculate adjustment to get CIR to look synced with scan
      %t_offset=min( tstop, ceil( t(templatestart)/10 )*10 - t(templatestart));
      %if t_offset>=tempwidth/2
      %   t_offset=tempwidth/2;
      %end
      t_offset=0;
      
	%Get waveforms of the same length
	if length(x)>=length(y)
   	%x=x(1:length(y));
   	y=[y;zeros(length(x)-length(y),1)];
	else
   	y=y(1:length(x));
	end   
   
   %Display Template Waveform
   if counter==1 & chandisp==1 
      figure(gcf+1)
      plot(t,x1/max(abs(x1)),'b:')
      hold on;
      plot(t,x/max(abs(x)),'r')
      axis([shifttime-5 shifttime+10 -1 1])
      title('Template Waveform (d=1 m)')
      xlabel('time (ns)')
      ylabel('normalized amplitude')
      hold off;
      grid on;
      templatefig=gcf;
   end   
   
   
%3. CLEAN procedure
	ttime=cputime;
	%Nit is the number of iterations of the CLEAN procedure
   W=x(templatestart:cutoff);
   W(1)=0;
   W(length(W))=0;
   P=y;
   
   t1ref=min( round(tcalclos(counter)/(Ts*1e9)), length(t));
   tcalclosplot=tcalclos(counter);
   [h,numpeaks,posneg_ratio,threshdBpre,chan_threshdB,energyratio]=clean_stdan(P,W,Nit,ver,t1ref,cleanstop,filenum);
   
   if counter==1  
      href=h;
      normref=href;
   end  
   
%Calculate Statistics on Channel Impulse Response**************************************
[multipaths,timezero1,breaktime,CpeakV,CrmsV,rakedB,peaksused,rmsdelay,meandelay,excess_delay,...
      peakratio,totalpower]=chan_stats(rakes,t,h,Ts);

	%Reconstruct Waveform by convolving template with CIR
	Pnew=conv(W,h);
   
   Eratio(counter)=energyratio;
   numpaths(counter)=multipaths;
   Numpeaks(counter)=multipaths;
   rms2delay(counter)=rmsdelay;
   CIRLOS(counter)=timezero1;
   %Create threshold to plot; Adjust for threshdBpre
   thresh=10^(-chan_threshdB/20) * max(abs(h));
   thresh=[ones(1,length(h))*thresh];
   thresh(1:t1ref)=thresh(1:t1ref) .* 10^(-threshdBpre/20)/10^(-chan_threshdB/20);
   thresh=thresh / max(abs(normref));
   
   
   peakpower(counter)=max(abs(h)).^2 ./ max(abs(href)).^2; %Normalize to first at end of this program
   peakpowerratio(counter)=peakratio;
   meanexcessdelay(counter)=meandelay;
   excessdelay(counter)=excess_delay;
   PNratio(counter)=posneg_ratio;
   RAKEdB(counter)=rakedB;
   PEAKSused(counter)=peaksused;
   CIRpeakV(counter)=CpeakV;
   CIRrmsV(counter)=CrmsV;
   
   if counter==1
      powerref=totalpower;
   end
   %Normalize to 1st CIR
   totpower(counter)=totalpower/powerref;
   
   if AoAon==1
      habs=abs(h);
      for iii=1:length(h)
         if habs(iii)>0
            ant1=(iii)*Ts*1e9;
            break
         else
             ant1=0;
         end
      end
      this=round(ant1/(Ts*1e9)+startLE);      
      for iii=round(ant1/(Ts*1e9)+startLE):1:round(ant1/(Ts*1e9)+stopLE)
         if habs(iii)>habs(this)
         	ant2=(iii)*Ts*1e9;
            this=iii;
         else
             ant2=0;
         end
      end
      DoAclean(counter)=ant2-ant1;
   else
       DoAclean(counter)=0;
   end %if AoAon
   %Display CIRs
   		if zoomon==1
   			hmax=0;
   			for mm=1:1:length(h)
            	if abs(h(mm))>0
               	if abs(h(mm))>hmax
                  	hmax=abs(h(mm));
               	end
               	%Adjust threshold by 10 dB for PAD sidelobe at breakpoint (from chan_stats) 
               	if t(mm)<breaktime
                  	tstopnew=ceil((tt(mm))/10)*10;
               	elseif t(mm)>=breaktime
                  	if 20*log10(abs(h(mm))+1e-12) > 20*log10(abs(hmax)+1e-12)-(chan_threshdB-10)
                     	tstopnew=ceil((tt(mm))/10)*10;
                  	end
               	end   
            	end
            end
         else
            tstopnew=tstop;
      	end%zoomon
      
         if scandisp==2 & chandisp==1 
           	%plot(tt,(abs(c)./max(abs(cref))),'b')
            hold on;
            plot([tcalclosplot tcalclosplot]+tempwidth/2,[-1.5 1.5],'m--')
            plot([timezero1 timezero1]+tempwidth/2,[-1.5 1.5],'g')
            legend('Calc','RMS to')
            plot(tt+tempwidth/2, h ./max(abs(href)),'r.-');
            %plot(thpeaks+tempwidth/2,hpeaks/max(abs(normref)),'k*');
            plot(tt+tempwidth/2,thresh,'b--');
            plot(tt+tempwidth/2,-thresh,'b--');
            axis([tstart tstopnew -max((abs(h)./max(abs(href))))-.1*max((abs(h)./max(abs(href)))) max((abs(h)./max(abs(href))))+.1*max((abs(h)./max(abs(href))))])
            hold off;
         	title(strcat('Channel Impulse Response (Scan # ',num2str(filenum(counter)), ', Thresh=', num2str(round(chan_threshdB*10)/10), 'dB)'));			
            ylabel('normalized h(t)')
            xlabel('Time (nS)');
            %legend('Correlation','De-convolution')
         
         elseif scandisp==0 & chandisp==1 
           	%plot(tt,(abs(c)./max(abs(cref))),'b')
				hold on;
            plot([tcalclosplot tcalclosplot]+tempwidth/2,[-1.5 1.5],'m--')
            plot([timezero1 timezero1]+tempwidth/2,[-1.5 1.5],'g')
            legend('Calc','RMS to')
            plot(tt+tempwidth/2, h ./max(abs(href)),'r.-');
            %plot(thpeaks+tempwidth/2,hpeaks/max(abs(normref)),'k*');
            plot(tt+tempwidth/2,thresh,'b--');
            plot(tt+tempwidth/2,-thresh,'b--');
            axis([tstart tstopnew -max((abs(h)./max(abs(href))))-.1*max((abs(h)./max(abs(href)))) max((abs(h)./max(abs(href))))+.1*max((abs(h)./max(abs(href))))])
            hold off;
            title(strcat('Channel Impulse Response (Scan # ',num2str(filenum(counter)), ', Thresh=', num2str(round(chan_threshdB*10)/10), 'dB)'));
            ylabel('normalized h(t)')
            xlabel('Time (nS)');
            %legend('Correlation','De-convolution')
            
         elseif scandisp==0 & chandisp==0 
           	   %Reconstruct Waveform by convolving template with CIR
               Pnew=conv(W,h);
               if normscans==1
                  Pnew=Pnew/max(abs(Pnew));
               end   
               hold on;
               plot(t,Pnew(1:length(P)),'r');
               axis([tstart tstopnew -max((abs(P)))-.1*max((abs(P))) max((abs(P)))+.1*max((abs(P)))]); 
               if normscans==1
                  axis([tstart tstopnew -1 1]); 
               end
               hold off;
               
         elseif scandisp==1
            figure(startfig+counter-1)
            if envelopeshow==1
         		subplot(313)
      		else   
              
               if normscans==1
                  Pnew=Pnew/max(abs(Pnew));
               end
               hold on;
               subplot(211),plot(t,Pnew(1:length(P)),'r');
               axis([tstart tstopnew -max((abs(P)))-.1*max((abs(P))) max((abs(P)))+.1*max((abs(P)))]); 
               if normscans==1
                  axis([tstart tstopnew -1 1]); 
               end
               hold off;
               grid on
               pleRMS=['CIR RMS Delay=', num2str(round(rmsdelay*10)/10)] ;
               if P300stuffon==1
               	text(tstart+10,max(Pnew)*.75,pleRMS)
               end   
               %legend('Org','Recon')
               subplot(212)
               
      		end 
            %plot(tt,(abs(c)./max(abs(cref))),'b')
            hold on;
            if P300stuffon==1
               plot([tcalclosplot tcalclosplot]+tempwidth/2,[-1.5 1.5],'m--')
            	plot([timezero1 timezero1]+tempwidth/2,[-1.5 1.5],'g')
               legend('Calc','RMS to')
            elseif AoAon==1
               plot([ant1 ant1]+tempwidth/2,[-1.5 1.5],'b')
            	plot([ant2 ant2]+tempwidth/2,[-1.5 1.5],'b')
            end               
            if normscans==1
               plot(tt+tempwidth/2,h./max(abs(h)),'r.-');
               %plot(thpeaks+tempwidth/2,hpeaks/max(abs(normref)),'k*');
            	plot(tt+tempwidth/2,thresh./max(abs(h)),'b--');
            	plot(tt+tempwidth/2,-thresh./max(abs(h)),'b--');	
            	xlabel('Time (nS)');
            	axis([tstart tstopnew -1 1])
            else
               scoot=tempwidth/2;
               plot(tt+scoot,h./max(abs(href)),'r.-');
               %plot(thpeaks+tempwidth/2,hpeaks/max(abs(normref)),'k*');
            	plot(tt+scoot,thresh,'b--');
               plot(tt+scoot,-thresh,'b--');
               xlabel('Time (nS)');
           		axis([tstart tstopnew -max((abs(h)./max(abs(href))))-.1*max((abs(h)./max(abs(href)))) max((abs(h)./max(abs(href))))+.1*max((abs(h)./max(abs(href))))])
           end   
            
            hold off;
            title(strcat('Channel Impulse Response (Scan # ',num2str(filenum(counter)), ', Thresh=', num2str(round(chan_threshdB*10)/10), 'dB)'));
            ylabel('normalized h(t)')
            %legend('Correlation','De-convolution')
            xlabel('Time (nS)');
            if P300stuffon==1
            	text(tstart+10,max((abs(h)./max(abs(href))))*.75,pleRMS)
            end   
         end%if
         
       CIRout(counter,:)=(h./max(abs(h)))'; 
       
       
       %Calculate Accuracy of CLEAN Algorithm
       
       		%s=P;r=Pnew(1:length(P));
            cc=0; 
            for bb=1:length(P)
               if Pnew(bb)>0
                  cc=cc+1;
                  s(cc)=P(bb)./max(abs(P));
                  r(cc)=Pnew(bb)./max(abs(Pnew));
               end
            end
            %[s' r']
            %figure(434)
            %plot(s)
            %hold on;
            %plot(r,'r')
            %hold off;
            
            norms_r=sqrt( sum((s-r).^2*Ts) );
    			norms=  sqrt( sum(   s.^2*Ts) );
    			normr=  sqrt( sum(   r.^2*Ts) );
    
    			%relerrora(counter)=norms_r/normr
            relerror(counter)=norms_r^2/norms^2;
    			angerror(counter)=sum(s.*r.*Ts) / (norms*normr);
  
    	end; %if (counter <= nrdatafiles)
      end; %l
  
    if scandisp==0 & chandisp==1 
       xlabel('time (ns)')
       g=g+1;
    end
        
 end; %k
 
 figure(templatefig) 
 if P300stuffon==1
    figure(gcf+1)
 	plot(filenum,relerror,'b*')
 	hold on;
 	plot(filenum,angerror,'rd')
 	hold off;
 	grid on;
 	legend('Relerror','Angerror')
 	xlabel('Scan #')
 	ylabel('Error')
 	title('Relative & Angular Error of Recon. vs Orig. Waveforms')
 	axis([min(filenum) max(filenum) 0 ceil(max(max(relerror),max(angerror))*10)/10])
    %templatefig=templatefig+1;
 end

 


