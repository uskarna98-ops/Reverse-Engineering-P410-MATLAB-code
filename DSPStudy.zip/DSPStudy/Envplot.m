clear
close all

NFS=2;
NHO=2.75;
NOF=2.8;
NRE=2.65;
NWA=2.6;
NHS=3.4;
miny=-51;

%Plot Reference Lines
		distdat1=3.3:1:80;
      Freespace=-NFS*10*log10(distdat1/min(distdat1));
      Home=-NHO*10*log10(distdat1/min(distdat1));
      Off=-NOF*10*log10(distdat1/min(distdat1));
      Ret=-NRE*10*log10(distdat1/min(distdat1));
      Ware=-NWA*10*log10(distdat1/min(distdat1));
      Hosp=-NHS*10*log10(distdat1/min(distdat1));
      semilogx(distdat1,Freespace,'linewidth',2,'color','r') 
      hold on;
      semilogx(distdat1,Home,'linewidth',2,'color','b')
      semilogx(distdat1,Off,'linewidth',2,'color','g')
      semilogx(distdat1,Ret,'linewidth',2,'color','m')
      semilogx(distdat1,Ware,'linewidth',2,'color','k')
      semilogx(distdat1,Hosp,'linewidth',2,'color',[1 .8 .1])
      legend('Free Space (N=2)','Home (N=2.75)','Office (N=2.8)','Retail (N=2.65)','Warehouse (N=2.6)','Hospital (N=3.4)')
      axis([3 100 miny 3]); %axis([0 3.0 -100 -20]);
      vecor=[];
      for gt=miny:3:3
         vecor=[vecor gt];
      end 
      set(gca,'yTick',vecor)
      grid on;
		xlabel('Distance (feet)');
		ylabel('Mean Pathloss (dB)');
		%ple=[('Calculated from ') num2str(length(distancedata)) ' scans (calculated assuming ',num2str(corr1), ' peak)  '  date];
   	%title(ple);
      hold off;
      
% RMS delay spread --------------------------------------------------------------------------
		figure(gcf+1) 
      plot([3.3 40 80],[3.5 5.61 7.88] ,'linewidth',2,'color','r');
      hold on;
      plot([3.3 40 80],[3 10.91 19.53] ,'linewidth',2,'color','b');
      plot([3.3 40 80],[9.2 33.1 59.07] ,'linewidth',2,'color','g');
		plot([3.3 40 80],[9.3 22.9 37.67] ,'linewidth',2,'color','m');
      plot([3.3 40 80],[9.3 18.1 27.65] ,'linewidth',2,'color','k');
      %plot([3.3 40 80],[18.15 25.9 34.39] ,'linewidth',2,'color','c');
      %Modified for 9 at 1 meter
      plot([3.3 40 80],[9 25.9 44.1] ,'linewidth',2,'color',[1 .8 .1]);
      grid on;
      legend('Free Space','Home','Office','Retail','Warehouse','Hospital',0)
      legend('Free Space (0.5ns/10ft)','Home (2.2ns/10ft)','Office (6.5ns/10ft)','Retail (3.7ns/10ft)','Warehouse (2.4ns/10ft)','Hospital (4.6ns/10ft)',0)
      xlabel('Distance (feet)');
      ylabel('Mean RMS Delay (ns)');
      axis([3.3 100 0 70])

     