function [snrinmatrix, signalmatrix, noisematrix]=findsnrin(scanmatrix, stmatrix, timeperpt)

snrinmatrix=zeros(1,length(stmatrix));
signalmatrix=zeros(1,length(stmatrix));
noisematrix=zeros(1,length(stmatrix));

for k=1:length(stmatrix)
   snrinmatrix(k)=10*log10( max(abs(scanmatrix(:,k)))^2 / (var( scanmatrix(1: round(stmatrix(k)/timeperpt),k)))  );
   
   signalmatrix(k) = 10*log10( max(abs(scanmatrix(:,k)))^2);
   noisematrix(k) = 10*log10(2*var( scanmatrix(1: round(stmatrix(k)/timeperpt),k)));
   %round(stmatrix(k)/timeperpt)
   %k
   %pause;
end %k
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%