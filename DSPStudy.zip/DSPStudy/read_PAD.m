function [scanmatrix, lockmatrix, distancedata, BERmatrix, SNRmatrix, timeperpt, nrdatapts,distfile,nrdatafiles,gain,txatt,rxatt,deltatflag,deltat,disttype]=...
  read_PAD(datadirectory, datafilename,attenoff,maxnumberoffiles,hTX,hRX,antheightadj,offdB)

% 
% operation:
%    reads in data files in a series, and passes out data on both scan and data/lock channels
%
% usage:
%    function [scanmatrix, lockmatrix, distancedata, BERmatrix, SNRmatrix, timeperpt, nrdatapts]=...
%      padsread(datadirectory, datafilename, nrdatafiles)
%
%    inputs:
%       datadirectory         directory that data is in
%       datafilename          filename used for files in that directory. 
%                e.g. if files are c:\data1.dat - data10.dat, 
%                this would be data
%       nrdatafiles           number of data files to read in the group.
%                e.g. in the above case, nrdatafiles=10
%
%    outputs:
%       scanmatrix           [nrdatapoints x nrdatafiles] dimensioned matrix containing the scan channel data
%       lockmatrix           [nrdatapoints x nrdatafiles] dimensioned matrix containing the lock channel data
%       distancedata         nrdatafiles dimensioned matrix containing the distances 
%                                 between the transmitter and receiver in feet.
%       BERmatrix            nrdatafiles dimensioned matrix containing the BER of each scan
%       SNRmatrix            [nrdatafiles x 3]      dimensioned matrix containing parameters PSNR, NSNR, and CSNR
%                                                         in columns 1, 2, and 3 respectively
%       timeperpt            time per point in nS
%       nrdatapts            number of data points per file
%		  distfile				  =0 if distancefile not present for scans, =1 if distancefile present for scans		
%       
%   dependencies:
%       masterlist.txt       list of parameters common to ALL data files
%       distance.txt         list of distances between receiver and transmitter in files in batch of data
%
%Limit number of scans to 100

%Get idea of start file number, how many, and end file number
flag=0;
started=0;
	for n=1:maxnumberoffiles
      FID = fopen([datadirectory datafilename num2str(n) '.dat']);
      if FID==-1
         FID = fopen([datadirectory datafilename num2str(n) '.txt']);
         %Kick out of loop because end is found
         if FID==-1 & started==2
            break
         end
      else
      	if flag==0
      		nstart=n;
            flag=1;
            started=1;
      	elseif flag==1
            nstop=n;
            started=2;
         end
      	fclose(FID);   
      end   
   end
%Display message if no data files found   
if flag==0
   disp(' ');
	disp(' ');
   disp('>>No scan files found; Check path and/or file name and restart program.');
   disp('>>press <CTRL>-C to end program');
   disp(' ');
   disp(' ');
   pause;
end   


nrdatafiles=nstop-nstart+1;
nrdatanames=9;  % number of variables to be read from each scan file.

BERmatrix = zeros(nrdatafiles,1);
SNRmatrix = zeros(nrdatafiles,3);

datalimit=30000;%16500
scandata = zeros(datalimit,2);
lockmatrix = zeros(datalimit,nrdatafiles);
scanmatrix = zeros(datalimit,nrdatafiles);

errorvector=zeros(nrdatanames);
maxlength=0;
minlength=99999;

for n=1:nstop-nstart+1
   
   filen=nstart+n-1;
   FID = fopen([datadirectory datafilename num2str(filen) '.dat']);
   if FID==-1
      FID = fopen([datadirectory datafilename num2str(filen) '.txt']);
   end 
   %if FID==-1
   %   if n==1
   %      disp(' ');
  % 		disp(' ');
  %       disp('>>No scan files found; Check path and/or file name and restart program.');
  %       disp('>>press <CTRL>-C to end program');
  %       disp(' ');
  %       disp(' ');
  %       pause;
  %    end   
  %    nrdatafiles=n-1;
  %    break
   %end
   if rem(n,10)==0   
      n 
   end
   line=fgets(FID,4);
   
   while(isletter(line(1))) ==1
	   if strcmp(line, 'EXRX') == 1
		   extraline = fgets(FID,6);
         nm = fgetl(FID);
         exrx = str2num(nm);
         errorvector(1)=1;
         
	   elseif strcmp(line,'EXTX') == 1
		   extraline = fgets(FID,6);
		   nm = fgetl(FID);
         extx = str2num(nm);
         errorvector(2)=1;
         
	   elseif strcmp(line,'BER	') == 1 % there is a <TAB> after the R
		   extraline = fgets(FID,8);
		   nm = fgetl (FID);
         BERmatrix (n) = str2num(nm);
         errorvector(3)=1;
         
	   elseif strcmp(line, 'PSNR') == 1
		   extraline = fgets(FID,9);
		   nm = fgetl(FID);
         SNRmatrix(n,1) = str2num(nm);
         errorvector(4)=1;
         
	   elseif strcmp(line, 'NSNR') == 1
		   extraline = fgets(FID, 9);
		   nm = fgetl(FID);
         SNRmatrix(n,2) = str2num(nm);
         errorvector(5)=1;
         
	   elseif strcmp(line,'CSNR') == 1
		   extraline = fgets(FID,9);
		   nm = fgetl(FID);
         SNRmatrix(n,3) = str2num(nm);
         errorvector(6)=1;
         
      elseif strcmp(line,'VGAG') == 1
		   extraline = fgets(FID,7);
		   nm = fgetl(FID);
         VGA = str2num(nm);
         errorvector(7)=1;   
               
	   elseif strcmp(line,'NPTS') == 1
		   extraline = fgets(FID,7);
		   nm = fgetl(FID);
         nrdatapts = str2num(nm);
         errorvector(8)=1;
         
	   elseif strcmp(line,'BINS') == 1
		   extraline = fgets(FID,9);
		   nm = fgetl(FID);
         timeperpt = 0.001*str2num(nm);
         errorvector(9)=1;
         
      else
         extraline = fgetl(FID);
      end; %if
      line=fgets(FID,4);
      
   end; %k
   
   
   for y=1:nrdatanames
      if errorvector(y) == 0
          y;
         error('parameter not found');
      end %if
   end; %y
   
   x = fscanf(FID,'%d %d',[2 inf]);
   x = x';
   [mm,nn] = size(x);
   
   if mm<minlength
      minlength=mm;
   end % if      
   
   % truncate size of scandata to datalimit
   [M N]=size(x);
   l=min(datalimit, M);
   mm=min(datalimit,mm);
   scandata(1:l,:)=x(1:mm,:);
   
   fclose(FID);
   %FOrce COrrection to Zero if want to compare Rax signal levels
   if attenoff==1
   	extx=0;
   	exrx=0;
      VGA=2560;
   end   
   %**************************   
   txatt(n)=extx;
   rxatt(n)=exrx;
   
   %Normalize Waveforms by accounting for External Attenuation and VGA Setting
   % External Attenuation
   if n==1 | n==2
      attenuation = 10^(( exrx + extx + offdB)/20);%account for offdB on first two scans
   else
      attenuation = 10^(( exrx + extx )/20);
   end   
      %Normalize to 0 dB attenuation
      scanmatrix(:,n)=attenuation*scandata(:,1);
      lockmatrix(:,n)= attenuation*scandata(:,2);
   % VGA Gain Setting
   	VGApossible=[2048 2304 2560 2816 3072 3328 3584 3840 4095];
   	VGAset=['800' '900' 'A00' 'B00' 'C00' 'D00' 'E00' 'F00' 'FFF'];
   	%VGA gain is relative to A00 (default) setting
  		VGAgain=[-9 -5 0 4 8 12 14 16 17];
   	i = find(VGApossible==VGA);
      VGAscale= 10^(( VGAgain(i) )/20);
      %Normalize to A00 VGA setting
   	scanmatrix(:,n)=scanmatrix(:,n)/VGAscale;
      lockmatrix(:,n)=lockmatrix(:,n)/VGAscale;
      gain(n)=VGAgain(i);
      
   nrdatapts=min(datalimit,minlength);   % decrease nrdatapts to minimum number read in any file in series
   %Check to make sure all files have same sampling resolution
   deltat(n)=timeperpt;
end;  %n

minlength=min(datalimit,minlength);
scanmatrix=scanmatrix(1:minlength,1:nrdatafiles);
lockmatrix=lockmatrix(1:minlength,1:nrdatafiles);
BERmatrix = BERmatrix(1:nrdatafiles,:);
SNRmatrix = SNRmatrix(1:nrdatafiles,:);

Number_of_files_read=n

%Read in Distancefile if available
FID=fopen([datadirectory 'distance.txt']);
if FID==-1
   distancedata = 1:nrdatafiles;
   distfile=0;
   disp(' ')
   disp(' ')
   disp('>> No distance.txt file found; this will prevent a path loss calculation.')
   %disp('>>Press spacebar to continue')
   disp(' ')
   %pause
   disttype=3;
else   
   fgetl(FID);	
   line=fgetl(FID);
   
   if line(2)=='f'
      disttype=1;
   elseif line(2)=='m'
      disttype=2;
   else
      disp(' ')
      disp(' ')
      disp('>> Specification of feet or meters was not found in distance file ')
      disp('>> Default of feet is assumed')
      %pause
      disttype=1;
   end   
   distancedata = fscanf(FID, '%f');
	distancedata = distancedata';
   fclose (FID);
   distfile=1;
end 
n=n;

for b=1:nrdatafiles-1
   if deltat(b)==deltat(b+1)
   	deltatflag=0;   
   else
      deltatflag=1;
   end
end 


%Account for difference in antenna heights (10-03-2001)   
if antheightadj==1 & distfile>0   
   if hTX>hRX | hTX<hRX
      %Compute angle for each distance
      for bb=1:length(distancedata)
      	ant_angle=180/pi*atan( abs(hTX-hRX) ./ distancedata(bb) );
         %Correction factor to normalize out height differential
         %  Equation taken from Excell curve fit
         %  Can never add to pathloss
         
         height_adjust= -0.0062*ant_angle^2 + 0.0131*ant_angle; %in dB
            height_adjust=10^(height_adjust/20); %Linear Voltage
         height_adjustLin=0.0000133196*(ant_angle)^3-0.001063716*(ant_angle)^2+0.0047927035*(ant_angle)+1 ;  
            
         scanmatrix(:,bb)=scanmatrix(:,bb)./height_adjust;
         lockmatrix(:,bb)=lockmatrix(:,bb)./height_adjust;
         
         h_adjust(bb)=20*log10(height_adjust);
         h_adjustLin(bb)=20*log10(height_adjustLin);
      end   
      disp(' ')
      disp(' ')
      disp('>> Scans Adjusted for Antenna Height')
      
      
   	%figure(gcf)
      %plot(distancedata,h_adjust,'rd');
      %hold on;
      %plot(distancedata,h_adjustLin,'b*');
      %hold off;
   	%grid on;
   	%title('Antenna height adjustment')
   	%xlabel('distance')
      %ylabel('dB')
      
      %figure(gcf+1)
      %plot(1:nrdatafiles,h_adjust,'rd');
      %hold on;
      %plot(1:nrdatafiles,h_adjustLin,'b*');
      %hold off;
   	%grid on;
   	%title('Antenna height adjustment')
   	%xlabel('distance')
   	%ylabel('dB')
   	%pause
   end
end
      

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%