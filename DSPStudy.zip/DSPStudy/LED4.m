%// returns the sample number of the direct path or -9999999 if can't find it
%// Envelope Difference First Peak with Dynamic Scaling
%int tdRADIO::LeadingEdgeDetection0(int numPts, long *iDataIn)

function [output,Template]=LED4(numPts,iDataIN,step,Ts,meantimes...
   ,k,firsttemp,template_sizens,Template,firstpeak4,tstart,tstop)
TS=Ts/1e-9;
inMean=0;
peak=1;
template_size = round( template_sizens/(Ts/1e-9) ); %samples

%x=[0,0,0];
%y=[0,0,0];
x1=0;
x2=0;
x3=0;
y1=0;
y2=0;
y3=0;

%Calculate Waveform Mean Voltage
for i=1:numPts
   inMean=inMean+iDataIN(i);
end
inMean=inMean/numPts;

%Correlate with IIR Filter
%for i=1:numPts
   %inputt=[iDataIN(i)-inMean];
   %[outputt,x1,x2,x3,y1,y2,y3]=FilterIIR3(inputt,x1,x2,x3,y1,y2,y3);
   %iDataINLocal(i)=outputt;
%Convolve with IIR Filter   
for i=0:numPts-1
   inputt=[iDataIN(numPts-i)-inMean];
   [outputt,x1,x2,x3,y1,y2,y3]=FilterIIR3(inputt,x1,x2,x3,y1,y2,y3);%FilterIIR2 does not square output
   iDataINLocal(numPts-i)=outputt;   
end   

%build envelope of correlated signal
	envelope=[];
	envelope(1) = 0;
	%compute first one
	for j=1:step
   	envelope(1)=envelope(1)+abs(iDataINLocal(j));  
	end
   
   for i=2:numPts-step
   	envelope(i)=envelope(i-1)-abs(iDataINLocal(i-1)) + abs(iDataINLocal(i+step-1));
   end
   
%find the average of the envelope 
envelopeMEAN=0;   
for i=1:numPts-step
	envelopeMEAN=envelopeMEAN+envelope(i);
end   
envelopeMEAN=envelopeMEAN/(numPts-step);
%Multiply mean by meantimes
%envelopeMEAN<<=1;
envelopeMEAN=envelopeMEAN*meantimes;

%find the first place we break this mean value
	for i=1:numPts-step
		if envelope(i)>=envelopeMEAN
         peak = i-1;
         %peak*TS;
         break;
      end
   end
   
   
% now lets snip out the leading edge for use in correlation
%Always use template from 1-meter scan

if firsttemp==1
   if k==1
   	for kk=1:template_size 
   		Template(kk) = iDataINLocal(peak+kk-1);
		end
   end   
elseif firsttemp==0
   for kk=1:template_size 
   	Template(kk) = iDataINLocal(peak+kk-1);
   end
end   

%Ensure indexes are > 0
	Start = peak - template_size;
   End   = peak + template_size;
   if Start<=2
   	Start=2;
	end
	if peak<=1
   	peak=1;
   end
   if End>=numPts
   	End=numPts;
	end
	peak1=peak;
	

% now lets correlate this template through the data
wavepeak=0;
for i=Start:End-1
    correlation(i) = 0;
    for j=1:template_size
       correlation(i) = correlation(i) + Template(j) * iDataINLocal(i+j-1);
    end
end

%Find Biggest Correlation Peak
for m=Start:End-1
   if correlation(m) > correlation(peak)
      peak = m;
   end  
   output = peak;
end

%Find First Correlation Peak
pcount=0;
curpeak=Start;
for m=Start:End-1   
   if correlation(m) > correlation(m-1) & correlation(m) > correlation(m+1) & m>(curpeak+round(.2/(TS)))
      if pcount==0
         prepeak=m;
         curpeak=prepeak;
         pcount=1;
      elseif pcount==1
         fpeak=m;
         curpeak=fpeak;
         pcount=2;
      elseif pcount==2
         postpeak=m;
         pcount==3;
         if correlation(fpeak)>correlation(prepeak) & correlation(fpeak)>correlation(postpeak)
            break
         elseif correlation(fpeak)<correlation(prepeak) 
            fpeak=prepeak;
            break
         elseif correlation(fpeak)>correlation(prepeak) & correlation(fpeak)<correlation(postpeak)
            prepeak=fpeak;
            fpeak=postpeak;
            pcount=2;  
         end
         curpeak=postpeak;
      end
   end
end   
if firstpeak4==1
   output = fpeak;
end   

if k==1
	figure(gcf+1)
   %subplot(211), 
   plot((0:numPts-1)*TS,iDataIN./max(abs(iDataIN)),'k.-')
	hold on
   %subplot(211), 
   plot((0:numPts-1)*TS,iDataINLocal./max(abs(iDataINLocal)),'r.-','LineWidth',2)
   plot((Start:End-1)*TS,correlation(Start:End-1)/max(abs(correlation(Start:End-1))),'m','LineWidth',2)
	%subplot(211), plot((0:numPts-1)*TS,iDataINLocal2./max(abs(iDataINLocal2)),'m.-')
   %axis([49.6 51 -.8 1.2])
   grid on
   plot((0:numPts-step-1)*TS,envelope/max(abs(envelope)),'g-*','LineWidth',2)
   plot((peak+(1:template_size)-2)*TS,Template./max(abs(Template)),'c','LineWidth',2)
   plot([fpeak fpeak]*TS, [-1 1],'--','LineWidth',2,'color','r')
   plot([peak1 peak1]*TS, [-1 1],'--','LineWidth',2,'color','b')
   plot([peak peak]*TS, [-1 1],'LineWidth',2,'color','b')
   plot([tstart tstop], [envelopeMEAN envelopeMEAN]./max(abs(envelope)),'LineWidth',2,'color','b')
   axis([tstart tstop -.8 1.2])
   %axis([11 14 -.8 1.2])
   xlabel('time (ns)')
	ylabel('normalized amplitude')
	title('LED4')
   %%%legend('Impulse Excitation','Manual IIR','MATLAB IIR')
   %legend('iDataIN','iDataINLocal','Envelope','LE4')
   hold off
end   


    