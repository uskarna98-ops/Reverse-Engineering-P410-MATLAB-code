clear
close all

%Values for older versions of STDAN without these parameters
endthreshhold=0;
threshdB=10;
offdB=0;
disttype=1;%force to feet
pointer=1;
corr1=1;
corr2=2;
corr3=4;
correlators=corr1;

calc_N90     =  1   ;
calc_Km90    =  0   ;
percent_less = 9.9 ;



disp('>> Enter the number of datasets to read:');
nrdatasets=input('');

distancedata_tot=[];
powersum_tot=[];
distancedata_mult=[];
powersum_mult=[];
rms_tot=[];
rms2delay_tot=[];
numpaths_tot=[];
peakratio_tot=[];
totpower_tot=[];
threshdB_tot=[];
endthreshhold_tot=[];

for m=1:nrdatasets

	disp('>> Enter the name of the folder where the data is stored.');
	datadirectory=input('    (if the data is in "c:\\analysis\\data\\", type "data\\" ) \n','s');
	datadirectory=['c:\analysis\' datadirectory];
	direct=pwd;
	%disp('>> Enter the name of the directory where the data is stored.');
	%datadirectory=input('    (for example, "c:\\analysis\\data\\" ) \n','s');

	%disp('>> Enter the base name of the data files.');
	%datafilename=input('    (for example, files scan1.dat thru scan8.dat, entry is "scan" ).\n','s');


	cd(datadirectory)
	load outputfile chanimpulse
	if chanimpulse==1
   	load  outputfile distancedata tpeakval rms rms2delay numpaths chanimpulse threshdB pointer disttype offdB endthreshhold
	else
   	load outputfile distancedata tpeakval rms chanimpulse pointer disttype offdB endthreshhold
	end
	cd c:\source
	nrdatafiles=length(distancedata);

	%Change all distances to feet
   if disttype==2
      distancedata=distancedata*3.28;%change meters to feet
      disttype=1;
   end   

%   Pathloss vs Distance   ********************************************************************

   %find energy using peak points with corr1 number of correlators
   powersum=zeros(1,nrdatafiles);
   powersum1=powersum;
   	for l=1:corr1
      	powersum1=powersum1+tpeakval(l,:).^2;
      end;
   	%powersum2=powersum;
   	%	for l=1:corr2
   	%   	powersum2=powersum2+tpeakval(l,:).^2;
   	%   end;
   	%powersum3=powersum;
   	%	for l=1:corr3
   	%   	powersum3=powersum3+tpeakval(l,:).^2;
   	%   end;     
        
   %Reference to 1st scan, not Absolute power in dBm
   	%Subtract 1 dB from reference
   	refnorm=powersum1(1);
      refd=distancedata(1);
         offdB;
         refnorm=refnorm*10^(offdB/10);
         powersum1=powersum1/refnorm;
         powersum1(1:2)=powersum1(1:2).*10^(offdB/10);
	

	distancedata_tot=[distancedata_tot distancedata]; 
   powersum_tot=[powersum_tot powersum1]; 
   distancedata_mult=[distancedata_mult distancedata(pointer)];
	powersum_mult=[powersum_mult powersum1(pointer)];
	rms_tot=[rms_tot rms]; 
   threshdB_tot=[threshdB_tot threshdB];
   endthreshhold_tot=[endthreshhold_tot endthreshhold];
	if chanimpulse==1
		rms2delay_tot=[rms2delay_tot rms2delay];
   	numpaths_tot=[numpaths_tot numpaths];
	end

end %end for m --------------------------------------------------------------

%Change names of combined data back to notation used by remainder of program
	distancedata=distancedata_tot; 
   powersum1=powersum_tot; 
   %distancedata_mult=distancedata_mult;
	%powersum_mult=powersum_mult;
	rms=rms_tot; 
   threshdB=sum(threshdB_tot)/nrdatasets;
   endthreshhold=sum(endthreshhold_tot)/nrdatasets;
	if chanimpulse==1
		rms2delay=rms2delay_tot;
   	numpaths=numpaths_tot;
	end

%Force Data to be less than 0 dB ---------------------------------------------
for bb=1:length(powersum1)
   if powersum1(bb)>1
      powersum1(bb)=1;
   end;
end   
   

%Calculate Curve Fits on combined datasets ------------------------------------------
   	freeref=-20*log10(distancedata/min(distancedata));
      relpower=(20*log10(sqrt(powersum1)));
      difpow=-(freeref-relpower);
      distdat1=min(distancedata):(max(distancedata)-min(distancedata))/40 : 2*max(distancedata);     
      
  %Least Squares Curve fit to 1/d^n ------------------------------------------------
		x=20*log10((sqrt(powersum1)));
        d=distancedata;
        counter=0;
      Nstart=1.0;
      Ninc=0.05;
      Nstop=5;
  		for N=Nstart:Ninc:Nstop
         counter=counter+1;  
         ya=sqrt(1./d.^N);
         %Normalize to 1 meter
         if disttype==1
            ya1=sqrt(1./(refd).^N);
         elseif disttype==2
            ya1=sqrt(1./(refd).^N);
         end   
         ya=20*log10((ya./ya1));
         Fa(counter)=sum( (x-ya).^2 );         
      end
      N=Nstart:Ninc:Nstop;
      [q,i]=min(Fa);
      N=N(i);
      ya=sqrt( 1 ./ (distdat1.^N) );
      %Normalize to 1 meter
      if disttype==1
         ya1=sqrt(1./(refd).^N);
      elseif disttype==2
         ya1=sqrt(1./(refd).^N);
      end   
      ya=20*log10((ya./ya1));
      

      
  %Least Squares Curve fit to exp(-Kd)/d^2 --------------------------------------------
  		x=20*log10((sqrt(powersum1)));
        d=distancedata;
        counter=0;
      Kstart=-0.1;
      Kinc=0.001;
      Kstop=0.25;
  		for K=Kstart:Kinc:Kstop
         counter=counter+1;  
         y=sqrt(exp(-K*d)./d.^2);
         %Normalize to 1 meter
         if disttype==1
            y1=sqrt(exp(-K*(refd))./(refd).^2);
         elseif disttype==2
            y1=sqrt(exp(-K*refd)./refd.^2);
         end
         y=20*log10((y./y1));
         F(counter)=sum( (x-y).^2 );         
      end
      K=Kstart:Kinc:Kstop;
      [q,i]=min(F);
      K=K(i);
      y=sqrt( exp(-K*distdat1) ./ (distdat1.^2) );
      %Normalize to 1 meter
      if disttype==1
            y1=sqrt(exp(-K*(refd))./(refd).^2);
      elseif disttype==2
            y1=sqrt(exp(-K*refd)./refd.^2);
      end
      y=20*log10((y./y1));
      
%Calculate the Standard Deviation of powersum1 with numbers in Log scale ---------------	

if calc_Km90==1
	%Km curve
		yK=20*log10( (sqrt(exp(-K*d)./d.^2)/y1) );   
   	powersum1K_dB=yK-20*log10(sqrt(powersum1+1e-20));
   	stddev_K=std( powersum1K_dB  )
      
      if percent_less>85
         zstart=1.2;
      elseif percent_less>75
         zstart=0.6;
      else
         zstart=-3;
      end
      
      for z=zstart:.002:3
      	%z=1.283;%for 90% reliability from P=0.5*erfc(-z/sqrt(2));%Calculated on 8/30/01, see page 91 of lab notebook II
      	M_K=stddev_K*z; %+ .31
      %Compute a 90% reliability Curve Fit based on standard deviation
   		y90=sqrt(exp(-K*distdat1)./distdat1.^2);
      	y90=20*log10((y90./y1))-(M_K);
      %CHeck on # of samples above line
      	y90a=sqrt(exp(-K*d)./d.^2);
      	y90a=20*log10((y90a./y1))-M_K;
      	count=0;
      	for b=1:length(distancedata)
         	if 20*log10(sqrt(powersum1(b))) >= y90a(b)
            	count=count+1;
         	end
      	end
         percent=count/length(distancedata)*100;
         if percent>=percent_less
            percent
            M_K
            break
         end
      end %for z   
      
      
elseif calc_N90==1      
      
   %N curve
      yN=20*log10( sqrt(1./d.^N)/ya1) ;   
   	powersum1N_dB=yN-20*log10(sqrt(powersum1+1e-20));
   	stddev_N=std( powersum1N_dB  )
   	      
      if percent_less>85
         zstart=1.2;
      elseif percent_less>75
         zstart=0.6;
      else
         zstart=-3;
      end
      
      for z=zstart:.002:3
      	%z=1.283;%for 90% reliability from P=0.5*erfc(-z/sqrt(2));%Calculated on 8/30/01, see page 91 of lab notebook II
      	M_N=stddev_N*z; %+ .31
      %Compute a 90% reliability Curve Fit based on standard deviation
      	y90=sqrt(1./distdat1.^N) ;
         y90=20*log10((y90./ya1))-(M_N);
      %CHeck on # of samples above line
         y90a=sqrt(1./d.^N) ;
         y90a=20*log10((y90a./ya1))-(M_N);
         
      	count=0;
      	for b=1:length(distancedata)
         	if 20*log10(sqrt(powersum1(b))) >= y90a(b)
            	count=count+1;
         	end
      	end
         percent=count/length(distancedata)*100;
         if percent>=percent_less
            percent
            M_N
            break
         end
      end %for z   
end %if calc_N90 calc_Km90      
      
%Plot PathLoss -------------------------------------------------------------------------      

	if max(distancedata)<=100
   	maxxpoint=ceil(max(distancedata)/10)*10;
	else
  		maxxpoint=ceil(max(distancedata)/100)*100;
	end    
	if min(distancedata)>=10
   	minpoint=10;
	else
  		minpoint=0;
	end 

	figure(gcf);
 	colorstring=['b-','m-','k-','g-'];
  %Plot Reference Lines
	   r2=-20*log10(distdat1/min(distdat1));
      
      r3=-30*log10(distdat1/min(distdat1));
      %semilogx
      plot(distdat1,r2,'linewidth',2,'color','r') 
      hold on;
      %plot(distdat1,r3,'g-s')     
      
  %Plot 1/d^N curve fit
      plot((distdat1),(ya),'linewidth',2,'color','b')
      if calc_N90==1
      	plot(distdat1,(y90),'linewidth',2,'color',[0 .8 1])
      end
      
  %Plot exp(-Kd)/d^2 curve fit
  		plot(distdat1,(y),'linewidth',2,'color','m')
      if calc_Km90==1
      	plot(distdat1,(y90),'linewidth',2,'color',[1 .5 .7])
      end
      
  %Plot the actual data points         
     plot((distancedata),20*log10(sqrt(powersum1)),'k*');
  %Plot the multipath peak data points         
     %plot(distancedata_mult,20*log10(sqrt(powersum_mult)),'g*');    
     
  %Re-Plot Lines to overlay points -----------------------------
      plot(distdat1,r2,'linewidth',2,'color','r') 
      hold on;
      plot((distdat1),(ya),'linewidth',2,'color','b')
      plot(distdat1,(y),'linewidth',2,'color','m')
      if calc_N90==1 | calc_Km90==1
         plot(distdat1,(y90),'linewidth',2,'color',[0 .8 1])
      elseif calc_Km90==1   
         plot(distdat1,(y90),'linewidth',2,'color',[1 .5 .7])
      end   
  %-------------------------------------------------------------   
       
  %Set Axes, Notes    
  		%ple1=[('n=') num2str(n)];
      ple1a=[('N=') num2str(N)];  
      if disttype==1
         %ple2=[('K_f =') num2str(K)];
         Km=3.28*K;
         Km=round(Km*100)/100;
         Lw=-10*log10(exp(-Km)); 
         Lw=round(Lw*100)/100;
         ple2=[('Km=') num2str(Km) ', Lw=' num2str(Lw)];
      elseif disttype==2
         Km=K;
         Km=round(Km*100)/100;
         Lw=-10*log10(exp(-Km));   
        	ple2=[('Km=') num2str(Km) ', Lw=' num2str(Lw)];
     	end 
      
      if calc_Km90==1
         plePER=[num2str(round(percent*10)/10) '% Rel to Km'];
         pleMAR=['Margin = ', num2str( round(M_K*10)/10 ) ' dB'];
      elseif calc_N90==1   
         plePER=[num2str(round(percent*10)/10) '% Rel to N'];
         pleMAR=['Margin = ', num2str( round(M_N*10)/10 ) ' dB'];
      else
         plePER=[];
         pleMAR=[];
      end
      
      if calc_N90==1
         legend('Free Space',ple1a,plePER,ple2,'data')%legend('Free Space',ple1a,ple2,'90% Rel','data','multipath peaks',pleoffdB)
      else   
         legend('Free Space',ple1a,ple2,plePER,'data')%legend('Free Space',ple1a,ple2,'90% Rel','data','multipath peaks',pleoffdB)
      end   
      pleoffdB=['offdB = ', num2str(offdB)];
      text(8,-1.5,pleoffdB)
      text(20,-7.5,pleMAR,'fontsize',12,'color','r')
      smaller=min(-30*log10([max(distancedata)/min(distancedata)]),20*log10(sqrt(powersum1))-6);
      miny=(ceil(min(smaller+0)/3)*3-3);
      axis([minpoint maxxpoint miny 3]); %axis([0 3.0 -100 -20]);
      vecor=[];
      for gt=miny:3:3
         vecor=[vecor gt];
      end 
      set(gca,'yTick',vecor)
      grid on;
		if disttype==1
        xlabel('Distance (feet)');
     elseif disttype==2
        xlabel('Distance (meters)');
     end 
		ylabel('Relative Received Power (dB)');
		ple=[('Calculated from ') num2str(length(distancedata)) ' scans (calculated assuming ',num2str(corr1), ' peak)  '  date];
   	title(ple);
      hold off;
      
% RMS delay spread --------------------------------------------------------------------------
      figure(gcf+1)
      rmsplot=gcf;
      %semilogx
      plot(distancedata,rms,'*','color',[.3 .7 .1]);
   	ple=['RMS Delay Spread (threshold=' num2str(endthreshhold) '*noise)'];
   	title(ple);
   	if disttype==1
        xlabel('Distance (feet)');
     	elseif disttype==2
        xlabel('Distance (meters)');
     	end 
   	ylabel('RMS Delay (ns)');
      
      hold on;
      [m b]=linefit((distancedata),rms);
      yhattilderms= m.*(distancedata)+b  ;  % this is the un-logarithmic curve fit 
      hold on;
      %Move curve fit to after rmsdelay2 so that legend makes sense
      if chanimpulse==0
         plot(distancedata,yhattilderms,'r');
      end   
      hold off;
      
      grid on;
   	axis([minpoint maxxpoint 0 max(10,max(rms)+5)])

      
 
 %Plot RMS Delay spread calculated from Channel Impulse
 if chanimpulse==1
 	fig=gcf;

      figure(rmsplot)
      hold on;
      %semilogx
      plot(distancedata,rms2delay,'r*');
      hold off;
      legend('waveform','chan impulse')
      
          
      
      hold on
      [m1 b1]=linefit((distancedata),rms2delay);
      yhattilde= m1.*(distancedata)+b1  ;  % this is the un-logarithmic curve fit 
      hold on;
      %semilogx
      
      plot(distancedata,yhattilderms,'color',[.3 .7 .1]);
      plot(distancedata,yhattilde,'r');
      hold off;
      
      grid on;
   	axis([minpoint maxxpoint 0 max(10,max(rms)+5)])
      ple=['RMS Delay Spread (threshold=' num2str(endthreshhold) '*noise, ', num2str(threshdB), ' dB threshold)'];     
      title(ple) 
      
 
   figure(fig)
 end %if chanimpulse  
   
   
 %Number of scatterers within a given threshold -----------------------------------------
 if chanimpulse==1

      figure(gcf+1)
      %semilogx
      plot(distancedata,numpaths,'b*');
      title(strcat('Number of Scaterers (',num2str(threshdB), ' dB threshold)'));
   	if disttype==1
        xlabel('Distance (feet)');
     	elseif disttype==2
        xlabel('Distance (meters)');
     	end 
   	ylabel('Number of Scaterers');
      
      hold on;
      [m b]=linefit((distancedata),numpaths );
      yhattilde= m.*(distancedata)+b  ;  % this is the un-logarithmic curve fit 
      hold on;
      %semilogx
      plot(distancedata,yhattilde,'b');
      hold off;
      
      axis([minpoint maxxpoint 0 max(10,ceil(max(numpaths)/5)*5+5)])
      grid on;
         
      

end %if chanimpulse  

figure(1)