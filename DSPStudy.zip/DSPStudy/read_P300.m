function [los,stud,pol,genloc,walls,datavalid,P300stuffon]=read_P300(nrdatafiles,datadirectory,setrange,nrdatast,nrdatasp);

for bb=1:nrdatafiles
      
      %LOS 
      FID=fopen([datadirectory 'los.txt']);
      if FID>0
         P300stuffon=1;
         los = fscanf(FID, '%s');
         if setrange==1
            los=[los(1:2) los(nrdatast:nrdatasp)];
         end   
         fclose (FID);
      else
         los(bb)='-';
         P300stuffon=0;
      end
      
      %# of walls penetrated 
      FID=fopen([datadirectory 'walls.txt']);
      if FID>0
         P300stuffon=1;
         walls = fscanf(FID, '%s');
         if setrange==1
            walls=[walls(1:2) walls(nrdatast:nrdatasp)];
         end   
         fclose (FID);
      else
         walls(bb)='-';
         P300stuffon=0;
      end
            
      %Stud 
      FID=fopen([datadirectory 'stud.txt']);
      if FID>0
         P300stuffon=1;
         stud = fscanf(FID, '%s');
         if setrange==1
            stud=[stud(1:2) stud(nrdatast:nrdatasp)];
         end   
         fclose (FID);
      else
         stud(bb)='-';
         P300stuffon=0;
      end
      
      
      %Polarization 
      FID=fopen([datadirectory 'pol.txt']);
      if FID>0
         P300stuffon=1;
         pol= fscanf(FID, '%s');
         if setrange==1
            pol=[pol(1:2) pol(nrdatast:nrdatasp)];
         end   
         fclose (FID);
      else
         pol(bb)='-';
         P300stuffon=0;
      end
      
      
      %General Location 
      FID=fopen([datadirectory 'genloc.txt']);
      if FID>0
         P300stuffon=1;
         genloc= fscanf(FID, '%s');
         if setrange==1
            genloc=[genloc(1:2) genloc(nrdatast:nrdatasp)];
         end   
         fclose (FID);
      else
         genloc(bb)='-';
         P300stuffon=0;
      end
      
      %Data Valid 
      FID=fopen([datadirectory 'datavalid.txt']);
      if FID>0
         P300stuffon=1;
         datavalid= fscanf(FID, '%s');
         if setrange==1
            datavalid=[datavalid(1:2) datavalid(nrdatast:nrdatasp)];
         end   
         fclose (FID);
      else
         datavalid(bb)='-';
         P300stuffon=0;
      end
      
  	end 