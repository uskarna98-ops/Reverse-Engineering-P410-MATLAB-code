function [g]=writefile(t,filteredscanmatrix,scanmatrix, nrdatafiles,datafilename, distancedata,EbNeff,...
   snrinmatrix,signalmatrix,noisematrix,relpower,freeref,difpow,...
   VGA,txatt,rxatt,rms,rms2delay,writeWAVE,datadirectory,direct,disttype,numpaths,peakpowerratio,...
   totpow,peakpower,meanexcessdelay,excessdelay,RAKEdB,PEAKSused,Numpeaks,PNratio,SpeakV,SrmsV,...
   CIRpeakV,CIRrmsV,filenum,cleanstop,writeCIR,CIRout,P300stuffon,los,stud,pol,genloc,walls,datavalid,...
   relerror,angerror,tcalclos,CIRLOS,Eratio,meas_sys)
% writefile.m

%

% cd(datadirectory)
% if cleanstop<=1
%    FID3=fopen([datafilename '_DATA_alpha=' num2str((cleanstop)) '.out'],'w');
% elseif cleanstop>1
%    FID3=fopen([datafilename '_DATA_thresh=' num2str((cleanstop)) '.out'],'w');
% end 
% 
% 
% 
% if meas_sys=='PAD' | meas_sys=='pad' 																																			
%     fprintf(FID3,   '-     d      Pos---- Neg---- Comp--- Scan   -       -       -        -       -      Scan     Scan   CIR      CIR     Scan    CIR     Mean   Excess  Peak    Tot       CIR    PosNeg  RAKE    RAKE    #       Power\n');
%     if disttype==1
%         fprintf(FID3,'#     ft     SNR     SNR     SNR     SNR    Signal  Noise   relpow   freesp  difpow PeakV    RMSV   PeakV    RMSV    RMSdel  RMSdel  Delay  Delay   Pow(dB) Pow(dB)  PEAKS   Ratio   (dB)    Peaks   Scats   Ratio    VGA   TXatt  RXatt \n');
%     elseif disttype==2   
%         fprintf(FID3,'#     m      SNR     SNR     SNR     SNR    Signal  Noise   relpow   freesp  difpow PeakV    RMSV   PeakV    RMSV    RMSdel  RMSdel  Delay  Delay   Pow(dB) Pow(dB)  PEAKS   Ratio   (dB)    Peaks   Scats   Ratio    VGA   TXatt  RXatt \n');
%     else    
%         fprintf(FID3,'     << No Distance File Prevented Pathloss Calculations >>\n');
%         fprintf(FID3,'#     #      SNR     SNR     SNR     SNR    Signal  Noise   relpow   freesp  difpow PeakV    RMSV   PeakV    RMSV    RMSdel  RMSdel  Delay  Delay   Pow(dB) Pow(dB)  PEAKS   Ratio   (dB)    Peaks   Scats   Ratio    VGA   TXatt  RXatt \n');
%     end
% else
%     fprintf(FID3,   '-     d      File--- File--- File--- Scan   -       -       -        -       -      Scan     Scan   CIR      CIR     Scan    CIR     Mean   Excess  Peak    Tot       CIR    PosNeg  RAKE    RAKE    #       Power\n');
%     if disttype==1
%         fprintf(FID3,'#     ft     EbNeff  Eb      Neff    SNR    Signal  Noise   relpow   freesp  difpow PeakV    RMSV   PeakV    RMSV    RMSdel  RMSdel  Delay  Delay   Pow(dB) Pow(dB)  PEAKS   Ratio   (dB)    Peaks   Scats   Ratio    VGA   TXatt  RXatt \n');
%     elseif disttype==2   
%         fprintf(FID3,'#     m      EbNeff  Eb      Neff    SNR    Signal  Noise   relpow   freesp  difpow PeakV    RMSV   PeakV    RMSV    RMSdel  RMSdel  Delay  Delay   Pow(dB) Pow(dB)  PEAKS   Ratio   (dB)    Peaks   Scats   Ratio    VGA   TXatt  RXatt \n');
%     else    
%         fprintf(FID3,'     << No Distance File Prevented Pathloss Calculations >>\n');
%         fprintf(FID3,'#     #      EbNeff  Eb      Neff    SNR    Signal  Noise   relpow   freesp  difpow PeakV    RMSV   PeakV    RMSV    RMSdel  RMSdel  Delay  Delay   Pow(dB) Pow(dB)  PEAKS   Ratio   (dB)    Peaks   Scats   Ratio    VGA   TXatt  RXatt \n');
%     end
% end
% % for m=1:nrdatafiles
% %    tempmatrix=[filenum(m)' ; distancedata(m)' ; EbNeff(m,:)' ; snrinmatrix(m); (signalmatrix(m));(noisematrix(m)); relpower(m)' ; freeref(m)' ; difpow(m)' ;SpeakV(m)' ; SrmsV(m)' ; CIRpeakV(m)' ; CIRrmsV(m)' ; rms(m); rms2delay(m)'; meanexcessdelay(m)'; excessdelay(m)'; 10*log10(peakpower(m))'; 10*log10(totpow(m))'; Numpeaks(m)'; PNratio(m)'; RAKEdB(m)'; PEAKSused(m)'; numpaths(m)'; peakpowerratio(m)'; VGA(m)' ; txatt(m)' ; rxatt(m)'];
% %    fprintf(FID3,'%.0f %7.1f %7.1f %7.1f %7.1f %7.1f %7.1f %7.1f %7.2f %7.1f %7.1f %7.4f %7.4f %7.4f %7.4f %7.1f %7.1f %7.1f %7.1f %7.2f %7.2f %7.0f %7.2f %7.2f %7.0f %7.0f %7.3f %6.0f %6.0f %6.0f\n',tempmatrix);
% % 
% % end %m   
% 
% fclose(FID3);


if writeCIR==1
   cd(direct)
   ftype='CIR';
   tle=['//NORMALIZED CHANNEL IMPULSE RESPONSES (N=' num2str(nrdatafiles) ')'];
   [g]=writefileOUT(distancedata,datafilename,datadirectory,direct,t,CIRout,nrdatafiles,RAKEdB,...
   PEAKSused,excessdelay,meanexcessdelay,rms2delay,totpow,peakpower,CIRpeakV,CIRrmsV,filenum,...
   cleanstop,ftype,tle,P300stuffon,los,stud,pol,genloc,walls,datavalid,relerror,angerror,...
   tcalclos,CIRLOS,Eratio,disttype);
end

if writeWAVE==1   
   cd(direct)
   ftype='WAV';
   tle=['//NORMALIZED SCAN WAVEFORMS (N=' num2str(nrdatafiles) ')'];
   [g]=writefileOUT(distancedata,datafilename,datadirectory,direct,t,filteredscanmatrix',nrdatafiles,RAKEdB,...
   PEAKSused,excessdelay,meanexcessdelay,rms2delay,totpow,peakpower,SpeakV,SrmsV,filenum,...
   cleanstop,ftype,tle,P300stuffon,los,stud,pol,genloc,walls,datavalid,relerror,angerror,...
   tcalclos,CIRLOS,Eratio,disttype);
end %if

g=1;
cd(direct)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%