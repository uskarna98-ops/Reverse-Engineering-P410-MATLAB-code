function [snr, sig, nos,output0]=dolockchannel(inputvector,lockinterp,rr)
% dolockchannel.m
% 
% operation:
%   breaks apart lock/data channel into early and late pulse data
%   uses FFT/IFFT techniques to remove oscillatory components from lock channel
%   calculates SNR of early and late channel with and without these filtering techniques
%
% usage:
%    [output1, onesspectrum, error1, output0, zerosspectrum, error0, snr]=dolockchannel(inputvector)
%                   snr 1x2 matrix containing SNR of zeros and ones respectively
%
%    inputs:  inputvector         vector containing lock/data channel information
%    
%    outputs: output1             vector containing linearly interpolated version of 1's (late) bits of lock/data channel
%             onesspectrum        spectrum of 1's (late) bits of lock/data channel
%             error1              error vector removed from 1's (late) bits of lock/data channel by (inverse) Fourier 
%                                        transforms
%             output0             vector containing linearly interpolated version of 0's (early) bits of lock/data channel
%             zerosspectrum       spectrum of 0's (early) bits of lock/data channel
%             error0              error vector removed from 0's (early) bits of lock/data channel by (inverse) Fourier
%                                        transforms
%             snr                 dimension [4 x 1] vector containing [snr0 before error vector removed
%                                                                      snr1 before error vector removed
%                                                                      snr0 after error vector removed
%                                                                      snr1 after error vector removed];
%
%                                                                     


% last edited by:
%   David J. Hall
%   Time Domain Systems, Inc.
%   10 Aug 2000
%   14:26

avg=mean(inputvector);
output1=zeros(1,length(inputvector));
output0=zeros(1,length(inputvector));
for k=1:length(inputvector)
   if inputvector(k)>=avg
      output1(k)=inputvector(k);
   else
      output0(k)=inputvector(k);
   end
end;  



% Look for strings of consecutive zeros in output1[] and output0[].
% Eliminate them by performing linear interpolation between values 
% on either side of each string.

if 1==1
   % force all ending 0 values equal to the last non-zero value
	pointer=length(output0);
	while(output0(pointer)==0)
   	pointer=pointer-1;
	end;
	for(k=pointer:length(output0))
   	output0(k)=output0(pointer);
	end   

	pointer=1;
	while (output0(pointer)==0) 
   	pointer=pointer+1;
	end;

	% force all leading 0 values equal to the first non-zero value
	for(k=1:pointer-1)
   	output0(k)=output0(pointer) ;
	end;   

	while(pointer<(length(output0)))
      y0=output0(pointer);
  		zerocount=0;
   	pointer=pointer+1;
   	while(output0(pointer)==0  & pointer<length(output0))
      	pointer=pointer+1;
      	zerocount=zerocount+1;
   	end;   

	   y1=output0(pointer);
   	x0=pointer-zerocount-1;
   	x1=pointer;
   	for k=(x0+1):(x1-1)
      	output0(k)=y1+(y1-y0)*(k-x1)/(x1-x0);
   	end   
   	x0=x1;
	end;
	mean0=mean(output0);

	% force all ending 0 values equal to the last non-zero value
	pointer=length(output1);
	while(output1(pointer)==0)
   	pointer=pointer-1;
	end;
	for(k=pointer:length(output1))
   	output1(k)=output1(pointer);
	end   


	pointer=1;
	while (output1(pointer)==0) 
   	pointer=pointer+1;
	end;

	% force all leading 0 values equal to the first non-zero value
	for(k=1:pointer-1)
   	output1(k)=output1(pointer) ;
	end;   


	while(pointer<(length(output1)))
      y0=output1(pointer);
   	zerocount=0;
   	pointer=pointer+1;
   	while(output1(pointer)==0 & pointer<length(output1))
      	pointer=pointer+1;
      	zerocount=zerocount+1;
   	end;   

	   y1=output1(pointer);
   	x0=pointer-zerocount-1;
   	x1=pointer;
   	for k=(x0+1):(x1-1)
      	output1(k)=y1+(y1-y0)*(k-x1)/(x1-x0);
   	end   
	   x0=x1;
	end;
	mean1=mean(output1);
   
else
	mean1=mean(output1);
	mean0=mean(output0);
end %if lockinterp

snr=[0 0 0 0 0 0];
sig=[0 0 0 0 0 0];
nos=[0 0 0 0 0 0];
snr(1)=(((mean1-mean0)/2)^2)/std(output0)^2;

sig(1)=(((mean1-mean0)/2)^2);
nos(1)=std(output0)^2;
%snr(2)=((mean1-mean0)^2)/std(output1)^2;

snr(2)=(((mean1-mean0)/2)^2)/std(output1)^2;
sig(2)=(((mean1-mean0)/2)^2);
nos(2)=std(output1)^2;

%Calculate a Composite SNR
comp_ave=((mean1-mean0)/2);
comp_var=sum(( (output1-output0)/2 - comp_ave ).^2)/length(inputvector); 
comp_std=sqrt(comp_var);
snr(5)=(comp_ave/comp_std)^2;
sig(5)=comp_ave^2;
nos(5)=comp_std^2;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% filter out dominant sinusoidal corrupting frequency
if lockinterp==1
	onesspectrum=fft(output1);
	e1=zeros(1,length(onesspectrum));
	onesspectrum(1)=0;
	temp=abs(onesspectrum);
	onesmean=mean(temp);
	for k=1:length(onesspectrum)
   	if(temp(k) >(15*onesmean))
      	e1(k)=onesspectrum(k);
      	onesspectrum(k)=0;
   	end      
	end;   
	output1=real(ifft(onesspectrum));
	error1=real(ifft(e1));

	zerosspectrum=fft(output0);
	e0=zeros(1,length(zerosspectrum));
	zerosspectrum(1)=0;
	temp=abs(zerosspectrum);
	zerosmean=mean(abs(zerosspectrum));
	for k=1:length(zerosspectrum)
   	if( temp(k) >15*(zerosmean) )
      	e0(k)=zerosspectrum(k);
      	zerosspectrum(k)=0;
   	end      
	end;   
	output0=real(ifft(zerosspectrum));
	error0=real(ifft(e0));
end %if lockinterp

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% calculate signal to noise ratios for ones and zeros
snr(3)=(((mean1-mean0)/2)^2)/std(output0)^2;
sig(3)=(((mean1-mean0)/2)^2);
nos(3)=std(output0)^2;

%snr(4)=((mean1-mean0)^2)/std(output1)^2;
snr(4)=(((mean1-mean0)/2)^2)/std(output1)^2;
sig(4)=(((mean1-mean0)/2)^2);
nos(4)=std(output1)^2;

%Calculate a Composite SNR
comp_ave=((mean1-mean0)/2);
comp_var=sum(( (output1-output0)/2 - comp_ave ).^2)/length(inputvector); 
comp_std=sqrt(comp_var);
snr(6)=(comp_ave/comp_std)^2;
sig(6)=comp_ave^2;
nos(6)=comp_std^2;

snr=10*log10(snr);                      % convert SNR to dB
sig=10*log10(sig);
nos=10*log10(nos);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%