function [timezero1,breaktime,CIRpeakV,CIRrmsV,RAKEdB,peaksused,thpeaks,hpeaks,rmsdelay,meandelay,...
      excessdelay,thresh,threshdB,peakratio,totalpower]=chan_stats(rakes,t,h,Ts,firstpeak,...
   	threshdBpre)
	adj=0;
   toffset=t;
   %firstpeak=20; %dB down from main peak
   thresh=firstpeak; %dB down from main peak
   thresh2=firstpeak-10; %dB down from main peak for points delayed more than 225 ns 
   
   %Calculate Peak and RMS voltage (before normalize)
 	[CIRpeakV,CIRrmsV]=calcrmsV(h);  
   
   hnorm=max(abs(h));
   h=h./hnorm; %normalize h
   
   
   %Set for start of peak search
   qh=find( abs(h) > (max(abs(h))*10^(-threshdBpre/20)) );
   ih=qh(1);
   if ih==1
      ih=2
   end   
      
   %Storng correlation sidelobes occur every 200 ns so raise thresh 175 ns after lock spot
   breaktime=round(t(ih))+185; %ns
   if max(t)<=breaktime
      breaktime=max(t);
   end   
         
         hdB=20*log10(abs(h+1e-12))-adj;
         qq=1;
         for ee=ih:1:length(h)-2
            if hdB(ee)>hdB(ee-1) & hdB(ee)>hdB(ee+1) 
               
               %Threshold changes at 225 ns to deal with correlation sidelobes in data
               if t(ee)<=breaktime
                  if hdB(ee)>-thresh
                  	index(qq)=ee;
                  	peaks(qq)=hdB(ee); 
                  	qq=qq+1;
                  end
               elseif t(ee)>breaktime
                  if hdB(ee)>-thresh2
                  	index(qq)=ee;
                  	peaks(qq)=hdB(ee); 
                  	qq=qq+1;
                  end
               end %if t(ee)
               
            end
         end %for ee
         first_peak=peaks(1);
         s1=index(1);
         [max_peak,i]=max((peaks));
         s=index(i);
         %Accounts for if max is not first arriving pulse
         if s>s1+20
            s=s1;
         end   
         timezero=t(s);
         
         %Convert Peaks back to linear to plot
         hpeaks=10.^(peaks/20)*hnorm;
         thpeaks=t(index);
         
                 
         %Make maxpeak time zero
         to=t; %Original time scale
         t=t-timezero;
         	timezero1=timezero;
         	timezero=0;
         
         	%[q,s]=max(abs(h));
         	%timezero=t(s);
            %H=H.*exp(j*2*pi*fw*(timezero));
        	 	%h=(ifft(H));timezero=0;s=1;
         	%hdB=20*log10(abs(h))-adj;
            
            
         %Find Noise Floor
         %NF=mean(hdB(200:300));   
         %if thresh > abs(max(hdB)-NF-10)
         %   thresh=(max(hdB)-NF-10);
         %end   
         
         %Set Threshold for Delay spread calc
         for ww=1:length(h)           
            if abs(max(hdB)-hdB(ww)) < thresh
               stop=ww;
               dspread=t(ww);%time in ns
            end
         end  
         
         %Adjust for limits of vector
         if s==1
            s=s+1;
         end
         if stop==length(h)
            stop=stop-1;
         end  
         
         per=0;
         yy=1;
         for ee=s:1:stop
            if hdB(ee)>hdB(ee-1) & hdB(ee)>hdB(ee+1) 
               %Only Crunch peaks
               %Threshold changes at 225 ns to deal with correlation sidelobes in data
               if to(ee)<=breaktime
               	if hdB(ee) > max(hdB)-thresh
                  	pt(yy)=hdB(ee);
                  	tt(yy)=t(ee);
                  	yy=yy+1;
                  	lastee=ee;
                  end
               elseif to(ee)>breaktime
               	if hdB(ee) > max(hdB)-thresh2
                  	pt(yy)=hdB(ee);
                  	tt(yy)=t(ee);
                  	yy=yy+1;
                  	lastee=ee;
                  end   
               end %if to(ee)   
            end
            
            %Cruches all points within Threshold
            	%if hdB(ee) > max(hdB)-thresh
              	   	%pt(yy)=hdB(ee);
                  	%tt(yy)=t(ee);
                  	%yy=yy+1;
            	%end 
            per=per+abs(h(ee));
         end %for ee
         
         
         %Calculate pt and tt directly from first hdB and t
         	tt2=to(index)-timezero1;
         	pt2=peaks;
         	%[tt' pt' tt2' pt2']
         	
         
         
%%%%%%%%%Change to Linear%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
			pt=10.^(pt/20);%voltage         
         Pt=abs(pt).^2;%power
         
         peakratio=max(pt.^2)./sum(pt.^2);
         
         %Multiply total power by hnorm to undo normalization to itself
         totalpower=sum( (pt.*hnorm).^2 );
         %pt is a voltage not power       
                  
         excessdelay=(t(lastee)-timezero);
         percentpower=per/sum(abs(h))*100;
                 
         %Calculate RAKE Gain assuming x rakes, 3 dB noise increase for each tooth
         rakepeak=[];
         RAKEdB=0;
         peaksused=1;
         pt1=pt;
         pt1=pt1/max(abs(pt1));%Normalize to biggest peak in PDP
         [maxpath,ww]=max(abs(pt1));%Find biggest peak
         rakepeak(1)=maxpath(1);
         pt1(ww(1))=0;%Zero biggest peak
         for jj=2:rakes
            RAKEdBold=RAKEdB;
            [maxpath,ww]=max(abs(pt1));%Find biggest remaining peak
            rakepeak(jj)=maxpath(1);
            pt1(ww(1))=0;%Zero biggest peak
            raketot=sum(rakepeak);
         	RAKEdB=20*log10(raketot)-20*log10(sqrt(jj));
            if RAKEdBold>RAKEdB
               RAKEdB=RAKEdBold;
               break
            end
            peaksused=jj;
         end
                           
         %Mean Excess Delay Spread
         %Pt is a power
         tPt=tt.*Pt;
         meandelay=sum(tPt)./sum(Pt);                 
       
         
         %RMS Delay Spread
         %t2Pt=(t.^2).*Pt;
         t2Pt=(tt.^2).*Pt;
         t2 = sum(t2Pt)./sum(Pt);
         st=sqrt( t2 - meandelay.^2 );
         rmsdelay=st;
                  
    threshdB=thresh;
    %find index to transition threshold
    threshbreak=find(to>=breaktime& to<=breaktime+.5);   
    threshbreak=threshbreak(1);
    
    %Convert back to linear
    thresh=10^(-thresh/20) * hnorm;
    thresh2=10^(-thresh2/20) * hnorm;
    %Make vector to be plotter
    thresh=[ones(1,threshbreak)*thresh ones(1,length(to)-threshbreak)*thresh2];
    
 
