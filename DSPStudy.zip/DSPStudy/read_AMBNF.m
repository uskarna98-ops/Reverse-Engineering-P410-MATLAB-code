close all
clear all

flag=0;
started=0;
datadirectory='q:\scottyano\P200 EVK Measurements\ambientscan 11-6-02\';
datafilename='scan';
maxnumberoffiles=100;
	for n=1:maxnumberoffiles
      if n==1
         FID = fopen([datadirectory datafilename '.log']);
      else
         FID = fopen([datadirectory datafilename num2str(n) '.log']);
      end
      if FID==-1
         if FID==-1 & started==2
            break
         end
      else
      	if flag==0
      		nstart=n;
            flag=1;
            started=1;
      	elseif flag==1
            nstop=n;
            started=2;
         end
      	fclose(FID);   
      end   
   end
%Display message if no data files found   
if flag==0
   disp(' ');
	disp(' ');
   disp('>>No scan files found; Check path and/or file name and restart program.');
   disp('>>press <CTRL>-C to end program');
   disp(' ');
   disp(' ');
   pause;
end   

nrdatafiles=nstop-nstart+1;

BERmatrix = zeros(nrdatafiles,1);
SNRmatrix = zeros(nrdatafiles,3);

datalimit=30000;%16500
scandata = zeros(datalimit,2);
lockmatrix = zeros(datalimit,nrdatafiles);
scanmatrix = zeros(datalimit,nrdatafiles);

maxlength=0;
minlength=99999;


N=[1 1 2 2 4 4 8 8 16 16 32 32 64 64 128 128 256 256 512 512 1024 1024 1 1 2 2 4 4 8 8 16 16 32 32 64 64 128 128 256 256 512 512 1024 1024];
PATNeff=ones(1,length(N))*130;%[130.37 130.39 130.37 130.38 130.25 130.19 130.08 130.09 128.02 129.46 127.08 127.68 124.22 123.89 117.59 115.82 45.15 45.28];
for n=1:nstop-nstart+1
   
   filen=nstart+n-1;
   if n==1
         datfile=[datadirectory datafilename '.log'];
      else
         datfile=[datadirectory datafilename num2str(filen) '.log'];
      end
   FID = fopen(datfile);
   if n==1 | rem(n,10)==0   
      n 
   end
   
   	%Sift Through Header To Get Time Base Offset
   	%linedata=fgets(FID);
    %  while (strncmp(linedata,'INTG',4))==0;
   	%   linedata = fgets(FID);
    %  end
    
    linedata=fgets(FID);
      while (strncmp(linedata,'NoComment',9))==0;
   	   linedata = fgets(FID);
      end
     linedata = fgets(FID);
     linedata = fgets(FID);
     numpts=str2num(linedata);
     if n==1
         numpts
     end    
     linedata = fgets(FID);
     if N(n)==1
        x = fscanf(FID,'%f',[1 inf]);
     else
        x = fscanf(FID,'%f %f',[2 inf]);
     end
     x = x';
     data(:,n)=x(:,1);
     fclose(FID);
end;  %n
Number_of_files_read=nrdatafiles

%Remove DC Offset
dataRAW=data;
steps=51;
xhist=-(steps-1)/2:(steps-1)/2;
for n=1:nrdatafiles
    DCoffset(n)=mean(data(:,n));
    data(:,n)=data(:,n)-DCoffset(n);
    noise(n)=2*var(data(:,n));
    distribution(n,:)=hist(data(:,n),steps);
end    



figure(gcf)
for n=1:2:nrdatafiles
    
    subplot(221)
    plot(data(:,n))
    legend(['scan' num2str(n)])
    title(['N=' num2str(N(n)) ', Variance= ' num2str(10*log10(noise(n))) ' dB'])
    axis([0 numpts -4000 4000])
    %axis tight
    subplot(222)
    bar(xhist,distribution(n,:))
    title(['N=' num2str(N(n))])
    
    subplot(223)
    plot(data(:,n+1))
    legend(['scan' num2str(n+1)])
    title(['N=' num2str(N(n+1)) ', Variance= ' num2str(10*log10(noise(n+1))) ' dB'])
    axis([0 numpts -4000 4000])
    %axis tight
    subplot(224)
    bar(xhist,distribution(n+1,:))
    title(['N=' num2str(N(n+1))])
    
    if n<Number_of_files_read-1
        figure(gcf+1)
    end 
end   

figure(gcf+1)
plot(log2(N(1:length(N)/2)),10*log10(noise((1:length(N)/2))),'o')
hold on
plot(log2(N(length(N)/2+1:length(N))),10*log10(noise((length(N)/2+1:length(N)))),'rx')
DIF=10*log10(noise((length(N)/2+1:length(N))))-10*log10(noise((1:length(N)/2)));
plot(log2(N(1:length(N)/2)),DIF,'gd')
ENR=20.8;%Measured 10/7/02
attenNGEN=0;%Any attenuation applied to the Noise Generator
NF=ENR-DIF;
aveNF=mean(NF);
%plot(log2(N(1:length(N)/2)),NF,'k*')
%Y Method
varTERM=noise((1:length(N)/2));
varNGEN=noise((length(N)/2+1:length(N)));
Y=varNGEN./varTERM;
NFY=ENR-attenNGEN-10*log10(Y-1);
aveNFY=mean(NFY);
plot(log2(N(1:length(N)/2)),NFY,'rs')
legend('50 Ohm Term','Noise SOurce','DIF','System Noise Figure')
grid on
%text(5,24,['Average Approx. NF=' num2str(  round(aveNF*10)/10  )])
text(5,20,['Average System Noise Figure=' num2str(  round(aveNFY*100)/100  )])
xlabel('Log2(N)')
ylabel('Noise calculated as variance (dB)')
title('System Noise Figure vs Integration at Maximum VGA Setting')
hold off

%Print all figures  ***************************************************************************
printallfigure=0;
if printallfigure==1
	for n=1:1:gcf
   	figure(n)
   	print
	end
end
