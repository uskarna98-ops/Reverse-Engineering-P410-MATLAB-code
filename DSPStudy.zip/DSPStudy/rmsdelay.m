function [rmsdelay,RMS_delay]=rmsdelay(wave, timeperpt)
% rmsdelay.m
% 
% operation:
%    finds rmsdelay of data in scan waveform,
%      based on timeperpt time between samples
%
% usage:
%    rms=rmsdelay(wave, timeperpt)
%
%    inputs:
%       wave         scan waveform
%       timeperpt    time per point in nS
%
%    outputs:
%       rms  Root Mean Square (RMS) group delay in nS
%

%
% last edited by:
%   David J. Hall
%   Time Domain Systems, Inc.
%   10 Aug 2000
%   16:42

wave=wave';
timematrix1=(1:length(wave))*timeperpt;

%Legacy Calculations by David Hall
   timematrix2=timematrix1.^2;
	t1=sum(timematrix1.*(wave(1:length(wave)).^2))/...
	      sum(wave.^2);
	t2=sum(timematrix2.*(wave(1:length(wave)).^2))/...
	      sum(wave.^2);
	
	RMS_delay=sqrt(t2-t1^2);


%Calculation on Waveform
			%Mean Excess Delay Spread
         pt=wave;
         tt=timematrix1;
         Pt=abs(pt).^2;
         tPt=tt.*Pt;
         meandelay=sum(tPt)./sum(Pt);
         mean_excess_delay=meandelay/1e-9;
                         
         %RMS Delay Spread
         %t2Pt=(t.^2).*Pt;
         t2Pt=(tt.^2).*Pt;
         t2 = sum(t2Pt)./sum(Pt);
         st=sqrt( t2 - meandelay.^2 );
         rmsdelay=st;
  
         
         
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%