function out=toppeaks(list,numpulses,spacing,pulseduration,tpp)
% toppeaks.m
% 
% operation:
%	This function will be given a matrix
%	and find the top "n" pulses in terms of peak-to-peak amplitude.
%	These pulses represent then the top "n" lock points.
%
%	The algorithm calculates the peak-to-peak amplitude over a span equal
%	to the peak-to-peak period of a perfect waveform. It then finds the largest
%	"numpulses" of these.
%
% usage:
%    toppeaks(list, numpulses, spacing, pulseduration,tpp)
%
%    inputs:
%       list = the input scan matrix
%       numpulses = the number of pulses to find/order
%		  spacing = spacing (usually 2 or more)
%		  pulseduration = pulse duration (pulseduration in ns)
%		  tpp = time per pt (timeperpt in ns)
%
%    outputs:
%       The output matrix has twice as many columns
%       as the input matrix. The columns are paired. The first column in
%       each pair represents the point number at which the peak occurred
%       and the second column represents the magnitude of that peak.
%
%	NB: The function has no mechanism for preventing one for asking for too many
%		peaks.

% based on: 
%	Paul Withington
%	Time Domain Corporation
%	February, 1999
%
% last edited by:
%   Scott Yano
%   Time Domain
%   14 Feb 2001
%   10:17

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
ndp=length(list(:,1));
ndf=length(list(1,:));
ptppts=round(pulseduration/(2*tpp));
ptsspacer=round(spacing*ptppts);
spacertime=ptsspacer*tpp;

peakpts=zeros(numpulses,ndf);  
peakmags=zeros(numpulses,ndf);  
out=zeros(numpulses,2*ndf);  
magvector=zeros(ptppts+1,1);  

magvector(1,1)=1;
%Including the -1 in the magvector adds an element that looks for the largest deviation from 
%		the positive peak to a negative peak.
magvector(ptppts+1,1)=0;%-1;   

tempmatrix0=zeros(ndp-ptppts,ndf);

for p=1:ndf
   if rem(p,10)==0
   %if p==10 | p==20 | p==30 | p==40 | p==50 | p==60 | p==70 | p==80 | p==ndf 
      p
   end  
	tempmatrix1=zeros(ndp-ptppts,2);
   % tempmatrix1 will contain the peak-to-peak values
	for m=1:ndp-ptppts;
		tempmatrix1(m,1)=m;
      tempmatrix1(m,2)=abs(dot(list(m:m+ptppts,p),magvector)); 
   end; 
   % The next loop iteratively finds the first numpulses largest peak-to-peak values.
   templength=length(tempmatrix1(:,1));
   for m=1:numpulses
		tempmatrix2=zeros(templength,2);
      [maxval, pointval]=max(tempmatrix1(:,2));
      spacertop=ptsspacer;
      spacerbottom=ptsspacer;
      if (pointval<(1+spacertop))  % if point is too close to beginning 
         spacertop=pointval-1;
      end;
      if (pointval > (templength-spacerbottom-1)) % if point is too close to end
         spacerbottom=templength-pointval-1;
      end;
		peakpts(m,p)=tempmatrix1(pointval,1);
		peakmags(m,p)=maxval;
		tempmatrix2(1:pointval-spacertop,:)=tempmatrix1(1:pointval-spacertop,:);
      tempmatrix2(pointval-spacertop:templength-spacertop-spacerbottom,:)=...
         tempmatrix1(pointval+spacerbottom:templength,:);
		tempmatrix1=tempmatrix2;
   end; %m
end; %p

% Now use actual values of peaks found, rather than peak-to-peak distances -djh

for m=1:numpulses
   for q=1:ndf
      peakmags(m,q)=list( peakpts(m,q),q);
   end; %q
end %m

for m=1:ndf
   out(:,2*m-1)=peakpts(:,m);
   out(:,2*m)=peakmags(:,m);
end; %m
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%