
function [g]=plot_chanstuff(RAKEplot,scatdisplay,ratiodisplay,rmsplot,rms2delay,meanexcessdelay,...
            excessdelay,filenum,rms,endthreshhold,cleanstop ,RAKEdB,PEAKSused,distancedata,...
            rakes,disttype,distfile,minpoint,maxxpoint,numpaths,peakpowerratio,yhattilderms)

    g=1;
 	fig=gcf;
 	if distfile==0;
      figure(rmsplot)
      hold on;
      plot(filenum,rms2delay,'r*');
      plot(filenum,meanexcessdelay,'gd');
      plot(filenum,excessdelay,'ks');
      hold off;
      legend('Scan calculated','Chan calculated','Mean Excess Delay','Excess Delay')
      axis([min(filenum) max(filenum) 0 max(10,ceil(max(rms)/10)*10+5)])
   	  grid on;
   elseif distfile==1
      figure(rmsplot)
      hold on;
      plot(distancedata,rms2delay,'r*');
      plot(distancedata,meanexcessdelay,'gd');
      plot(distancedata,excessdelay,'ks');
      hold off;
      legend('waveform rms','chan impulse rms','mean excess delay','excess delay')
      [m b]=linefit((distancedata),rms2delay);
      yhattilde= m.*(distancedata)+b  ;  % this is the un-logarithmic curve fit 
      [m b]=linefit((distancedata),meanexcessdelay);
      yhattildemean= m.*(distancedata)+b  ;  % this is the un-logarithmic curve fit 
      [m b]=linefit((distancedata),excessdelay);
      yhattildeexc= m.*(distancedata)+b  ;  % this is the un-logarithmic curve fit 
      hold on;
      plot(distancedata,yhattilderms,'b');
      plot(distancedata,yhattilde,'r');
      plot(distancedata,yhattildemean,'g');
      plot(distancedata,yhattildeexc,'k');
      hold off;
      grid on;
   	  axis([minpoint maxxpoint 0 max( max(10,ceil(max(excessdelay)/10)*10) , ceil(max(rms)/10)*10)])
      if cleanstop<=1
          ple=['RMS Delay Spread (threshold=' num2str(endthreshhold) '*noise, alpha=', num2str(cleanstop), ')_' date];     
      else
          ple=['RMS Delay Spread (threshold=' num2str(endthreshhold) '*noise, Thresh=', num2str(cleanstop), ' dB)_' date];     
      end
      title(ple)
   end  
   figure(fig)
 

 %Plot RAKE gain and number of peaks used
	if  RAKEplot==1;
      figure(gcf+1)
      plot(distancedata,RAKEdB,'b*')
      hold on;
      plot(distancedata,PEAKSused,'rs')
      [m b]=linefit((distancedata),RAKEdB);
      yhattilde= m.*(distancedata)+b  ;  % this is the un-logarithmic curve fit 
      hold on;
      plot(distancedata,yhattilde,'b');
      hold off;
      title(strcat('RAKE Gain Assuming (',num2str(rakes), ' Available Rakes)_', date));
   	  if disttype==1
        xlabel('Distance (feet)');
      elseif disttype==2
        xlabel('Distance (meters)');
      end 
      ylabel('RAKE Gain (dB),peaks used');
      legend('RAKE Gain','# Teeth Used')  
      grid on;
      axis([minpoint maxxpoint 0 max(10, ceil(max(max(RAKEdB),max(PEAKSused)))) ])
    end    
   
   
 %Plot the number of scatterers within a given threshold ****************************  
 if scatdisplay==1
 	if distfile==0;
      figure(gcf+1)
      plot(filenum,numpaths,'b*');
      axis([min(filenum) max(filenum) 0 max(10,ceil(max(numpaths)/5)*5+5)])
      grid on;
      if cleanstop<=1
          title(strcat('Number of Scaterers (alpha=',num2str(cleanstop), ')_', date));
   	  else
          title(strcat('Number of Scaterers (Thresh=',num2str(cleanstop), ' dB)_', date));
   	  end
      xlabel('Scan number');
   	  ylabel('Number of Scaterers');
   	  grid on;
   elseif distfile==1
      figure(gcf+1)
      plot(distancedata,numpaths,'b*');
      if cleanstop<=1
          title(strcat('Number of Scaterers (alpha=',num2str(cleanstop), ')_', date));
   	  else
          title(strcat('Number of Scaterers (Thresh=',num2str(cleanstop), ' dB)_', date));
      end
      if disttype==1
        xlabel('Distance (feet)');
      elseif disttype==2
        xlabel('Distance (meters)');
      end 
   	  ylabel('Number of Scaterers');
      [m b]=linefit((distancedata),numpaths );
      yhattilde= m.*(distancedata)+b  ;  % this is the un-logarithmic curve fit 
      hold on;
      plot(distancedata,yhattilde,'b');
      hold off;
      axis([minpoint maxxpoint 0 max(10,ceil(max(numpaths)/5)*5+5)])
      grid on;
    end  
end %if chanimpulse   

%Plot the peak power ratio ****************************  
 if ratiodisplay==1
 	if distfile==0;
      figure(gcf+1)
      plot(filenum,peakpowerratio,'b*');
      axis([min(filenum) max(filenum) 0 1])
      grid on;
      title('Ratio of peak impulse power to sum of all impulse powers');
   	  xlabel('Scan number');
   	  ylabel('ratio');
   	  grid on;
   elseif distfile==1
      figure(gcf+1)
      plot(distancedata,peakpowerratio,'b*');
      title('Ratio of peak impulse power to sum of all impulse powers');
   	  if disttype==1
        xlabel('Distance (feet)');
      elseif disttype==2
        xlabel('Distance (meters)');
      end 
   	  ylabel('ratio');
      [m b]=linefit((distancedata),peakpowerratio);
      yhattilde= m.*(distancedata)+b  ;  % this is the un-logarithmic curve fit 
      hold on;
      plot(distancedata,yhattilde,'b');
      hold off;
      axis([minpoint maxxpoint 0 1])
      grid on;
  end  
end 