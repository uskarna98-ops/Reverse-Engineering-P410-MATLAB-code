function newlist=expgate(list,x1,dx1,x2,dx2,varargin)
% expgate.m
% 
% operation:
%   used to gate or zero out data file for fft reasons
%
% usage:
%       newlist=EXPGATE(list,x1,dx1,x2,dx2,MDIM)
%
%    For best results, x1 & x2 should be set such that the
%    exponential falloff begins where the data is at/near zero.
%
%	  dx1<1
%	  dx2<1
%	  x1 points at the beginning of the list to smooth
%	  x2 points at the end of the list to smooth
%    MDIM is OPTIONAL - use if list is a matrix.
%    MDIM specifies the dimension over which the expgate 
%      should smooth.
%    MDIM=1 smooth over row, MDIM=2 smooth over column
%      For example:  
%       list=rand(100,5);
%       newlist=expgate(list,10,.95,15,.93,2)
%       This generates a matrix newlist in which each column 
%       is made up of each column of the matrix list after it
%       has been smoothed using the above start points & factors.
%       
%
%	  Smoothing of the form factor^pts from beginning or end
%

% based on: 
%	Rachel Reinhardt & Mark Barnes
%	Time Domain
%	February, 1999
%
% last edited by:
%   David J. Hall
%   Time Domain Systems, Inc.
%   24 July 2000
%   23:46



if nargin==5
   varargin=cellstr('0');
end
if size(list,1)==1 | varargin{1}==1
   x3=size(list,2)-x2;
   newlist=list.*(ones(size(list,1),1)*[dx1.^(x1:-1:1),ones(1,x3-x1-1),dx2.^(0:x2)]);
elseif size(list,2)==1 | varargin{1}==2
   x3=size(list,1)-x2;
   newlist=list.*([dx1.^(x1:-1:1),ones(1,x3-x1-1),dx2.^(0:x2)]'*ones(1,size(list,2)));
end
