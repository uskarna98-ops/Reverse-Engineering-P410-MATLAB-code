function [m,b]=linefit(x,y)
% linefit.m
% 
% operation: provides best fit   yhat(x)=m*x+b  
%
% Usage: 
%     [m b]=linefit(x, y)
%
%     inputs: 
%         x = x-coordinates of data points
%         y = y-coordinates of data points
%
%    outputs:
%         m = slope of fit line
%         b = y-intercept 
%
%   returns error if vectors x,y not same lengths

% last edited by:
%   David J. Hall
%   Time Domain Systems, Inc.
%   10 Aug 2000

if length(x)~=length(y) end;

n=length(y);
SumXY=sum(x.*y);
SumX=sum(x);
SumXsquared=sum(x.^2);
SumY=sum(y);

m=(n*SumXY-SumX*SumY)/(n*SumXsquared-SumX^2);
b=(SumY/n)-(m*SumX/n);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%