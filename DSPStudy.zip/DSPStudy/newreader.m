function [scanmatrix, lockmatrix, distancedata, timeperpt, nrdatapts]=...
   newreader(datadirectory, datafilename, nrdatafiles)
%  newreader.m
% 
%  Operation:
%  This file loads the data into the computer.
%  It should be the first of the MATLAB programs to be run.
%
%  Usage:
%    [scanmatrix, lockmatrix, distancedata, timeperpt, nrdatapts]=...
%       newreader(datadirectory, datafilename, nrdatafiles)
%
%    inputs:
%       datadirectory         directory that data is in
%       datafilename          filename used for files in that directory. 
%                e.g. if files are c:\data1.dat - data10.dat, 
%                this would be data
%       nrdatafiles           number of data files to read in the group.
%                e.g. in the above case, nrdatafiles=10
%    outputs:
%       scanmatrix           [nrdatapoints x nrdatafiles] dimensioned matrix containing the scan channel data
%       lockmatrix           [nrdatapoints x nrdatafiles] dimensioned matrix containing the lock channel data
%       distancedata         nrdatafiles dimensioned matrix containing the distances 
%                                 between the transmitter and receiver in feet.
%       BERmatrix            nrdatafiles dimensioned matrix containing the BER of each scan
%       SNRmatrix            [nrdatafiles x 3]      dimensioned matrix containing parameters PSNR, NSNR, and CSNR
%                                                         in columns 1, 2, and 3 respectively
%       timeperpt            time per point in nS
%       nrdatapts            number of data points per file
%       
%   dependencies:
%       masterlist.txt       list of parameters common to ALL data files
%       distance.txt         list of distances between receiver and transmitter in files in batch of data
%

% The data must be in the following format for proper loading:
%   Lines 1 to n: Comments on data set
%   Line n+1: Maximum number of samples in data set
%   Line n+2: Scan step (e.g., 18 where time between sample points would be
%             18 * 3.125 ps = 56.25 ps)
%   Line n+3: Lock point number
%	 Line 28: Attenuation of Receiver
%	 Line 30: Attenuation on Transmitter
%   Lines 32 to end of file: Data in two columns:
%        Column 1: Timer B (Scanning correlator) Sample value
%        Column 2: Timer A (Locked correlator) Sample value

% based on: 
%   Rachel Reinhardt and Paul Withington  
%   Time Domain
%   May 1999
%
% last edited by:
%   David J. Hall
%   Time Domain Systems, Inc.
%   10 Aug 2000
%   09:08
%

% ---- SHOULD THERE BE CALIBRATION PARAMETERS TO TRANSLATE AMPLITUDES INTO dBm or
%      OTHER STANDARD VALUES????
%	1)	Read in parameters, e.g., maximum length of data set
%		We need to know these values in order to:
%			A) Efficiently create the data matrices
%			B) Scale plots
%
%		NB: Assumes that all files have same parameters.
%
fid=fopen([datadirectory datafilename '1.dat']);
for k=1:21
	fgetl(fid);
end;


fseek(fid,1,0); timeperpt=0.001*fscanf(fid,'%g');
%
%	(2) Read in the number of data points. NB: Subtract 1 until Randall
%	fixes the problem with the first data point value always being
%	zero.
%
fgetl(fid);
fseek(fid,1,0); nrdatapts=fscanf(fid,'%g')-1;
fclose(fid);
nrdatapts
%
%	(3)	Create a vector with the time at each data point (in nanoseconds)
pointtime=timeperpt*(0:nrdatapts-1)';
%
%
%	(4)	Create three matrices to hold data.
% 		scandata: Temporarily contains the output of the scanning receiver **
%			It has two columns:
%				Column 1: scan measurement data
%				Column 2: noise measurement data
%		lockmatrix: Contains as columns the locked channel data
%		scanmatrix: Contains as columns the scanning channel data

%
scandata=[]; lockmatrix=[]; scanmatrix=[];
%
%	(5)
%     A) Read in the data files
%     B) Break data into two different matrices:
%			lockmatrix: Contains as columns the locked channel data
%			scanmatrix: Contains as columns the scanning channel
%
for n=1:nrdatafiles
   fid=fopen([datadirectory datafilename num2str(n) '.dat']);
	for k=1:27
			fgetl(fid);
	end; %k
   fseek(fid,1,0); 
   attn1=fscanf(fid,'%g')
	fgetl(fid);
   fseek(fid,1,0); 
   attn2=fscanf(fid,'%g')
   fgetl(fid);
   fgetl(fid); 
   for m=1:nrdatapts
      scandata(m,:)=fscanf(fid,'%6d %6d',[1,2]);
	end; %m
   fclose(fid);
   attenuation=10^((attn1+attn2)/20);
   scanmatrix(:,n)=attenuation.*scandata(:,1);
   lockmatrix(:,n)=attenuation.*scandata(:,2);
end; %n
clear scandata fid n k m attenuation;
%
%	Read the distance data
fid=fopen([datadirectory 'distance.txt']);
			fgetl(fid);			fgetl(fid);  % read in two null lines 
distancedata=fscanf(fid,'%f');
distancedata=distancedata';
fclose(fid);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%