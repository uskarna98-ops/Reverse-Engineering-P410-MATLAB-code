function [multipaths,timezero1,breaktime,CIRpeakV,CIRrmsV,RAKEdB,peaksused,rmsdelay,meandelay,excessdelay,...
      		peakratio,totalpower]=chan_stats(rakes,t,h,Ts)
	adj=0;
   toffset=t;
   breaktime=500;
   
   %Calculate Peak and RMS voltage (before normalize)
 	[CIRpeakV,CIRrmsV]=calc_rmsV(h);  
   
   hnorm=max(abs(h));
   h=h./hnorm; %normalize h
   
   %Find first impulse
   s=find( abs(h) > 0 );
   timezero=t(s(1));
   multipaths=length(s);      
      
                 
         %Make maxpeak time zero
         to=t; %Original time scale
         t=t-timezero;
         timezero1=timezero;
         timezero=0;

         Pt=(abs(h).^2)';%power
                  
         %Multiply total power by hnorm to undo normalization to itself
         peakratio=max(h.^2)./sum(h.^2);
         totalpower=sum( (h.*hnorm).^2 );
         
         %Excess Delay Spread
         excessdelay=t(s(length(s))-timezero);
         %excessdelay
         
         %Mean Excess Delay Spread
         %Pt is a power
         tPt=t.*Pt;
         meandelay=sum(tPt)./sum(Pt);                 
         %meandelay
         
         %RMS Delay Spread
         %t2Pt=(t.^2).*Pt;
         t2Pt=(t.^2).*Pt;
         t2 = sum(t2Pt)./sum(Pt);
         rmsdelay=sqrt( t2 - meandelay.^2 );
         %rmsdelay
   
    %Calculate RAKE Gain assuming x rakes, 3 dB noise increase for each tooth
         rakepeak=[];
         RAKEdB=0;
         peaksused=1;
         pt1=h;
         pt1=pt1/max(abs(pt1));%Normalize to biggest peak in PDP
         [maxpath,ww]=max(abs(pt1));%Find biggest peak
         rakepeak(1)=maxpath(1);
         pt1(ww(1))=0;%Zero biggest peak
         for jj=2:rakes
            RAKEdBold=RAKEdB;
            [maxpath,ww]=max(abs(pt1));%Find biggest remaining peak
            rakepeak(jj)=maxpath(1);
            pt1(ww(1))=0;%Zero biggest peak
            raketot=sum(rakepeak);
         	RAKEdB=20*log10(raketot)-20*log10(sqrt(jj));
            if RAKEdBold>RAKEdB
               RAKEdB=RAKEdBold;
               break
            end
            peaksused=jj;
         end
    
    
 
