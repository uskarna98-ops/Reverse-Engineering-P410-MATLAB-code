function [los,stud,pol,genloc,walls,datavalid]=p300read(nrdatafiles,datadirectory,setrange,nrdatast,nrdatasp);

for bb=1:nrdatafiles
      
      %LOS 
      FID=fopen([datadirectory 'los.txt']);
      if FID>0
         los = fscanf(FID, '%s');
         if setrange==1
            los=[los(1:2) los(nrdatast:nrdatasp)];
         end   
         fclose (FID);
      else
         los(bb)='-';
      end
      
      %# of walls penetrated 
      FID=fopen([datadirectory 'walls.txt']);
      if FID>0
         walls = fscanf(FID, '%s');
         if setrange==1
            walls=[walls(1:2) walls(nrdatast:nrdatasp)];
         end   
         fclose (FID);
      else
         walls(bb)='-';
      end
            
      %Stud 
      FID=fopen([datadirectory 'stud.txt']);
      if FID>0
         stud = fscanf(FID, '%s');
         if setrange==1
            stud=[stud(1:2) stud(nrdatast:nrdatasp)];
         end   
         fclose (FID);
      else
         stud(bb)='-';
      end
      
      
      %Polarization 
      FID=fopen([datadirectory 'pol.txt']);
      if FID>0
         pol= fscanf(FID, '%s');
         if setrange==1
            pol=[pol(1:2) pol(nrdatast:nrdatasp)];
         end   
         fclose (FID);
      else
         pol(bb)='-';
      end
      
      
      %General Location 
      FID=fopen([datadirectory 'genloc.txt']);
      if FID>0
         genloc= fscanf(FID, '%s');
         if setrange==1
            genloc=[genloc(1:2) genloc(nrdatast:nrdatasp)];
         end   
         fclose (FID);
      else
         genloc(bb)='-';
      end
      
      %Data Valid 
      FID=fopen([datadirectory 'datavalid.txt']);
      if FID>0
         datavalid= fscanf(FID, '%s');
         if setrange==1
            datavalid=[datavalid(1:2) datavalid(nrdatast:nrdatasp)];
         end   
         fclose (FID);
      else
         datavalid(bb)='-';
      end
      
  	end 