function [scanfig]=plot_scans(scandisp,nrdatafiles,envelopeshow,LE,LE2,LE3,LEAoA,LE_2,...
        LE_2truth,LEDon,AoAon,normscans,filteredscanmatrix,scanmatrix,pointtime,tstart,tstop,...
        filenum,showunfiltered,startlevel,envel)
    
if scandisp==0
	numframes=nrdatafiles;%ceil(nrdatafiles/3);
elseif scandisp==1
    numframes=nrdatafiles;
end    
    figure(gcf+1);
    scanfig=gcf;
    counter=0;
	for k=1:numframes
   	  counter=counter+1; 
      if scandisp==0
          if rem(counter,3)==1
             subplot(3,1,1)
          elseif rem(counter,3)==2  
      	     subplot(3,1,2)
          elseif rem(counter,3)==0  
      	     subplot(3,1,3)
          end
      elseif scandisp==1
          if envelopeshow==1
            subplot(311)
          else
            subplot(211)
          end  
      end  
      grid on;
            
        
     if LEDon==1
         plot([LE(counter) LE(counter)],[-1e5 1e5],'LineWidth',2,'color','k')
         hold on;
         plot([LE2(counter) LE2(counter)],[-1e5 1e5],':','LineWidth',2,'color','r')
         plot([LE3(counter) LE3(counter)],[-1e5 1e5],'--','LineWidth',2,'color',[.5 .5 .5])
         grid off;
         legend('LED0','LED2','LED3')
         if AoAon==1
            hold off;
            plot([LEAoA(counter) LEAoA(counter)],[-1e5 1e5],'LineWidth',2,'color','r')
            hold on;
            plot([LE_2(counter) LE_2(counter)],[-1e5 1e5],'LineWidth',2,'color','r')
            plot([LE_2truth(counter) LE_2truth(counter)],[-1e5 1e5],'--','LineWidth',2,'color','k')
            %legend('LED0','LED2','LED3','LE_2','LE_2t')
            %text(tstart+1,.5,['PAR= ' num2str(PAR(counter))] );
            hold off;
         end
      end   
      
      if normscans==1
          filteredplot=filteredscanmatrix(:,counter)./max(abs(filteredscanmatrix(:,counter)));
          unfilteredplot=scanmatrix(:,counter)./max(abs(scanmatrix(:,counter)));
          ylim=1;
      else
          filteredplot=filteredscanmatrix(:,counter);
          unfilteredplot=scanmatrix(:,counter);
          ylim=max(max(abs(filteredscanmatrix(:,counter))))+.1*max(max(abs(filteredscanmatrix(:,counter))));
      end
      
      if showunfiltered==1
         plot(pointtime,unfilteredplot,'r-')%unfiltered
         hold on;
      end
      plot(pointtime,filteredplot,'b-')%filtered
      axis([tstart tstop -ylim ylim]); 
      if showunfiltered==1
        legend('Un-Filtered','Filtered')   
        hold off      
      end
      %peakpt=round((tpeakpts(1:correlators,counter)*timeperpt+maxlobe_time(counter))/timeperpt);
      %hold on;
      %plot(tpeakpts(1:correlators,counter)*timeperpt+maxlobe_time(counter),filteredscanmatrix(peakpt,counter),'rx'  );      
      %hold off;
	  title(strcat('Filtered Scan Channel Data (Scan # ',num2str(filenum(counter)), ')'));
      ylabel('Amplitude');        
        
      
      
      if  scandisp==0 & rem(counter,3)==0
          xlabel('Time (nS)');
          figure(gcf+1)
      elseif scandisp==1
          figure(gcf+1)
      end    
  end; %for k
       
  if scandisp==1
      figure(gcf-1)
  elseif scandisp==0 & rem(counter,3)==0
      figure(gcf-1)
  end    
            

%Plot Envelope ***************************************************************   
   if envelopeshow==1 & scandisp==1
		counter=0;
		for k=1:nrdatafiles
   		figure(scanfig+counter)
            subplot(312)
            counter=counter+1;
            if (counter <= nrdatafiles)
              	if normscans==1
                    envplot=envel(counter,:)./max(abs(envel(counter,:)));
                    strlvplot=startlevel(counter,:)./max(abs(envel(counter,:)));
                    ylim=1;
                else
                    envplot=envel(counter,:);
                    strlvplot=startlevel(counter,:);
                    ylim=max(max((10*ceil(envel(counter,:)/10))));
                end    
                plot(pointtime,envplot)
            	hold on;
            	plot(pointtime,strlvplot,'r')
            	hold off;
            	axis([tstart tstop 0 ylim]);
   				ylabel('Amplitude')
            	title(strcat('Envelope (Scan # ',num2str(filenum(counter)), ')'));
         	end      
		end; %k
	end %envelope
 
  

      
      

