clear
close all

%Values for older versions of STDAN without these parameters
endthreshhold=0;
threshdB=20;
offdB=0;
rakes=4;
disttype=1;%force to feet
pointer=1;
corr1=1;
corr2=2;
corr3=4;
correlators=corr1;

Kmon			 =  0   ;
calc_N90     =  0   ;
calc_Km90    =  0   ;
logon 		 =  1   ;
percent_less = 89 ;

maindirectory=['q:\propagation\data\'];

disp('>> Enter the number of datasets to read:');
nrdatasets=input('');

distancedata_tot=[];
powersum_tot=[];
relpower_tot=[]; 
distancedata_mult=[];
powersum_mult=[];
rms_tot=[];
rms2delay_tot=[];
numpaths_tot=[];
peakratio_tot=[];
totpower_tot=[];
threshdB_tot=[];
endthreshhold_tot=[];

totpower_tot=[];
peakpower_tot=[];
meanexcessdelay_tot=[];
excessdelay_tot=[];
RAKEdB_tot=[];
PEAKSused_tot=[];
Numpeaks_tot=[]; 
PNratio_tot=[];

for m=1:nrdatasets

	disp('>> Enter the name of the folder where the data is stored.');
   datadirectory=input('    (if the data is in "c:\\analysis\\data\\", type "data\\" ) \n','s');

   
   datadirectory=[maindirectory datadirectory];
	direct=pwd;
	%disp('>> Enter the name of the directory where the data is stored.');
	%datadirectory=input('    (for example, "c:\\analysis\\data\\" ) \n','s');

	%disp('>> Enter the base name of the data files.');
	%datafilename=input('    (for example, files scan1.dat thru scan8.dat, entry is "scan" ).\n','s');


	cd(datadirectory)
	load outputfile chanimpulse
	if chanimpulse==1
      load  outputfile hRX hTX distancedata tpeakval relpower freeref difpow rms rms2delay numpaths chanimpulse threshdB pointer disttype offdB endthreshhold peakpowerratio totpower peakpower meanexcessdelay excessdelay RAKEdB PEAKSused Numpeaks PNratio    
   else
   	load outputfile distancedata tpeakval rms chanimpulse pointer disttype offdB endthreshhold
	end
	cd c:\source
	nrdatafiles=length(distancedata);

	%Change all distances to feet
   if disttype==2
      distancedata=distancedata*3.28;%change meters to feet
      disttype=1;
   end   

%Find energy using peak points with corr1 number of correlators
   powersum=zeros(1,nrdatafiles);
   powersum1=powersum;
   	for l=1:corr1
      	powersum1=powersum1+tpeakval(l,:).^2;
      end;
        
   %Reference to 1st scan, not Absolute power in dBm
   	%Subtract 1 dB from reference
   	refnorm=powersum1(1);
      refd=distancedata(1);
      powersum1=powersum1/refnorm;
	

	distancedata_tot=[distancedata_tot distancedata]; 
   powersum_tot=[powersum_tot powersum1];
   relpower_tot=[relpower_tot relpower];
   distancedata_mult=[distancedata_mult distancedata(pointer)];
	powersum_mult=[powersum_mult powersum1(pointer)];
	rms_tot=[rms_tot rms]; 
   threshdB_tot=[threshdB_tot threshdB];
   endthreshhold_tot=[endthreshhold_tot endthreshhold];
	if chanimpulse==1
		rms2delay_tot=[rms2delay_tot rms2delay];
   	numpaths_tot=[numpaths_tot numpaths];
      totpower_tot=[totpower_tot totpower];
   	peakpower_tot=[peakpower_tot peakpower];
   	meanexcessdelay_tot=[meanexcessdelay_tot meanexcessdelay];
   	excessdelay_tot=[excessdelay_tot excessdelay];
   	RAKEdB_tot=[RAKEdB_tot RAKEdB];
   	PEAKSused_tot=[PEAKSused_tot PEAKSused];
   	Numpeaks_tot=[Numpeaks_tot Numpeaks]; 
   	PNratio_tot=[PNratio_tot PNratio];
   end

end %end for m --------------------------------------------------------------

%Change names of combined data back to notation used by remainder of program
	distancedata=distancedata_tot; 
   powersum1=powersum_tot;
   relpower=relpower_tot;
   %distancedata_mult=distancedata_mult;
	%powersum_mult=powersum_mult;
	rms=rms_tot; 
   threshdB=sum(threshdB_tot)/nrdatasets;
   endthreshhold=sum(endthreshhold_tot)/nrdatasets;
	if chanimpulse==1
		rms2delay=rms2delay_tot;
      numpaths=numpaths_tot;
      totpower=totpower_tot;
   	peakpower=peakpower_tot;
   	meanexcessdelay=meanexcessdelay_tot;
   	excessdelay=excessdelay_tot;
   	RAKEdB=RAKEdB_tot;
   	PEAKSused=PEAKSused_tot;
   	Numpeaks=Numpeaks_tot; 
   	PNratio=PNratio_tot;
	end

%Force PathlossData to be less than 0 dB ---------------------------------------------
for bb=1:length(powersum1)
   if powersum1(bb)>1
      powersum1(bb)=1;
   end;
   if relpower(bb)>0
      relpower(bb)=0;
   end;
   if totpower(bb)>1
      totpower(bb)=1;
   end;
   if peakpower(bb)>1
      peakpower(bb)=1;
   end;
end   

%Calculate Curve Fits on combined datasets ------------------------------------------
  	freeref=-20*log10(distancedata/min(distancedata));
   relpower=(20*log10(sqrt(powersum1)));
   difpow=-(freeref-relpower);
   
%Set for axes   
	if max(distancedata)<=100
   	maxxpoint=ceil(max(distancedata)/100)*100;
	else
  		maxxpoint=ceil(max(distancedata)/100)*100;
	end    
	if min(distancedata)>=10
   	minpoint=10;
	else
      if logon==1
         minpoint=1;
      else
         minpoint=0;;
      end   
   end
   
   if logon==1
   	distancedatalog=log10(distancedata);
	else
   	distancedatalog=(distancedata);
	end   
   

%Pathloss -------------------------------------------------------------------------      
%relpower(3:length(relpower))=relpower(3:length(relpower))-1;	
%Curvefit Powersum1
[distdat1,N,K,ya,y,y90N,y90K,M_N,stdev_N,M_K,stdev_K,percent]=curvefit(distancedata,relpower,percent_less);
	M_N
	stdev_N
   	
   
	figure(gcf);
  %Plot Reference Lines
	   r2=-20*log10(distdat1/min(distdat1));semilogx(distdat1,r2,'linewidth',2,'color','r') 
      hold on;
      %r3=-30*log10(distdat1/min(distdat1));semilogx(distdat1,r3,'g-s')     
      
  %Plot 1/d^N curve fit
      semilogx((distdat1),(ya),'linewidth',2,'color','b')
      if calc_N90==1
      	semilogx(distdat1,(y90N),'linewidth',2,'color',[0 .8 1])
      end
      
  %Plot exp(-Kd)/d^2 curve fit
  		if Kmon==1
     		semilogx(distdat1,(y),'linewidth',2,'color','m')
      end     
      if calc_Km90==1 &Kmon==1
      	semilogx(distdat1,(y90K),'linewidth',2,'color',[1 .5 .7])
      end
      
  %Plot the actual data points         
     semilogx((distancedata),relpower,'k*');
  %Plot the multipath peak data points         
     %plot(distancedata_mult,20*log10(sqrt(powersum_mult)),'g*');    
     
  %Re-Plot Lines to overlay points ------------------------
      semilogx(distdat1,r2,'linewidth',2,'color','r') 
      hold on;
      semilogx((distdat1),(ya),'linewidth',2,'color','b')
      if Kmon==1
      	semilogx(distdat1,(y),'linewidth',2,'color','m')
      end   
      if calc_N90==1
         semilogx(distdat1,(y90N),'linewidth',2,'color',[0 .8 1])
      elseif calc_Km90==1 & Kmon==1  
         semilogx(distdat1,(y90K),'linewidth',2,'color',[1 .5 .7])
      end   
        
  %Set Axes, Notes    
  		%ple1=[('n=') num2str(n)];
      ple1a=[('N=') num2str(N)];  
      if disttype==1
         %ple2=[('K_f =') num2str(K)];
         Km=3.28*K;
         Km=round(Km*100)/100;
         Lw=-10*log10(exp(-Km)); 
         Lw=round(Lw*100)/100;
         ple2=[('Km=') num2str(Km) ', Lw=' num2str(Lw)];
      elseif disttype==2
         Km=K;
         Km=round(Km*100)/100;
         Lw=-10*log10(exp(-Km));   
        	ple2=[('Km=') num2str(Km) ', Lw=' num2str(Lw)];
     	end 
      
      if calc_Km90==1
         plePER=[num2str(round(percent*10)/10) '% Rel to Km'];
         pleMAR=['Margin = ', num2str( round(M_K*10)/10 ) ' dB'];
      elseif calc_N90==1   
         plePER=[num2str(round(percent*10)/10) '% Rel to N'];
         pleMAR=['Margin = ', num2str( round(M_N*10)/10 ) ' dB'];
      else
         plePER=[];
         pleMAR=['Margin = ', num2str( round(M_N*10)/10 ) ' dB'];
      end
      
      if calc_N90==1
         if Kmon==1
         	legend('Free Space',ple1a,plePER,ple2,'data')%legend('Free Space',ple1a,ple2,'90% Rel','data','multipath peaks',pleoffdB)
         else
            legend('Free Space',ple1a,plePER,'data')
         end   
      else   
         legend('Free Space',ple1a,'data',3)%legend('Free Space',ple1a,ple2,'90% Rel','data','multipath peaks',pleoffdB)
      end   
      pleoffdB=['offdB = ', num2str(offdB)];
      %text(8,-1.5,pleoffdB)
      pleSTD=['\sigma_N = ' num2str(round(stdev_N*100)/100) ' dB'];
      text(20,-5.3,pleSTD,'fontsize',12,'color','b')
      %text(20,-7.5,pleMAR,'fontsize',12,'color','b')
      smaller=min(-30*log10([max(distancedata)/min(distancedata)]),20*log10(sqrt(powersum1))-6);
      miny=(ceil(min(smaller+0)/3)*3-3);
      axis([minpoint maxxpoint miny 3]); %axis([0 3.0 -100 -20]);
      vecor=[];
      for gt=miny:3:3
         vecor=[vecor gt];
      end 
      set(gca,'yTick',vecor)
      grid on;
		if disttype==1
        xlabel('Distance (feet)','fontsize',12);
     elseif disttype==2
        xlabel('Distance (meters)','fontsize',12);
     end 
		ylabel('PEAK Power PL (dB)','fontsize',12);
		ple=[('Calculated from ') num2str(length(distancedata)) ' scans (calculated assuming ',num2str(corr1), ' peak)  '  date];
   	%title(ple);
      hold off;
%----------------------------------------------------------------------------------      

%PEAK Power from CIR -------------------------------------------------------------------------      

if 1==0
%Curvefit
[distdat1,N,K,ya,y,y90N,y90K,M_N,stdev_N,M_K,stdev_K,percent]=curvefit(distancedata,10*log10(peakpower),percent_less);

	figure(gcf+1);
  %Plot Reference Lines
	   r2=-20*log10(distdat1/min(distdat1));semilogx(distdat1,r2,'linewidth',2,'color','r') 
      hold on;
      %r3=-30*log10(distdat1/min(distdat1));semilogx(distdat1,r3,'g-s')     
      
  %Plot 1/d^N curve fit
      semilogx((distdat1),(ya),'linewidth',2,'color','b')
      if calc_N90==1
      	semilogx(distdat1,(y90N),'linewidth',2,'color',[0 .8 1])
      end
      
  %Plot exp(-Kd)/d^2 curve fit
  		if Kmon==1
     		semilogx(distdat1,(y),'linewidth',2,'color','m')
      end
      if calc_Km90==1
      	semilogx(distdat1,(y90K),'linewidth',2,'color',[1 .5 .7])
      end
      
  %Plot the actual data points         
     semilogx((distancedata),10*log10(peakpower),'m*');
  %Plot the multipath peak data points         
     %semilogx(distancedata_mult,20*log10(sqrt(powersum_mult)),'g*');    
     
  %Re-Plot Lines to overlay points ------------------------
      semilogx(distdat1,r2,'linewidth',2,'color','r') 
      hold on;
      semilogx((distdat1),(ya),'linewidth',2,'color','b')
      if Kmon==1
         semilogx(distdat1,(y),'linewidth',2,'color','m')
      end
      if calc_N90==1
         semilogx(distdat1,(y90N),'linewidth',2,'color',[0 .8 1])
      elseif calc_Km90==1   
         semilogx(distdat1,(y90K),'linewidth',2,'color',[1 .5 .7])
      end   
        
  %Set Axes, Notes    
  		%ple1=[('n=') num2str(n)];
      ple1a=[('N=') num2str(N)];  
      if disttype==1
         %ple2=[('K_f =') num2str(K)];
         Km=3.28*K;
         Km=round(Km*100)/100;
         Lw=-10*log10(exp(-Km)); 
         Lw=round(Lw*100)/100;
         ple2=[('Km=') num2str(Km) ', Lw=' num2str(Lw)];
      elseif disttype==2
         Km=K;
         Km=round(Km*100)/100;
         Lw=-10*log10(exp(-Km));   
        	ple2=[('Km=') num2str(Km) ', Lw=' num2str(Lw)];
     	end 
      
      if calc_Km90==1
         plePER=[num2str(round(percent*10)/10) '% Rel to Km'];
         pleMAR=['Margin = ', num2str( round(M_K*10)/10 ) ' dB'];
      elseif calc_N90==1   
         plePER=[num2str(round(percent*10)/10) '% Rel to N'];
         pleMAR=['Margin = ', num2str( round(M_N*10)/10 ) ' dB'];
      else
         plePER=[];
         pleMAR=['Margin = ', num2str( round(M_N*10)/10 ) ' dB'];
      end
      
      if calc_N90==1
         if Kmon==1
         	legend('Free Space',ple1a,plePER,ple2,'data')%legend('Free Space',ple1a,ple2,'90% Rel','data','multipath peaks',pleoffdB)
         else
            legend('Free Space',ple1a,plePER,'data')
         end 
      else   
         legend('Free Space',ple1a,'data',3)%legend('Free Space',ple1a,ple2,'90% Rel','data','multipath peaks',pleoffdB)
      end   
      pleoffdB=['offdB = ', num2str(offdB)];
      text(8,-1.5,pleoffdB)
      pleSTD=['Stdev = ' num2str(stdev_N)];
      text(20,-5.3,pleSTD,'fontsize',12,'color','b')
      text(20,-7.5,pleMAR,'fontsize',12,'color','b')
      smaller=min(-30*log10([max(distancedata)/min(distancedata)]),20*log10(sqrt(powersum1))-6);
      miny=(ceil(min(smaller+0)/3)*3-3);
      axis([minpoint maxxpoint miny 3]); %axis([0 3.0 -100 -20]);
      vecor=[];
      for gt=miny:3:3
         vecor=[vecor gt];
      end 
      set(gca,'yTick',vecor)
      grid on;
		if disttype==1
        xlabel('Distance (feet)','fontsize',12);
     elseif disttype==2
        xlabel('Distance (meters)','fontsize',12);
     end 
		ylabel('Peak Power Received from CIR (dB)','fontsize',12);
		ple=[('Calculated from ') num2str(length(distancedata)) ' scans (calculated assuming ',num2str(corr1), ' peak)  '  date];
   	title(ple);
      hold off;
%----------------------------------------------------------------------------------      
end     
     
%PathLoss + RAKEGAIN -------------------------------------------------------------------------      
	
%Curvefit Powersum1
[distdat1,N,K,ya,y,y90N,y90K,M_N,stdev_N,M_K,stdev_K,percent]=curvefit(distancedata,relpower+RAKEdB,percent_less);
   
	figure(gcf+1);
  %Plot Reference Lines
	   r2=-20*log10(distdat1/min(distdat1));semilogx(distdat1,r2,'linewidth',2,'color','r') 
      hold on;
      %r3=-30*log10(distdat1/min(distdat1));semilogx(distdat1,r3,'g-s')     
      
  %Plot 1/d^N curve fit
      semilogx((distdat1),(ya),'linewidth',2,'color','b')
      if calc_N90==1
      	semilogx(distdat1,(y90N),'linewidth',2,'color',[0 .8 1])
      end
      
  %Plot exp(-Kd)/d^2 curve fit
  		if Kmon==1
     		semilogx(distdat1,(y),'linewidth',2,'color','m')
      end
      if calc_Km90==1
      	semilogx(distdat1,(y90K),'linewidth',2,'color',[1 .5 .7])
      end
      
  %Plot the actual data points         
     semilogx((distancedata),relpower+RAKEdB,'k*');
  %Plot the multipath peak data points         
     %semilogx(distancedata_mult,20*log10(sqrt(powersum_mult)),'g*');    
     
  %Re-Plot Lines to overlay points ------------------------
      semilogx(distdat1,r2,'linewidth',2,'color','r') 
      hold on;
      semilogx((distdat1),(ya),'linewidth',2,'color','b')
      if Kmon==1
         semilogx(distdat1,(y),'linewidth',2,'color','m')
      end
      if calc_N90==1
         semilogx(distdat1,(y90N),'linewidth',2,'color',[0 .8 1])
      elseif calc_Km90==1   
         semilogx(distdat1,(y90K),'linewidth',2,'color',[1 .5 .7])
      end   
        
  %Set Axes, Notes    
  		%ple1=[('n=') num2str(n)];
      ple1a=[('N=') num2str(N)];  
      if disttype==1
         %ple2=[('K_f =') num2str(K)];
         Km=3.28*K;
         Km=round(Km*100)/100;
         Lw=-10*log10(exp(-Km)); 
         Lw=round(Lw*100)/100;
         ple2=[('Km=') num2str(Km) ', Lw=' num2str(Lw)];
      elseif disttype==2
         Km=K;
         Km=round(Km*100)/100;
         Lw=-10*log10(exp(-Km));   
        	ple2=[('Km=') num2str(Km) ', Lw=' num2str(Lw)];
     	end 
      
      if calc_Km90==1
         plePER=[num2str(round(percent*10)/10) '% Rel to Km'];
         pleMAR=['Margin = ', num2str( round(M_K*10)/10 ) ' dB'];
      elseif calc_N90==1   
         plePER=[num2str(round(percent*10)/10) '% Rel to N'];
         pleMAR=['Margin = ', num2str( round(M_N*10)/10 ) ' dB'];
      else
         plePER=[];
         pleMAR=['Margin = ', num2str( round(M_N*10)/10 ) ' dB'];
      end
      
      if calc_N90==1
         if Kmon==1
         	legend('Free Space',ple1a,plePER,ple2,'data')%legend('Free Space',ple1a,ple2,'90% Rel','data','multipath peaks',pleoffdB)
         else
            legend('Free Space',ple1a,plePER,'data')
         end 
      else   
         legend('Free Space',ple1a,'data',3)%legend('Free Space',ple1a,ple2,'90% Rel','data','multipath peaks',pleoffdB)
      end   
      pleoffdB=['offdB = ', num2str(offdB)];
      %text(8,-1.5,pleoffdB)
      pleSTD=['\sigma_N = ' num2str(round(stdev_N*100)/100) ' dB'];
      text(20,-5.3,pleSTD,'fontsize',12,'color','b')
      %text(20,-7.5,pleMAR,'fontsize',12,'color','b')
      smaller=min(-30*log10([max(distancedata)/min(distancedata)]),20*log10(sqrt(powersum1))-6);
      miny=(ceil(min(smaller+0)/3)*3-3);
      axis([minpoint maxxpoint miny 3]); %axis([0 3.0 -100 -20]);
      vecor=[];
      for gt=miny:3:3
         vecor=[vecor gt];
      end 
      set(gca,'yTick',vecor)
      grid on;
		if disttype==1
        xlabel('Distance (feet)','fontsize',12);
     elseif disttype==2
        xlabel('Distance (meters)','fontsize',12);
     end 
		ylabel('PEAK Power Plus RAKE Gain PL (dB)','fontsize',12);
		ple=[('Calculated from ') num2str(length(distancedata)) ' scans (calculated assuming ',num2str(corr1), ' peak)  '  date];
   	%title(ple);
      hold off;
%----------------------------------------------------------------------------------      

%Total power -------------------------------------------------------------------------      
	
%Curvefit Powersum1
[distdat1,N,K,ya,y,y90N,y90K,M_N,stdev_N,M_K,stdev_K,percent]=curvefit(distancedata,10*log10(totpower),percent_less);
   
	figure(gcf+1);
  %Plot Reference Lines
	   r2=-20*log10(distdat1/min(distdat1));semilogx(distdat1,r2,'linewidth',2,'color','r') 
      hold on;
      %r3=-30*log10(distdat1/min(distdat1));semilogx(distdat1,r3,'g-s')     
      
  %Plot 1/d^N curve fit
  		semilogx((distdat1),(ya),'linewidth',2,'color','b')
      if calc_N90==1
      	semilogx(distdat1,(y90N),'linewidth',2,'color',[0 .8 1])
      end
      
  %Plot exp(-Kd)/d^2 curve fit
  		if Kmon==1
     		semilogx(distdat1,(y),'linewidth',2,'color','m')
      end     
      if calc_Km90==1
      	semilogx(distdat1,(y90K),'linewidth',2,'color',[1 .5 .7])
      end
      
  %Plot the actual data points         
     semilogx((distancedata),10*log10(totpower),'k*');
  %Plot the multipath peak data points         
     %semilogx(distancedata_mult,20*log10(sqrt(powersum_mult)),'g*');    
     
  %Re-Plot Lines to overlay points ------------------------
      semilogx(distdat1,r2,'linewidth',2,'color','r') 
      hold on;
      semilogx((distdat1),(ya),'linewidth',2,'color','b')
      if Kmon==1
         semilogx(distdat1,(y),'linewidth',2,'color','m')
      end   
      if calc_N90==1
         semilogx(distdat1,(y90N),'linewidth',2,'color',[0 .8 1])
      elseif calc_Km90==1   
         semilogx(distdat1,(y90K),'linewidth',2,'color',[1 .5 .7])
      end   
        
  %Set Axes, Notes    
  		%ple1=[('n=') num2str(n)];
      ple1a=[('N=') num2str(N)];  
      if disttype==1
         %ple2=[('K_f =') num2str(K)];
         Km=3.28*K;
         Km=round(Km*100)/100;
         Lw=-10*log10(exp(-Km)); 
         Lw=round(Lw*100)/100;
         ple2=[('Km=') num2str(Km) ', Lw=' num2str(Lw)];
      elseif disttype==2
         Km=K;
         Km=round(Km*100)/100;
         Lw=-10*log10(exp(-Km));   
        	ple2=[('Km=') num2str(Km) ', Lw=' num2str(Lw)];
     	end 
      
      if calc_Km90==1
         plePER=[num2str(round(percent*10)/10) '% Rel to Km'];
         pleMAR=['Margin = ', num2str( round(M_K*10)/10 ) ' dB'];
      elseif calc_N90==1   
         plePER=[num2str(round(percent*10)/10) '% Rel to N'];
         pleMAR=['Margin = ', num2str( round(M_N*10)/10 ) ' dB'];
      else
         plePER=[];
         pleMAR=['Margin = ', num2str( round(M_N*10)/10 ) ' dB'];
      end
      
      if calc_N90==1
         if Kmon==1
         	legend('Free Space',ple1a,plePER,ple2,'data')%legend('Free Space',ple1a,ple2,'90% Rel','data','multipath peaks',pleoffdB)
         else
            legend('Free Space',ple1a,plePER,'data')
         end 
      else   
         legend('Free Space',ple1a,'data',3)%legend('Free Space',ple1a,ple2,'90% Rel','data','multipath peaks',pleoffdB)
      end   
      pleoffdB=['offdB = ', num2str(offdB)];
      %text(8,-1.5,pleoffdB)
      pleSTD=['\sigma_N = ' num2str(round(stdev_N*100)/100) ' dB'];
      text(20,-5.3,pleSTD,'fontsize',12,'color','b')
      %text(20,-7.5,pleMAR,'fontsize',12,'color','b')
      smaller=min(-30*log10([max(distancedata)/min(distancedata)]),20*log10(sqrt(powersum1))-6);
      miny=(ceil(min(smaller+0)/3)*3-3);
      axis([minpoint maxxpoint miny 3]); %axis([0 3.0 -100 -20]);
      vecor=[];
      for gt=miny:3:3
         vecor=[vecor gt];
      end 
      set(gca,'yTick',vecor)
      grid on;
		if disttype==1
        xlabel('Distance (feet)','fontsize',12);
     elseif disttype==2
        xlabel('Distance (meters)','fontsize',12);
     end 
		ylabel('TOTAL Power PL (dB)','fontsize',12);
		ple=[('Calculated from ') num2str(length(distancedata)) ' scans (calculated assuming ',num2str(corr1), ' peak)  '  date];
   	%title(ple);
      hold off;
%----------------------------------------------------------------------------------      



      
% RMS delay spread --------------------------------------------------------------------------
      %figure(gcf+1)
      %rmsplot=gcf;
      %semilogx
      %semilogx(distancedata,rms,'*','color',[.3 .7 .1]);
   	%ple=['RMS Delay Spread (threshold=' num2str(endthreshhold) '*noise)'];
   	%title(ple);
   	%if disttype==1
      %  xlabel('Distance (feet)');
     	%elseif disttype==2
      %  xlabel('Distance (meters)');
     	%end 
   	%ylabel('RMS Delay (ns)');
      %hold on;
      %[m b]=linefit((distancedata),rms);
      %yhattilderms= m.*(distancedata)+b  ;  % this is the un-logarithmic curve fit 
      %hold on;
      %%Move curve fit to after rmsdelay2 so that legend makes sense
      %if chanimpulse==0
      %   semilogx(distancedata,yhattilderms,'r');
      %end   
      %hold off;
      %
      %grid on;
   	%axis([minpoint maxxpoint 0 max(10,max(rms)+5)])

      
 
 %Plot RMS Delay spread calculated from Channel Impulse
 if chanimpulse==1
      figure(gcf+1)
      semilogx(distancedata,rms2delay,'k*');
      hold on;
      %semilogx(distancedata,meanexcessdelay,'gd');
      %semilogx(distancedata,excessdelay,'ks');
  
      %legend('RMS Delay','Mean Excess Delay','Excess Delay')
       
      [m b]=linefit((distancedatalog),rms2delay);
      yhattilde= m.*(distancedatalog)+b  ;  % this is the un-logarithmic curve fit 
      dif=yhattilde-rms2delay;
      STDrms=std(dif);
      
      pleSTDrms=['\sigma = ' num2str(round(STDrms*100)/100) ' ns']
      text(2,30,pleSTDrms,'color','k')
      
      [m b]=linefit((distancedatalog),meanexcessdelay);
      yhattildemean= m.*(distancedatalog)+b  ;  % this is the un-logarithmic curve fit 
      
      [m b]=linefit((distancedatalog),excessdelay);
      yhattildeexc= m.*(distancedatalog)+b  ;  % this is the un-logarithmic curve fit 
      
      
      semilogx(distancedata,yhattilde,'r');
      %semilogx(distancedata,yhattildemean,'g');
      %semilogx(distancedata,yhattildeexc,'k');
      hold off;
      
      grid on;
      if disttype==1
        xlabel('Distance (feet)','fontsize',12);
     	elseif disttype==2
        xlabel('Distance (meters)','fontsize',12);
     	end 
   	ylabel('RMS Delay Spread (ns)','fontsize',12);
      
      axis([minpoint maxxpoint 0 max( max(10,ceil(max(rms2delay)/10)*10) , ceil(max(rms2delay)/10)*10)+10])
      %ple=['RMS Delay Spread (threshold=' num2str(endthreshhold) '*noise, ', num2str(threshdB), ' dB threshold)_' date];     
      ple=['Delay Spreads Calculated from CIR (', num2str(threshdB), ' dB threshold)  ' date];     
      title(ple)
 end %if chanimpulse  
 
 %Plot RMS Delay spread vs Peak Pathloss calculated from Channel Impulse
 if chanimpulse==1
      figure(gcf+1)
      this=peakpower;relpower+RAKEdB;totpower;
      plot(-10*log10(this),rms2delay,'k*');
      hold on;
      %plot(-10*log10(this),meanexcessdelay,'bd');
      %plot(-10*log10(this),excessdelay,'ks');
  
      %legend('RMS Delay','Mean Excess Delay','Excess Delay')
       
      [m b]=linefit(-10*log10(this),rms2delay);
      yhattilde= m.*(-10*log10(this))+b  ;  % this is the un-logarithmic curve fit 
      dif=yhattilde-rms2delay;
      STDrms=std(dif);
      
      pleSTDrms=['\sigma = ' num2str(round(STDrms*100)/100) ' ns']
      text(2,30,pleSTDrms,'color','k')
        
      [m b]=linefit((-10*log10(this)),meanexcessdelay);
      yhattildemean= m.*(-10*log10(this))+b  ;  % this is the un-logarithmic curve fit 
      
      [m b]=linefit((-10*log10(this)),excessdelay);
      yhattildeexc= m.*(-10*log10(this))+b  ;  % this is the un-logarithmic curve fit 
     
      semilogx(-10*log10(this),yhattilde,'r');
      %semilogx(-10*log10(this),yhattildemean,'g');
      %semilogx(-10*log10(this),yhattildeexc,'k');
      hold off;
      
      grid on;
      xlabel('Peak Pathloss (dB)','fontsize',12);
    	ylabel('RMS Delay Spread (ns)','fontsize',12);
      
      axis([0 ceil(max(-10*log10(this))/10)*10 0 max( max(10,ceil(max(rms2delay)/10)*10) , ceil(max(rms2delay)/10)*10)+10])
      %ple=['RMS Delay Spread (threshold=' num2str(endthreshhold) '*noise, ', num2str(threshdB), ' dB threshold)_' date];     
      ple=['Delay Spreads Calculated from CIR (', num2str(threshdB), ' dB threshold)  ' date];     
      title(ple)
 end %if chanimpulse 
 
   
 %Number of scatterers within a given threshold -----------------------------------------
 if chanimpulse==1

      figure(gcf+1)
      %semilogx
      semilogx(distancedata,numpaths,'b*');
      title(strcat('Number of Scaterers (',num2str(threshdB), ' dB threshold)'));
   	if disttype==1
        xlabel('Distance (feet)','fontsize',12);
     	elseif disttype==2
        xlabel('Distance (meters)','fontsize',12);
     	end 
   	ylabel('Number of Scaterers','fontsize',12);
      
      hold on;
      [m b]=linefit((distancedatalog),numpaths );
      yhattilde= m.*(distancedatalog)+b  ;  % this is the un-logarithmic curve fit 
      hold on;
      %semilogx
      semilogx(distancedata,yhattilde,'b');
      hold off;
      
      axis([minpoint maxxpoint 0 max(10,ceil(max(numpaths)/5)*5+5)])
      grid on;
         
      

end %if chanimpulse  

if chanimpulse==1
      figure(gcf+1)
      semilogx(distancedata,RAKEdB,'b*')
      hold on;
      semilogx(distancedata,PEAKSused,'rs')
      
      [m b]=linefit(distancedatalog,(RAKEdB));
      yhattilde= m.*distancedatalog+b  ;  % this is the un-logarithmic curve fit 
      
      hold on;
      semilogx(distancedata,yhattilde,'b');
      hold off;
      
      
      title(strcat('RAKE Gain Assuming (',num2str(rakes), ' Available Rakes)  ', date));
   	if disttype==1
        xlabel('Distance (feet)');
     	elseif disttype==2
        xlabel('Distance (meters)');
     	end 
      ylabel('RAKE Gain (dB),peaks used');
      legend('RAKE Gain','# Teeth Used')  
      grid on;
      axis([minpoint maxxpoint 0 max(10, ceil(max(max(RAKEdB),max(PEAKSused)))) ])
    end    


figure(1)