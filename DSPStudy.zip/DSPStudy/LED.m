%// returns the sample number of the direct path or -9999999 if can't find it
%// Envelope Difference First Peak with Dynamic Scaling
%int tdRADIO::LeadingEdgeDetection0(int numPts, long *iDataIn)

function [output]=LED(numPts,iDataIN,step,Ts,cumsamps,peakdiv,addtoLE,k,tstart,tstop)
TS=Ts/1e-9;
inMean=0;
peak=1;
%x=[0,0,0];
%y=[0,0,0];
x1=0;
x2=0;
x3=0;
y1=0;
y2=0;
y3=0;


%Calculate Waveform Mean Voltage
for i=1:numPts
   inMean=inMean+iDataIN(i);
end
inMean=inMean/numPts;

%Input an Impulse to the Filter
iDataIN2=[zeros(1,round((numPts-1)/2)) 100 zeros(1,round((numPts)/2))]; 
if length(iDataIN2)~=length(iDataIN)
   iDataIN2=iDataIN2(1:length(iDataIN));
end   

%Correlate with IIR Filter
for i=1:numPts
   inputt=[iDataIN(i)-inMean];
   [outputt,x1,x2,x3,y1,y2,y3]=FilterIIR(inputt,x1,x2,x3,y1,y2,y3);
   iDataINLocal(i)=outputt;
end   
b=[1  0  -1];
a=[1 -1.405512 0.67475];
%a=[16 -22 10];
iDataINLocal2=filter(b,a,iDataIN2);
iDataINLocal2=iDataINLocal2;%.^2;

%build envelope of correlated signal
	envelope=[];
	envelope(1) = 0;
	%compute first one
	for j=1:step
   	envelope(1)=envelope(1)+iDataINLocal(j);  
	end
   
   for i=2:numPts-step
   	envelope(i)=envelope(i-1)-iDataINLocal(i-1) + iDataINLocal(i+step-1);
   end
   
%find the peak in the envelope to re-scale
for i=1:numPts-step
   if envelope(i) > envelope(peak) 
      peak = i;
   end
end   
%find out the dynamic range in the signal
%Not needed in MATLAB
%	// lets find out the dynamic range in the signal
%    int bits_too_big=-16;
%    long big_value=envelope[peak];
%    while(big_value>0)
%    {
%        big_value>>=1;
%        bits_too_big++;
%    }
%   // if less than 16 bits of dynamic range already, no scaling required
%   if(bits_too_big<0) bits_too_big = 0;
%   // 
%   for(i=0; i<numPts-16; i++) envelope[i] >>= bits_too_big;
      
%build difference over 21 (cumsamps-1) samples over cummulative envelope
	diff=[];
   diff(1)=0;
   %compute first one
   for j=2:cumsamps+1 
      diff(1)= diff(1) + envelope(j);    
   end    
   for i=2:numPts-step-cumsamps
      diff(i) = diff(i-1) - envelope(i) + envelope(i+cumsamps);
   end   

   %lets find the peak value
   peak=0;
   for i=1:numPts-step-(cumsamps)
      if peak < diff(i) 
         peak = diff(i);
      end
   end   
   peak=peak/peakdiv;

   %find first place we break this peak/5 value
	for i=1:numPts-step-(cumsamps)
		if peak <= diff(i) 
           peak = i-1;
        	break
      end
   end   

if peak+addtoLE <= 10 
   output=5;
else
   output=peak+addtoLE ;
end   

if k==1
	figure(gcf+1)
   %subplot(211), 
   plot((0:numPts-1)*TS,iDataIN./max(abs(iDataIN)),'k.-')
	hold on
   %subplot(211), 
   plot((0:numPts-1)*TS,iDataINLocal./max(abs(iDataINLocal)),'r.-','LineWidth',2)
	%subplot(211), plot((0:numPts-1)*TS,iDataINLocal2./max(abs(iDataINLocal2)),'m.-')
   %axis([49.6 51 -.8 1.2])
   grid on
   plot((0:numPts-step-1)*TS,envelope/max(abs(envelope)),'g','LineWidth',2)
	plot((0:numPts-step-cumsamps-1)*TS,diff/max(abs(diff)),'k','LineWidth',2)
   plot([output output]*TS, [-1 1],'LineWidth',2,'color','b')
   axis([tstart tstop -.8 1.2])
   xlabel('time (ns)')
	ylabel('normalized amplitude')
   title('LED0')
   %title('Impulse Response of IIR Filter')
   %legend('Impulse Excitation','Manual IIR','MATLAB IIR')
   legend('iDataIN','iDataINLocal','Envelope','Diff','LE')
   hold off
   
   if 1==1
      figure(gcf+1)
      S=fft(iDataIN);
      H=fft(iDataINLocal2);
   	[q,i]=max(abs(H));
   	if i==1
      	H(1)=0;
   	end   
   	%H2=fft(iDataINLocal2);
      subplot(211),
      plot((0:numPts-1)*TS,iDataINLocal2./max(abs(iDataINLocal2)),'r')
      xlabel('time (ns)')
      ylabel('Impulse Response')
      title('IIR Filter for LED')
      this=0;
      for gg=1:length(iDataINLocal2)
         if iDataINLocal2(gg)>this
            this=iDataINLocal2(gg);
            thistime=round(gg-1)*TS;
         end
      end
      axis([thistime-1.5 thistime+1.5 -1 1])
      grid
      
      fs=1/TS;
   	f=(0:length(H)-1)./length(H)*fs; %GHz
      subplot(212),
      plot(f,20*log10(abs(S)./max(abs(S))),'b')
      hold on
      plot(f,20*log10(abs(H)./max(abs(H))+1e-12),'r')
   	hold on
   	%subplot(212), plot(f,abs(H2)./max(abs(H2)),'m')
   	axis([0 10 -40 0])
   	xlabel('frequency (GHz)')
   	ylabel('Transfer Function')
      
      legend('Signal FFT','IIR Filter')
   	grid on
   	hold off
   end   
end

    