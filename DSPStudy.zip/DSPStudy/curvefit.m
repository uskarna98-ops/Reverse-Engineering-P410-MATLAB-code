
function [distdat1,N,K,ya,y,y90N,y90K,M_N,stddev_N,M_K,stddev_K,percent]=curvefit(distancedata,AA,percent_less);

	refd=distancedata(1);
	d=distancedata;
    distdat1=min(distancedata):(max(distancedata)-min(distancedata))/40 : 2*max(distancedata);     
    
%Least Squares Curve fit to 1/d^n ------------------------------------------------
		counter=0;
      Nstart=1.0;
      Ninc=0.05;
      Nstop=5;
      for N=Nstart:Ninc:Nstop
         counter=counter+1;  
         ya=sqrt(1./d.^N);
         ya1=sqrt(1./(refd).^N);%Normalize to 1 meter
         ya=20*log10((ya./ya1));
         Fa(counter)=sum( (AA-ya).^2 );         
      end
      N=Nstart:Ninc:Nstop;
      [q,i]=min(Fa);
      N=N(i);
      ya=sqrt( 1 ./ (distdat1.^N) );
      ya1=sqrt(1./(refd).^N);%Normalize to 1 meter
      ya=20*log10((ya./ya1));
      

      
  %Least Squares Curve fit to exp(-Kd)/d^2 --------------------------------------------
      counter=0;
      Kstart=-0.1;
      Kinc=0.001;
      Kstop=0.25;
  		for K=Kstart:Kinc:Kstop
         counter=counter+1;  
         y=sqrt(exp(-K*d)./d.^2);
         y1=sqrt(exp(-K*refd)./refd.^2);%Normalize to 1 meter
         y=20*log10((y./y1));
         F(counter)=sum( (AA-y).^2 );         
      end
      K=Kstart:Kinc:Kstop;
      [q,i]=min(F);
      K=K(i);
      y=sqrt( exp(-K*distdat1) ./ (distdat1.^2) );
      y1=sqrt(exp(-K*refd)./refd.^2);%Normalize to 1 meter
      y=20*log10((y./y1));
      
%Calculate the Standard Deviation of powersum1 with numbers in Log scale ---------------	
%Km curve
		yK=20*log10( (sqrt(exp(-K*d)./d.^2)/y1) );
      AAK_dB=yK-AA;
   	stddev_K=std( AAK_dB  );
      
      if percent_less>85
         zstart=1.2;
      elseif percent_less>75
         zstart=0.6;
      else
         zstart=-3;
      end
      
      for z=zstart:.002:3
      	%z=1.283;%for 90% reliability from P=0.5*erfc(-z/sqrt(2));%Calculated on 8/30/01, see page 91 of lab notebook II
      	M_K=stddev_K*z;%+ .31
      %Compute a 90% reliability Curve Fit based on standard deviation
      	y90=sqrt(exp(-K*distdat1)./distdat1.^2);
      	y90=20*log10((y90./y1))-(M_K);
      %CHeck on # of samples above line
      	y90a=sqrt(exp(-K*d)./d.^2);
      	y90a=20*log10((y90a./y1))-M_K;
      	count=0;
      	for b=1:length(distancedata)
         	if AA(b) >= y90a(b)
            	count=count+1;
         	end
      	end
         percent=count/length(distancedata)*100;
         if percent>=percent_less
            percent;
            M_K90Kai=stddev_K*1.283;
            M_K;
            break
         end
      end %for z
      y90K=y90;
      
      clear y90;
%N curve
      yN=20*log10( sqrt(1./d.^N)/ya1) ;   
   	AAN_dB=yN-AA;
   	stddev_N=std( AAN_dB  );
   	      
      if percent_less>85
         zstart=1.2;
      elseif percent_less>75
         zstart=0.6;
      else
         zstart=-3;
      end
      
      
      for z=zstart:.002:3
      	%z=1.283;%for 90% reliability from P=0.5*erfc(-z/sqrt(2));%Calculated on 8/30/01, see page 91 of lab notebook II
         M_N=stddev_N*z;%+ .31
      %Compute a 90% reliability Curve Fit based on standard deviation
      	y90=sqrt(1./distdat1.^N) ;
         y90=20*log10((y90./ya1))-(M_N);
      %CHeck on # of samples above line
         y90a=sqrt(1./d.^N) ;
         y90a=20*log10((y90a./ya1))-(M_N);
         
      	count=0;
      	for b=1:length(distancedata)
         	if AA(b) >= y90a(b)
            	count=count+1;
         	end
      	end
         percent=count/length(distancedata)*100;
         if percent>=percent_less
            percent;
            M_N90Kai=stddev_N*1.283;
            M_N;
            break
         end
      end %for z       
      y90N=y90;
